
-- Drop old counselor-specific policies on leads
DROP POLICY IF EXISTS "Counselors can read assigned leads" ON public.leads;
DROP POLICY IF EXISTS "Counselors can update assigned leads" ON public.leads;

-- Team can read ALL leads
CREATE POLICY "Team can read all leads"
ON public.leads FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'team'::app_role));

-- Team can update ALL leads
CREATE POLICY "Team can update all leads"
ON public.leads FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'team'::app_role));
