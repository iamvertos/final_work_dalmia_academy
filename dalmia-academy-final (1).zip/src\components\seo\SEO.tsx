import { Helmet } from "react-helmet-async";
import {
  DEFAULT_DESCRIPTION,
  DEFAULT_OG_IMAGE,
  DEFAULT_OG_IMAGE_ALT,
  DEFAULT_TITLE,
  SITE_LOCALE,
  SITE_NAME,
  TWITTER_HANDLE,
  absoluteUrl,
  canonicalFor,
} from "@/config/site";

export type SEOType = "website" | "article" | "profile";

export interface ArticleMeta {
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  section?: string;
  tags?: string[];
}

export interface SEOProps {
  path: string;
  title?: string;
  description?: string;
  ogTitle?: string;
  ogDescription?: string;
  image?: string;
  imageAlt?: string;
  type?: SEOType;
  noindex?: boolean;
  keywords?: string[] | string;
  canonical?: string;
  schema?: object | object[];
  articleMeta?: ArticleMeta;
}

export function SEO(props: SEOProps) {
  const {
    path,
    title = DEFAULT_TITLE,
    description = DEFAULT_DESCRIPTION,
    ogTitle,
    ogDescription,
    image = DEFAULT_OG_IMAGE,
    imageAlt = DEFAULT_OG_IMAGE_ALT,
    type = "website",
    noindex = false,
    keywords,
    canonical,
    schema,
    articleMeta,
  } = props;

  const url = canonical || canonicalFor(path);
  const ogImg = absoluteUrl(image) || absoluteUrl(DEFAULT_OG_IMAGE)!;
  const finalOgTitle = ogTitle || title;
  const finalOgDescription = ogDescription || description;
  const kw = Array.isArray(keywords) ? keywords.join(", ") : keywords;
  const schemas = schema ? (Array.isArray(schema) ? schema : [schema]) : [];

  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      {kw ? <meta name="keywords" content={kw} /> : null}
      <meta
        name="robots"
        content={noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large"}
      />
      <link rel="canonical" href={url} />

      <meta property="og:type" content={type} />
      <meta property="og:site_name" content={SITE_NAME} />
      <meta property="og:locale" content={SITE_LOCALE} />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={finalOgTitle} />
      <meta property="og:description" content={finalOgDescription} />
      <meta property="og:image" content={ogImg} />
      <meta property="og:image:alt" content={imageAlt} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />

      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={finalOgTitle} />
      <meta name="twitter:description" content={finalOgDescription} />
      <meta name="twitter:image" content={ogImg} />
      <meta name="twitter:image:alt" content={imageAlt} />
      {TWITTER_HANDLE ? <meta name="twitter:site" content={TWITTER_HANDLE} /> : null}
      {TWITTER_HANDLE ? <meta name="twitter:creator" content={TWITTER_HANDLE} /> : null}

      {type === "article" && articleMeta?.publishedTime ? (
        <meta property="article:published_time" content={articleMeta.publishedTime} />
      ) : null}
      {type === "article" && articleMeta?.modifiedTime ? (
        <meta property="article:modified_time" content={articleMeta.modifiedTime} />
      ) : null}
      {type === "article" && articleMeta?.author ? (
        <meta property="article:author" content={articleMeta.author} />
      ) : null}
      {type === "article" && articleMeta?.section ? (
        <meta property="article:section" content={articleMeta.section} />
      ) : null}
      {type === "article" &&
        articleMeta?.tags?.map((tag) => (
          <meta key={tag} property="article:tag" content={tag} />
        ))}

      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(s)}
        </script>
      ))}
    </Helmet>
  );
}

export default SEO;