import { useEffect, useState } from "react";
import { Download, Search, BookOpen } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import StickyHeader from "@/components/StickyHeader";
import Footer from "@/components/Footer";
import StickyBottomBar from "@/components/StickyBottomBar";

import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";

const classCategories = [
  "All",
  "6th", "7th", "8th", "9th", "10th",
  "11th Commerce", "11th Science", "11th Humanities",
  "12th Commerce", "12th Science", "12th Humanities",
  "CA Foundation", "CUET",
];

interface Resource {
  id: string;
  title: string;
  cover_image_url: string | null;
  description: string | null;
  class_category: string | null;
  subject: string | null;
  drive_link: string;
}

const Resources = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [classFilter, setClassFilter] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchResources = async () => {
      const { data } = await supabase
        .from("resources")
        .select("id, title, cover_image_url, description, class_category, subject, drive_link")
        .eq("published", true)
        .order("created_at", { ascending: false });
      setResources(data || []);
      setLoading(false);
    };
    fetchResources();
  }, []);

  const filtered = resources.filter((r) => {
    const matchClass = classFilter === "All" || r.class_category === classFilter;
    const matchSearch = !searchQuery ||
      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (r.subject || "").toLowerCase().includes(searchQuery.toLowerCase());
    return matchClass && matchSearch;
  });

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/resources")} path="/resources" />
      <StickyHeader />
      
      <main>
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              Study <span className="text-accent">Resources</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
              Download free notes, important questions, and study materials prepared by our expert faculty.
            </p>
          </div>
        </section>

        <section className="py-10">
          <div className="container mx-auto px-4">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-3 mb-8 max-w-2xl mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by title or subject..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={classFilter} onValueChange={setClassFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Filter by class" />
                </SelectTrigger>
                <SelectContent>
                  {classCategories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {loading ? (
              <div className="text-center py-20 text-muted-foreground">Loading resources...</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-20">
                <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground">No resources found. Check back soon!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                {filtered.map((resource) => (
                  <div
                    key={resource.id}
                    className="bg-card rounded-xl border border-border overflow-hidden hover:shadow-lg transition-shadow group"
                  >
                    {resource.cover_image_url ? (
                      <img
                        src={resource.cover_image_url}
                        alt={resource.title}
                        className="w-full h-44 object-cover"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-44 bg-muted flex items-center justify-center">
                        <BookOpen className="h-12 w-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="p-5">
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {resource.class_category && (
                          <span className="text-xs bg-primary/10 text-primary rounded-full px-2.5 py-0.5 font-medium">
                            {resource.class_category}
                          </span>
                        )}
                        {resource.subject && (
                          <span className="text-xs bg-accent/10 text-accent-foreground rounded-full px-2.5 py-0.5 font-medium">
                            {resource.subject}
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold font-heading text-foreground mb-1.5 line-clamp-2">
                        {resource.title}
                      </h3>
                      {resource.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                          {resource.description}
                        </p>
                      )}
                      <Button asChild className="w-full gap-2">
                        <a href={resource.drive_link} target="_blank" rel="noopener noreferrer">
                          <Download className="h-4 w-4" />
                          Download
                        </a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I need help with study resources from Dalmia Academy." />
    </div>
  );
};

export default Resources;
