import StickyHeader from "@/components/StickyHeader";
import LeadFormSection from "@/components/LeadFormSection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { Phone, Mail, MapPin } from "lucide-react";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { organizationSchema } from "@/components/seo/SchemaMarkup";


const contactInfo = [
  {
    icon: Phone,
    title: "Call Us",
    detail: "+91 95757 76655",
    href: "tel:+919575776655",
  },
  {
    icon: Mail,
    title: "Email Us",
    detail: "dalmiaacademy@gmail.com",
    href: "mailto:dalmiaacademy@gmail.com",
  },
  {
    icon: MapPin,
    title: "Visit Us",
    detail: "108-109, First Floor, Tulsi Tower Geeta Bhawan Square, AB Rd, Indore",
    href: "https://www.google.com/maps/place/?q=place_id:ChIJH579QzX9YjkR4wewVlLwGW8",
  },
];

const allCourseOptions = [
  { value: "IPMAT & CUET-UG", label: "IPMAT & CUET-UG" },
  { value: "CA / CS", label: "CA / CS Foundation" },
  { value: "Commerce 11th & 12th", label: "Commerce 11th & 12th" },
  { value: "Science 11th & 12th", label: "Science 11th & 12th" },
  { value: "6th-10th", label: "6th–10th Coaching" },
  { value: "Spoken English", label: "Spoken English" },
];

const Contact = () => {
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/contact")} path="/contact" schema={organizationSchema()} />
      <StickyHeader />
      
      <main>
        {/* Hero Banner */}
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              Get in <span className="text-accent">Touch</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
              Have questions? We'd love to hear from you. Reach out for a free counseling session.
            </p>
          </div>
        </section>

        {/* Contact Cards */}
        <section className="py-14 bg-muted">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {contactInfo.map((c) => (
                <a
                  key={c.title}
                  href={c.href}
                  target={c.icon === MapPin ? "_blank" : undefined}
                  rel={c.icon === MapPin ? "noopener noreferrer" : undefined}
                  className="bg-card rounded-xl p-6 border border-border text-center hover:shadow-lg transition-shadow group"
                >
                  <c.icon className="h-8 w-8 text-accent mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold font-heading text-foreground mb-1">{c.title}</h3>
                  <p className="text-sm text-muted-foreground">{c.detail}</p>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* Google Maps */}
        <section className="py-10">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold font-heading text-center text-primary mb-6">
              Find Us Here
            </h2>
            <div className="max-w-4xl mx-auto rounded-xl overflow-hidden border border-border shadow-sm">
              <iframe
                title="Dalmia Academy Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3680.2642757563012!2d75.88359790000001!3d22.718416599999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962fd3543fd9e1f%3A0x6f19f05256b007e3!2sDalmia%20Academy%20-%20Commerce%20%26%20Applied%20Maths%20%7C%20CA%2C%20ACCA%2C%20CUET%2C%20IPMAT%20%7C%20Class%209%20%26%2010%20(All%20Subjects)%20%7C%20Class%2011%20%26%2012!5e0!3m2!1sen!2sin!4v1771501597554!5m2!1sen!2sin"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </section>

        <LeadFormSection courseOptions={allCourseOptions} />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'd like to connect with Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default Contact;
