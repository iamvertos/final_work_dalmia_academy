
-- SEO Module: checklist, scans, results

CREATE TABLE public.seo_checklist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  label text NOT NULL,
  description text,
  category text NOT NULL,
  severity text NOT NULL DEFAULT 'medium',
  sort_order integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'todo',
  notes text,
  updated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.seo_checklist_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage checklist" ON public.seo_checklist_items
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER trg_seo_checklist_items_updated
  BEFORE UPDATE ON public.seo_checklist_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.seo_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  status text NOT NULL DEFAULT 'running',
  total_routes integer NOT NULL DEFAULT 0,
  passed integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  warnings integer NOT NULL DEFAULT 0,
  triggered_by uuid,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.seo_scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read scans" ON public.seo_scans
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TABLE public.seo_scan_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_id uuid NOT NULL REFERENCES public.seo_scans(id) ON DELETE CASCADE,
  route_path text NOT NULL,
  status_code integer,
  title text,
  description text,
  canonical text,
  h1_count integer,
  og_title text,
  og_description text,
  og_image text,
  robots text,
  schema_types text[] DEFAULT '{}',
  issues jsonb NOT NULL DEFAULT '[]',
  severity text NOT NULL DEFAULT 'ok',
  ai_recommendation text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.seo_scan_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read scan results" ON public.seo_scan_results
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update scan results" ON public.seo_scan_results
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_seo_scan_results_scan ON public.seo_scan_results(scan_id);
CREATE INDEX idx_seo_scans_started ON public.seo_scans(started_at DESC);

-- Seed checklist
INSERT INTO public.seo_checklist_items (key, label, description, category, severity, sort_order) VALUES
  ('sitemap_present', 'sitemap.xml exists and is reachable', 'Public sitemap.xml at site root', 'Indexing', 'high', 10),
  ('sitemap_submitted', 'Sitemap submitted in Google Search Console', 'Verify in GSC > Sitemaps', 'Indexing', 'high', 20),
  ('robots_valid', 'robots.txt allows crawling of public pages', 'No accidental Disallow: /', 'Indexing', 'high', 30),
  ('canonical_strategy', 'Single canonical per page, pointing to primary domain', 'https://dalmiaacademy.com', 'Indexing', 'high', 40),
  ('https_enforced', 'HTTPS enforced, www redirects to apex', 'No mixed content', 'Indexing', 'high', 50),
  ('noindex_admin', 'Admin and utility pages are noindex', '/admin/*, /thank-you, /review', 'Indexing', 'medium', 60),
  ('mobile_viewport', 'Viewport meta tag present and correct', 'width=device-width, initial-scale=1', 'Meta', 'high', 100),
  ('title_unique', 'Unique <title> per page, ≤60 chars', 'Avoid duplicates', 'Meta', 'high', 110),
  ('meta_description', 'Unique meta description per page, ≤160 chars', 'Compelling and keyword-relevant', 'Meta', 'high', 120),
  ('og_tags', 'OG title/description/url present on every page', 'For social previews', 'Meta', 'medium', 130),
  ('og_image_default', 'Default OG image set sitewide', 'public/og-default.jpg 1200x630', 'Meta', 'medium', 140),
  ('twitter_card', 'Twitter card tags present', 'summary_large_image', 'Meta', 'low', 150),
  ('single_h1', 'Exactly one <h1> per page', 'With primary keyword', 'Meta', 'medium', 160),
  ('organization_schema', 'Organization JSON-LD on every page', 'EducationalOrganization', 'Schema', 'medium', 200),
  ('article_schema_blog', 'Article schema on every blog post', 'With author, datePublished, image', 'Schema', 'medium', 210),
  ('breadcrumb_schema', 'BreadcrumbList schema on inner pages', 'Helps SERP display', 'Schema', 'low', 220),
  ('faq_schema', 'FAQ schema where FAQ section is visible', 'Coaching pages', 'Schema', 'low', 230),
  ('image_alt_coverage', 'All meaningful images have alt text', 'Decorative use alt=""', 'Accessibility', 'high', 300),
  ('color_contrast', 'Color contrast meets WCAG AA', '4.5:1 for body text', 'Accessibility', 'medium', 310),
  ('form_labels', 'All form inputs have associated labels', 'Use <label> or aria-label', 'Accessibility', 'high', 320),
  ('lcp_target', 'Largest Contentful Paint < 2.5s on mobile', 'Hero image preloaded', 'Performance', 'high', 400),
  ('cls_target', 'Cumulative Layout Shift < 0.1', 'Width/height on images', 'Performance', 'high', 410),
  ('image_dimensions', 'Images resized to display dimensions', 'Avoid serving oversized assets', 'Performance', 'medium', 420),
  ('defer_third_party', 'GTM/Pixel scripts deferred or lazy-loaded', 'After interaction or idle', 'Performance', 'medium', 430),
  ('preconnect_hints', 'Preconnect/preload for critical origins', 'Fonts, CDN', 'Performance', 'low', 440),
  ('404_handling', 'Custom 404 page returns proper status and links home', 'Improves UX and crawl', 'Indexing', 'low', 70),
  ('internal_linking', 'Key pages reachable in ≤3 clicks from home', 'Strong internal links', 'Indexing', 'medium', 80);
