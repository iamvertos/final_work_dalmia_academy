Replace the existing ItemList JSON-LD block in `index.html` (lines 106-211) with the corrected version that nests `courseMode` inside a `hasCourseInstance` → `CourseInstance` object, per Schema.org spec.

Changes:
- Single file: `index.html`
- Move `courseMode: "Onsite"` out of each Course and into a new `hasCourseInstance` object (IPMAT also gets `courseWorkload: "Full-time"`)
- Keep all other fields (name, description, provider, educationalLevel, inLanguage, offers) intact
- Use the exact JSON from the user's message (note: `sameAs` URLs use trailing slash and `availability` uses `http://schema.org/InStock` — preserved verbatim as requested)
- No other schemas (LocalBusiness, FAQPage) are touched

No new components or files needed — keeping it inline in `index.html` matches how the other home-page schemas are implemented.