import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Home from "./pages/Home";
import ScrollToTop from "./components/ScrollToTop";
import GTMPageView from "./components/GTMPageView";

const CUETCoaching = lazy(() => import("./pages/CUETCoaching"));
const CAFoundation = lazy(() => import("./pages/CAFoundation"));
const CommerceCoaching = lazy(() => import("./pages/CommerceCoaching"));
const HumanitiesCoaching = lazy(() => import("./pages/HumanitiesCoaching"));
const SchoolCoaching = lazy(() => import("./pages/SchoolCoaching"));
const SpokenEnglish = lazy(() => import("./pages/SpokenEnglish"));
const ACCACoaching = lazy(() => import("./pages/ACCACoaching"));
const USCPACoaching = lazy(() => import("./pages/USCPACoaching"));
const USCMACoaching = lazy(() => import("./pages/USCMACoaching"));
const CFACoaching = lazy(() => import("./pages/CFACoaching"));
const AboutUs = lazy(() => import("./pages/AboutUs"));
const Results = lazy(() => import("./pages/Results"));
const Contact = lazy(() => import("./pages/Contact"));
const NotFound = lazy(() => import("./pages/NotFound"));
const ThankYou = lazy(() => import("./pages/ThankYou"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogPost = lazy(() => import("./pages/BlogPost"));
const Resources = lazy(() => import("./pages/Resources"));
const AdminLogin = lazy(() => import("./pages/admin/Login"));
const AdminLayout = lazy(() => import("./components/admin/AdminLayout"));
const Dashboard = lazy(() => import("./pages/admin/Dashboard"));
const Leads = lazy(() => import("./pages/admin/Leads"));
const Team = lazy(() => import("./pages/admin/Team"));
const BlogPosts = lazy(() => import("./pages/admin/BlogPosts"));
const BlogEditor = lazy(() => import("./pages/admin/BlogEditor"));
const AdminResources = lazy(() => import("./pages/admin/Resources"));
const SummerLeads = lazy(() => import("./pages/admin/SummerLeads"));
const GTMDebug = lazy(() => import("./pages/admin/GTMDebug"));
const AdminSEO = lazy(() => import("./pages/admin/SEO"));
const AdminSEOScanDetail = lazy(() => import("./pages/admin/SEOScanDetail"));
const ReviewLinks = lazy(() => import("./pages/ReviewLinks"));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <GTMPageView />
        <AuthProvider>
          <Suspense fallback={null}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/cuet-coaching" element={<CUETCoaching />} />
            <Route path="/ca-foundation" element={<CAFoundation />} />
            <Route path="/commerce-coaching" element={<CommerceCoaching />} />
            <Route path="/humanities-coaching" element={<HumanitiesCoaching />} />
            <Route path="/school-coaching" element={<SchoolCoaching />} />
            <Route path="/spoken-english" element={<SpokenEnglish />} />
            <Route path="/acca-coaching" element={<ACCACoaching />} />
            <Route path="/us-cpa-coaching" element={<USCPACoaching />} />
            <Route path="/us-cma-coaching" element={<USCMACoaching />} />
            <Route path="/cfa-coaching" element={<CFACoaching />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/results" element={<Results />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/review" element={<ReviewLinks />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin/blog/editor" element={<BlogEditor />} />
            <Route path="/admin/blog/editor/:id" element={<BlogEditor />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="leads" element={<Leads />} />
              <Route path="summer-leads" element={<SummerLeads />} />
              <Route path="team" element={<Team />} />
              <Route path="blog" element={<BlogPosts />} />
              <Route path="resources" element={<AdminResources />} />
              <Route path="gtm-debug" element={<GTMDebug />} />
              <Route path="seo" element={<AdminSEO />} />
              <Route path="seo/scans/:scanId" element={<AdminSEOScanDetail />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
          </Suspense>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
