export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      blog_posts: {
        Row: {
          author_name: string | null
          auto_saved_at: string | null
          canonical_url: string | null
          category: string | null
          content: string | null
          cover_image_url: string | null
          created_at: string
          excerpt: string | null
          focus_keyword: string | null
          id: string
          meta_description: string | null
          meta_keywords: string | null
          meta_title: string | null
          og_image_url: string | null
          published: boolean | null
          reading_time_minutes: number | null
          schema_type: string | null
          slug: string
          title: string
          updated_at: string
        }
        Insert: {
          author_name?: string | null
          auto_saved_at?: string | null
          canonical_url?: string | null
          category?: string | null
          content?: string | null
          cover_image_url?: string | null
          created_at?: string
          excerpt?: string | null
          focus_keyword?: string | null
          id?: string
          meta_description?: string | null
          meta_keywords?: string | null
          meta_title?: string | null
          og_image_url?: string | null
          published?: boolean | null
          reading_time_minutes?: number | null
          schema_type?: string | null
          slug: string
          title: string
          updated_at?: string
        }
        Update: {
          author_name?: string | null
          auto_saved_at?: string | null
          canonical_url?: string | null
          category?: string | null
          content?: string | null
          cover_image_url?: string | null
          created_at?: string
          excerpt?: string | null
          focus_keyword?: string | null
          id?: string
          meta_description?: string | null
          meta_keywords?: string | null
          meta_title?: string | null
          og_image_url?: string | null
          published?: boolean | null
          reading_time_minutes?: number | null
          schema_type?: string | null
          slug?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      click_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          page_url: string | null
          source_component: string | null
          utm_campaign: string | null
          utm_content: string | null
          utm_medium: string | null
          utm_source: string | null
          utm_term: string | null
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          page_url?: string | null
          source_component?: string | null
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          page_url?: string | null
          source_component?: string | null
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Relationships: []
      }
      leads: {
        Row: {
          admission_status: string | null
          assigned_counselor: string | null
          campaign_name: string | null
          course_interested: string
          created_at: string
          email: string | null
          follow_up_date: string | null
          id: string
          ip_address: string | null
          message: string | null
          name: string
          notes: string | null
          page_url: string | null
          payment_status: string | null
          phone: string
          source: string | null
          status: string
          updated_at: string
          utm_campaign: string | null
          utm_content: string | null
          utm_medium: string | null
          utm_source: string | null
          utm_term: string | null
        }
        Insert: {
          admission_status?: string | null
          assigned_counselor?: string | null
          campaign_name?: string | null
          course_interested: string
          created_at?: string
          email?: string | null
          follow_up_date?: string | null
          id?: string
          ip_address?: string | null
          message?: string | null
          name: string
          notes?: string | null
          page_url?: string | null
          payment_status?: string | null
          phone: string
          source?: string | null
          status?: string
          updated_at?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Update: {
          admission_status?: string | null
          assigned_counselor?: string | null
          campaign_name?: string | null
          course_interested?: string
          created_at?: string
          email?: string | null
          follow_up_date?: string | null
          id?: string
          ip_address?: string | null
          message?: string | null
          name?: string
          notes?: string | null
          page_url?: string | null
          payment_status?: string | null
          phone?: string
          source?: string | null
          status?: string
          updated_at?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Relationships: []
      }
      resources: {
        Row: {
          class_category: string | null
          cover_image_url: string | null
          created_at: string
          description: string | null
          drive_link: string
          id: string
          published: boolean | null
          subject: string | null
          title: string
          updated_at: string
        }
        Insert: {
          class_category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          drive_link: string
          id?: string
          published?: boolean | null
          subject?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          class_category?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          drive_link?: string
          id?: string
          published?: boolean | null
          subject?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      seo_checklist_items: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          key: string
          label: string
          notes: string | null
          severity: string
          sort_order: number
          status: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          key: string
          label: string
          notes?: string | null
          severity?: string
          sort_order?: number
          status?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          label?: string
          notes?: string | null
          severity?: string
          sort_order?: number
          status?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      seo_scan_results: {
        Row: {
          ai_recommendation: string | null
          canonical: string | null
          created_at: string
          description: string | null
          h1_count: number | null
          id: string
          issues: Json
          og_description: string | null
          og_image: string | null
          og_title: string | null
          robots: string | null
          route_path: string
          scan_id: string
          schema_types: string[] | null
          severity: string
          status_code: number | null
          title: string | null
        }
        Insert: {
          ai_recommendation?: string | null
          canonical?: string | null
          created_at?: string
          description?: string | null
          h1_count?: number | null
          id?: string
          issues?: Json
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          robots?: string | null
          route_path: string
          scan_id: string
          schema_types?: string[] | null
          severity?: string
          status_code?: number | null
          title?: string | null
        }
        Update: {
          ai_recommendation?: string | null
          canonical?: string | null
          created_at?: string
          description?: string | null
          h1_count?: number | null
          id?: string
          issues?: Json
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          robots?: string | null
          route_path?: string
          scan_id?: string
          schema_types?: string[] | null
          severity?: string
          status_code?: number | null
          title?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "seo_scan_results_scan_id_fkey"
            columns: ["scan_id"]
            isOneToOne: false
            referencedRelation: "seo_scans"
            referencedColumns: ["id"]
          },
        ]
      }
      seo_scans: {
        Row: {
          created_at: string
          error_message: string | null
          failed: number
          finished_at: string | null
          id: string
          passed: number
          started_at: string
          status: string
          total_routes: number
          triggered_by: string | null
          warnings: number
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          passed?: number
          started_at?: string
          status?: string
          total_routes?: number
          triggered_by?: string | null
          warnings?: number
        }
        Update: {
          created_at?: string
          error_message?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          passed?: number
          started_at?: string
          status?: string
          total_routes?: number
          triggered_by?: string | null
          warnings?: number
        }
        Relationships: []
      }
      summer_leads: {
        Row: {
          activity: string
          batch_preference: string
          child_name: string
          city: string
          class_grade: string
          created_at: string
          id: string
          page_url: string | null
          parent_name: string
          phone: string
          source: string
          utm_campaign: string | null
          utm_content: string | null
          utm_medium: string | null
          utm_source: string | null
          utm_term: string | null
        }
        Insert: {
          activity: string
          batch_preference: string
          child_name: string
          city?: string
          class_grade: string
          created_at?: string
          id?: string
          page_url?: string | null
          parent_name: string
          phone: string
          source?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Update: {
          activity?: string
          batch_preference?: string
          child_name?: string
          city?: string
          class_grade?: string
          created_at?: string
          id?: string
          page_url?: string | null
          parent_name?: string
          phone?: string
          source?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "counselor" | "team"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "counselor", "team"],
    },
  },
} as const
