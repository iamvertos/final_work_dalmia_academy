import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { scienceContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import { useEffect } from "react";

const ScienceCoaching = () => {
  useEffect(() => {
    document.title = scienceContent.pageTitle;
    document.querySelector('meta[name="description"]')?.setAttribute("content", scienceContent.metaDescription);
  }, []);

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={scienceContent.hero} />
        <WhyChooseSection
          heading={scienceContent.whyChoose.heading}
          subheading={scienceContent.whyChoose.subheading}
          benefits={scienceContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={scienceContent.courses.heading}
          subheading={scienceContent.courses.subheading}
          courses={scienceContent.courses.items}
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={scienceContent.highlights.heading}
          subheading={scienceContent.highlights.subheading}
          highlights={scienceContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={scienceContent.leadForm.courseOptions} />
        <FAQSection faqs={scienceContent.faqs} />
        <FinalCTASection
          headline={scienceContent.finalCTA.headline}
          highlightText={scienceContent.finalCTA.highlightText}
          subheadline={scienceContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in 11th & 12th Science Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in 11th & 12th Science Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default ScienceCoaching;
