import {
  DEFAULT_DESCRIPTION,
  DEFAULT_OG_IMAGE,
  DEFAULT_OG_IMAGE_ALT,
  DEFAULT_TITLE,
} from "@/config/site";
import type { SEOProps } from "@/components/seo/SEO";

export type PageIntent =
  | "informational"
  | "commercial"
  | "local"
  | "transactional"
  | "brand"
  | "navigational";

export interface PageSeo extends Omit<SEOProps, "path"> {
  primaryKeyword?: string;
  intent?: PageIntent;
}

export const PAGE_SEO: Record<string, PageSeo> = {
  "/": {
    title: DEFAULT_TITLE,
    description: DEFAULT_DESCRIPTION,
    ogTitle: "Dalmia Academy Indore — Trusted Coaching Since 1991",
    primaryKeyword: "coaching classes in Indore",
    intent: "local",
    keywords: [
      "coaching classes in Indore",
      "best coaching institute in Indore",
      "Dalmia Academy",
      "CUET coaching Indore",
      "CA Foundation Indore",
      "commerce coaching Indore",
      "ACCA coaching in Indore",
      "CFA coaching Indore",
      "us cma coaching in Indore",
      "CIMA coaching Indore",
    ],
  },
  "/cuet-coaching": {
    title: "Best CUET & IPMAT Coaching in Indore — Dalmia Academy",
    description:
      "Best CUET-UG and IPMAT coaching in Indore. Board-integrated preparation with daily mocks, sectional drills, mentorship & small batches at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "CUET coaching in Indore",
    intent: "commercial",
    keywords: ["CUET coaching in Indore", "best CUET coaching in Indore", "IPMAT coaching in Indore", "best IPMAT coaching in Indore", "CUET-UG classes Indore", "cuet coaching fees in Indore", "iim indore ipmat coaching"],
  },
  "/ca-foundation": {
    title: "Best CA Coaching in Indore | CA Foundation & CSEET — Dalmia Academy",
    description:
      "Best CA coaching in Indore since 1991. CA Foundation and CSEET preparation with 90%+ pass rate, small batches of 25, expert faculty & personal mentorship at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "CA coaching in Indore",
    intent: "commercial",
    keywords: ["CA coaching in Indore", "ca foundation coaching in indore", "indore ca coaching", "CSEET coaching Indore", "best CA classes Indore"],
  },
  "/commerce-coaching": {
    title: "Best Commerce Coaching in Indore | 11th & 12th — Dalmia Academy",
    description:
      "Best commerce coaching in Indore for Class 11 & 12. Board + CA/CS integrated preparation with Applied Maths, small batches & 30+ years experience at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "commerce coaching in Indore",
    intent: "commercial",
    keywords: ["commerce coaching in Indore", "best commerce coaching Indore", "11th commerce coaching in Indore", "12th commerce coaching in Indore", "11th 12th coaching in Indore", "accounts coaching in Indore", "economics tuition in Indore", "commerce tuition near me"],
  },
  "/humanities-coaching": {
    title: "Best Humanities Coaching in Indore | 11th & 12th — Dalmia Academy",
    description:
      "Best humanities coaching in Indore for Class 11 & 12. Score 85%-95%+ in boards with expert faculty, structured answer writing & small batches at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "humanities coaching in Indore",
    intent: "commercial",
    keywords: ["humanities coaching in Indore", "best humanities coaching Indore", "arts coaching in Indore", "11th humanities coaching Indore", "12th humanities coaching Indore", "psychology coaching Indore", "sociology coaching Indore", "political science tuition Indore", "humanities tuition near me"],
  },
  "/school-coaching": {
    title: "Best Class 6 to 10 Coaching in Indore | Class 9 & 10 Tuition — Dalmia Academy",
    description:
      "Best coaching for Class 6 to 10 in Indore. Maths, Science, English tuition near Geeta Bhawan Square. Class 9 & 10 board exam prep with small batches at Dalmia Academy.",
    primaryKeyword: "class 9 coaching in Indore",
    intent: "commercial",
    keywords: ["class 9 coaching near me", "class 9 coaching in Indore", "class 10 coaching in Indore", "6th to 10th coaching in Indore", "maths coaching in Indore", "science coaching in Indore", "CBSE coaching in Indore", "tuition classes near me"],
  },
  "/spoken-english": {
    title: "Best Spoken English Classes in Indore | Personality Development — Dalmia Academy",
    description:
      "Best spoken English classes in Indore. English speaking course, personality development & interview prep at Dalmia Academy, Geeta Bhawan Square. Beginner to advanced batches.",
    primaryKeyword: "spoken English classes in Indore",
    intent: "commercial",
    keywords: ["spoken English classes in Indore", "best spoken English classes Indore", "English speaking course in Indore", "personality development classes Indore", "English coaching in Indore", "spoken English near me"],
  },
  "/acca-coaching": {
    title: "Best ACCA Coaching in Indore | Dalmia Academy",
    description:
      "Best ACCA coaching in Indore. Prepare for all 13 ACCA papers with expert faculty, structured study plans & small batches at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "ACCA coaching in Indore",
    intent: "commercial",
    keywords: ["ACCA coaching in Indore", "ACCA classes Indore", "best ACCA coaching Indore", "ACCA preparation Indore"],
  },
  "/us-cpa-coaching": {
    title: "Best US CPA Coaching in Indore | Dalmia Academy",
    description:
      "Best US CPA coaching in Indore. Prepare for all 4 CPA sections — FAR, AUD, REG, BEC — with expert faculty & structured coaching at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "US CPA coaching in Indore",
    intent: "commercial",
    keywords: ["US CPA coaching in Indore", "CPA classes Indore", "best CPA coaching Indore", "CPA preparation Indore"],
  },
  "/us-cma-coaching": {
    title: "Best US CMA Coaching in Indore | Dalmia Academy",
    description:
      "Best US CMA coaching in Indore. Prepare for both CMA parts with expert accounting faculty & structured study plans at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "US CMA coaching in Indore",
    intent: "commercial",
    keywords: ["US CMA coaching in Indore", "CMA classes Indore", "best CMA coaching Indore", "CMA preparation Indore"],
  },
  "/cfa-coaching": {
    title: "Best CFA Coaching in Indore | Dalmia Academy",
    description:
      "Best CFA coaching in Indore. Prepare for all 3 CFA levels with expert faculty, structured study plans & small batches at Dalmia Academy, Geeta Bhawan Square.",
    primaryKeyword: "CFA coaching in Indore",
    intent: "commercial",
    keywords: ["CFA coaching in Indore", "CFA classes Indore", "best CFA coaching Indore", "CFA preparation Indore"],
  },
  "/about": {
    title: "About Dalmia Academy Indore — 30+ Years of Trusted Coaching",
    description:
      "Dalmia Academy Indore has mentored students since 1991 with concept-first coaching for CUET, CA, Commerce, Humanities and school. Meet the team and mission.",
    primaryKeyword: "about Dalmia Academy",
    intent: "brand",
  },
  "/results": {
    title: "Results & Student Stories — Dalmia Academy Indore",
    description:
      "Read real student outcomes and testimonials from Dalmia Academy Indore — 1000+ students mentored, 90%+ pass rate across boards and competitive exams.",
    primaryKeyword: "Dalmia Academy results",
    intent: "brand",
  },
  "/contact": {
    title: "Contact Dalmia Academy Indore — Call, WhatsApp or Visit",
    description:
      "Reach Dalmia Academy Indore at +91 95757 76655 or visit 108-109 Tulsi Tower, Geeta Bhawan Square, AB Road, Indore. Book a free counselling session.",
    primaryKeyword: "Dalmia Academy contact Indore",
    intent: "local",
  },
  "/blog": {
    title: "Dalmia Academy Blog — CUET, CA & Commerce Insights",
    description:
      "Articles, exam tips and academic guidance from Dalmia Academy Indore on CUET, CA Foundation, Commerce, Humanities and school prep.",
    primaryKeyword: "commerce CA CUET tips",
    intent: "informational",
  },
  "/resources": {
    title: "Free Study Notes & Resources — Dalmia Academy Indore",
    description:
      "Free downloadable notes, important questions and resources for classes 6-12, CA Foundation and CUET — curated by Dalmia Academy Indore faculty.",
    primaryKeyword: "free study notes commerce CUET",
    intent: "informational",
  },
  "/thank-you": {
    title: "Thank You — Dalmia Academy Indore",
    description: "Your enquiry was received. Our counsellor will reach out shortly.",
    noindex: true,
  },
  "/review": {
    title: "Leave a Review — Dalmia Academy Indore",
    description: "Share your experience with Dalmia Academy on Google or JustDial.",
    noindex: true,
  },
};

const DEFAULTS: PageSeo = {
  title: DEFAULT_TITLE,
  description: DEFAULT_DESCRIPTION,
  image: DEFAULT_OG_IMAGE,
  imageAlt: DEFAULT_OG_IMAGE_ALT,
};

export function getPageSeo(path: string): PageSeo {
  return PAGE_SEO[path] || DEFAULTS;
}