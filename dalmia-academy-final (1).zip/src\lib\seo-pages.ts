import routes from "@/data/static-routes.json";

export interface StaticRoute {
  path: string;
  type: string;
  priority: string;
  changefreq: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  indexable: boolean;
}

export const STATIC_ROUTES: StaticRoute[] = routes as StaticRoute[];

export function getSitemapEntries() {
  const seen = new Set<string>();
  return STATIC_ROUTES.filter((r) => r.indexable)
    .map((r) => ({
      path: r.path,
      changefreq: r.changefreq,
      priority: r.priority,
    }))
    .filter((r) => {
      if (seen.has(r.path)) return false;
      seen.add(r.path);
      return true;
    });
}