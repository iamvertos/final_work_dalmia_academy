import { Star } from "lucide-react";
import type { TestimonialItem } from "@/data/pageContent";

interface TrustSectionProps {
  testimonials?: TestimonialItem[];
}

const TrustSection = ({ testimonials = [] }: TrustSectionProps) => {
  return (
    <section className="py-14 md:py-20 bg-primary/5" id="trust">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          What Our Students Say
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          Building exam confidence through concept clarity and foundation-focused learning
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="bg-card rounded-lg p-6 shadow-sm border border-border"
            >
              <div className="flex gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed italic">"{t.text}"</p>
              <div>
                <p className="font-semibold font-heading text-foreground">{t.name}</p>
                <p className="text-xs text-secondary">{t.course}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
