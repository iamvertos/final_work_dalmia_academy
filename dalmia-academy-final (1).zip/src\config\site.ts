export const SITE_URL = "https://dalmiaacademy.com";
export const SITE_NAME = "Dalmia Academy Indore";
export const SITE_LOCALE = "en_IN";
export const TWITTER_HANDLE: string | null = null;

export const DEFAULT_TITLE =
  "Dalmia Academy Indore — Coaching for CUET, CA, Commerce, Humanities & School";
export const DEFAULT_DESCRIPTION =
  "Dalmia Academy Indore offers expert coaching for IPMAT, CUET-UG, CA Foundation / CSEET, 11th-12th Commerce & Humanities, Spoken English and 6th-10th tuition. 30+ years of trusted academic mentoring.";
export const DEFAULT_OG_IMAGE = "/og-default.jpg";
export const DEFAULT_OG_IMAGE_ALT =
  "Dalmia Academy Indore — coaching for CUET, CA, Commerce and School";

const PRIVATE_PREFIXES = ["/admin", "/thank-you", "/review", "/summer-camp/register"];

export function isPrivatePath(path: string): boolean {
  if (!path) return false;
  return PRIVATE_PREFIXES.some((p) => path === p || path.startsWith(`${p}/`));
}

export function canonicalFor(path: string): string {
  if (!path) return SITE_URL + "/";
  if (path.startsWith("http")) return path;
  const clean = path.startsWith("/") ? path : `/${path}`;
  // strip trailing slash except root
  const normalized = clean.length > 1 && clean.endsWith("/") ? clean.slice(0, -1) : clean;
  return `${SITE_URL}${normalized}`;
}

export function absoluteUrl(pathOrUrl?: string | null): string | undefined {
  if (!pathOrUrl) return undefined;
  if (pathOrUrl.startsWith("http")) return pathOrUrl;
  return `${SITE_URL}${pathOrUrl.startsWith("/") ? "" : "/"}${pathOrUrl}`;
}