import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import StickyHeader from "@/components/StickyHeader";
import Footer from "@/components/Footer";
import StickyBottomBar from "@/components/StickyBottomBar";

import { BookOpen } from "lucide-react";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  cover_image_url: string | null;
  excerpt: string | null;
  category: string | null;
  created_at: string;
}

const Blog = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [categories, setCategories] = useState<string[]>([]);

  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const { data, error: fetchError } = await supabase
          .from("blog_posts")
          .select("id, title, slug, cover_image_url, excerpt, category, created_at, author_name, reading_time_minutes")
          .eq("published", true)
          .order("created_at", { ascending: false });
        if (fetchError) throw fetchError;
        const postData = data || [];
        setPosts(postData);
        const cats = [...new Set(postData.map((p) => p.category).filter(Boolean))] as string[];
        setCategories(cats);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  const filtered = categoryFilter === "All" ? posts : posts.filter((p) => p.category === categoryFilter);

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/blog")} path="/blog" />
      <StickyHeader />
      
      <main>
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              Our <span className="text-accent">Blog</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
              Tips, updates, exam strategies, and career guidance from our expert faculty.
            </p>
          </div>
        </section>

        <section className="py-10">
          <div className="container mx-auto px-4">
            {categories.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center mb-8">
                <button
                  onClick={() => setCategoryFilter("All")}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                    categoryFilter === "All" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  All
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                      categoryFilter === cat ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            )}

            {error ? (
              <div className="text-center py-20">
                <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground">Unable to load articles right now. Please try again later.</p>
              </div>
            ) : loading ? (
              <div className="text-center py-20 text-muted-foreground">Loading articles...</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-20">
                <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground">No articles yet. Check back soon!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                {filtered.map((post) => (
                  <Link
                    key={post.id}
                    to={`/blog/${post.slug}`}
                    className="bg-card rounded-xl border border-border overflow-hidden hover:shadow-lg transition-shadow group"
                  >
                    {post.cover_image_url ? (
                      <img src={post.cover_image_url} alt={post.title} className="w-full h-48 object-cover" loading="lazy" />
                    ) : (
                      <div className="w-full h-48 bg-muted flex items-center justify-center">
                        <BookOpen className="h-12 w-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="p-5">
                      <div className="flex items-center gap-2 mb-2">
                        {post.category && (
                          <span className="text-xs bg-primary/10 text-primary rounded-full px-2.5 py-0.5 font-medium">
                            {post.category}
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {new Date(post.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                        </span>
                        {(post as any).reading_time_minutes && (
                          <span className="text-xs text-muted-foreground">· {(post as any).reading_time_minutes} min</span>
                        )}
                      </div>
                      <h3 className="font-bold font-heading text-foreground mb-1.5 line-clamp-2 group-hover:text-primary transition-colors">
                        {post.title}
                      </h3>
                      {post.excerpt && (
                        <p className="text-sm text-muted-foreground line-clamp-3">{post.excerpt}</p>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I read a blog post on Dalmia Academy. I need more info." />
    </div>
  );
};

export default Blog;
