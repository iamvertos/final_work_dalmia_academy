import { Phone, MapPin } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";
import { trackClick } from "@/hooks/useClickTracking";
import { Button } from "@/components/ui/button";

interface FinalCTASectionProps {
  headline?: string;
  highlightText?: string;
  subheadline?: string;
  whatsappMessage?: string;
}

const FinalCTASection = ({
  headline = "Limited Seats Available —",
  highlightText = "Enroll Early",
  subheadline = "Don't miss your chance to prepare with Indore's best CUET coaching. Book your seat today!",
  whatsappMessage,
}: FinalCTASectionProps) => {
  const whatsappUrl = whatsappMessage
    ? `https://wa.me/919575776655?text=${encodeURIComponent(whatsappMessage)}`
    : "https://wa.me/919575776655";
  return (
    <section className="py-14 md:py-20 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-4xl font-bold font-heading mb-3">
          {headline} <span className="text-accent">{highlightText}</span>
        </h2>
        <p className="opacity-90 mb-8 max-w-xl mx-auto">
          {subheadline}
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center mb-10">
          <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-bold">
            <a href="#lead-form">Book Free Demo</a>
          </Button>
          <Button asChild size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white/10 font-heading font-bold">
            <a href="tel:+919575776655" onClick={() => trackClick("phone_click", "final_cta")}>
              <Phone className="h-4 w-4 mr-2" />
              Call Now
            </a>
          </Button>
          <Button asChild size="lg" className="bg-green-600 hover:bg-green-700 text-white font-heading font-bold">
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackClick("whatsapp_click", "final_cta")}>
              <WhatsAppIcon className="h-4 w-4 mr-2" />
              WhatsApp
            </a>
          </Button>
        </div>

        <div className="flex items-center justify-center gap-2 text-sm opacity-80">
          <MapPin className="h-4 w-4" />
          108-109, First Floor, Tulsi Tower Geeta Bhawan Square, AB Rd, Indore
        </div>
      </div>
    </section>
  );
};

export default FinalCTASection;
