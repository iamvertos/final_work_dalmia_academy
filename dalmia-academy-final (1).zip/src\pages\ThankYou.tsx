import { CheckCircle, BookOpen, Home } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { trackClick } from "@/hooks/useClickTracking";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";

const WHATSAPP_NUMBER = "919109109651";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=Hi%2C%20I%20just%20submitted%20a%20form%20on%20your%20website.%20I%20need%20more%20info.`;

const ThankYou = () => {
  const handleWhatsAppClick = () => {
    trackClick("whatsapp_click", "thank_you_page");
    window.open(WHATSAPP_URL, "_blank");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <SEO {...getPageSeo("/thank-you")} path="/thank-you" />
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <div className="rounded-full bg-green-100 p-4">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
        </div>

        <h1 className="text-3xl md:text-4xl font-bold font-heading text-foreground">
          Thank You! 🎉
        </h1>

        <p className="text-muted-foreground text-base leading-relaxed">
          Our counselor will contact you within{" "}
          <span className="font-semibold text-foreground">2 hours</span>. For a
          faster response, chat with us on WhatsApp.
        </p>

        <Button
          onClick={handleWhatsAppClick}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-heading font-bold text-base h-12 gap-2"
        >
          <WhatsAppIcon className="h-5 w-5" />
          Continue on WhatsApp
        </Button>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Link to="/cuet-coaching">
            <Button variant="outline" className="gap-2">
              <BookOpen className="h-4 w-4" />
              Explore Courses
            </Button>
          </Link>
          <Link to="/">
            <Button variant="ghost" className="gap-2">
              <Home className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYou;
