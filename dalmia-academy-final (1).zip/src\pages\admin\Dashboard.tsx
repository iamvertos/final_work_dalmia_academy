import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import DashboardCards from "@/components/admin/DashboardCards";
import UTMLinkGenerator from "@/components/admin/UTMLinkGenerator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, PieChart, Pie, Cell, BarChart, Bar, CartesianGrid } from "recharts";
import { startOfDay, startOfMonth, format, subDays } from "date-fns";

const COLORS = ["#2563eb", "#0ea5e9", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444", "#06b6d4", "#6366f1"];

const Dashboard = () => {
  const [leads, setLeads] = useState<any[]>([]);
  const [phoneClicksToday, setPhoneClicksToday] = useState(0);
  const [whatsappClicksToday, setWhatsappClicksToday] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const todayISO = startOfDay(new Date()).toISOString();

    const fetchAll = async () => {
      const [leadsRes, phoneRes, whatsappRes] = await Promise.all([
        supabase.from("leads").select("*").order("created_at", { ascending: false }),
        supabase.from("click_events").select("id", { count: "exact", head: true }).eq("event_type", "phone_click").gte("created_at", todayISO),
        supabase.from("click_events").select("id", { count: "exact", head: true }).eq("event_type", "whatsapp_click").gte("created_at", todayISO),
      ]);
      setLeads(leadsRes.data || []);
      setPhoneClicksToday(phoneRes.count || 0);
      setWhatsappClicksToday(whatsappRes.count || 0);
      setLoading(false);
    };
    fetchAll();
  }, []);

  const now = new Date();
  const todayStart = startOfDay(now).toISOString();
  const monthStart = startOfMonth(now).toISOString();

  const todayCount = leads.filter((l) => l.created_at >= todayStart).length;
  const monthCount = leads.filter((l) => l.created_at >= monthStart).length;
  const pendingFollowUps = leads.filter(
    (l) => l.status === "Follow-up Required" || (l.follow_up_date && new Date(l.follow_up_date) <= now)
  ).length;
  const confirmedCount = leads.filter((l) => l.status === "Admission Confirmed").length;

  // Daily trend (last 30 days)
  const trendData = Array.from({ length: 30 }, (_, i) => {
    const day = subDays(now, 29 - i);
    const dayStr = format(day, "yyyy-MM-dd");
    const count = leads.filter((l) => format(new Date(l.created_at), "yyyy-MM-dd") === dayStr).length;
    return { date: format(day, "MMM dd"), count };
  });

  // Course distribution
  const courseMap: Record<string, number> = {};
  leads.forEach((l) => {
    courseMap[l.course_interested] = (courseMap[l.course_interested] || 0) + 1;
  });
  const courseData = Object.entries(courseMap).map(([name, value]) => ({ name, value }));

  // Status funnel
  const statusOrder = ["New", "Contacted", "Interested", "Demo Booked", "Admission Confirmed"];
  const funnelData = statusOrder.map((s) => ({
    status: s,
    count: leads.filter((l) => l.status === s).length,
  }));

  if (loading) {
    return <p className="text-muted-foreground">Loading dashboard...</p>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-heading font-bold">Dashboard</h1>

      <DashboardCards
        todayCount={todayCount}
        monthCount={monthCount}
        pendingFollowUps={pendingFollowUps}
        confirmedCount={confirmedCount}
        phoneClicksToday={phoneClicksToday}
        whatsappClicksToday={whatsappClicksToday}
      />

      <UTMLinkGenerator />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leads Trend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Leads Trend (30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{ count: { label: "Leads", color: "hsl(var(--primary))" } }} className="h-[250px]">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Course Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Course-wise Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={Object.fromEntries(courseData.map((d, i) => [d.name, { label: d.name, color: COLORS[i % COLORS.length] }]))}
              className="h-[250px]"
            >
              <PieChart>
                <Pie data={courseData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {courseData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Conversion Funnel */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Conversion Funnel</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={Object.fromEntries(funnelData.map((d, i) => [d.status, { label: d.status, color: COLORS[i] }]))}
              className="h-[250px]"
            >
              <BarChart data={funnelData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="status" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
