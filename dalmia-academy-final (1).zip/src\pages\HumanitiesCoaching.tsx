import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { humanitiesContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const humanitiesCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/humanities-coaching#course",
  name: "11th & 12th Humanities Coaching",
  description:
    "Humanities coaching for Class 11 and 12 at Dalmia Academy, Indore. Concept-based teaching with structured answer writing training targeting 85%–95%+ board scores. Covers Psychology, Political Science, Geography, and History with analytical thinking development and exam strategy.",
  url: "https://dalmiaacademy.com/humanities-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "HighSchool",
  teaches: [
    "Psychology",
    "Political Science",
    "Geography",
    "History",
    "Sociology",
    "Human Behavior",
    "Cognitive Processes",
    "Therapeutic Approaches",
    "Indian Constitution",
    "Political Theory",
    "Contemporary World Politics",
    "Indian Government",
    "Physical Geography",
    "Human Geography",
    "Map Work",
    "Modern India",
    "World History",
    "Source Analysis",
  ],
  coursePrerequisites: "Completed Class 10",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "11th Humanities",
      description:
        "Foundation year for Humanities students covering Psychology, Political Science, Geography, and History with concept clarity and answer writing techniques.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
      instructor: [
        { "@type": "Person", name: "Nidhi Ghosh", jobTitle: "Senior Faculty — History & Political Science" },
        { "@type": "Person", name: "Mohini Ojha", jobTitle: "Senior Faculty — Geography" },
      ],
    },
    {
      "@type": "CourseInstance",
      name: "12th Humanities",
      description:
        "Board-focused Humanities preparation for Class 12 with intensive answer writing practice, mock exams, time management, and exam strategy sessions.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  about: [
    { "@type": "Thing", name: "CBSE Humanities" },
    { "@type": "Thing", name: "MP Board Humanities" },
    { "@type": "Thing", name: "Board Exam Preparation" },
    { "@type": "Thing", name: "Answer Writing Skills" },
    { "@type": "Thing", name: "Psychology Coaching" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/humanities-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "5",
    reviewCount: "8",
    bestRating: "5",
    worstRating: "1",
  },
};

const HumanitiesCoaching = () => {
  const seo = getPageSeo("/humanities-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/humanities-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/humanities-coaching" }),
          humanitiesCourseSchema,
          faqSchema(humanitiesContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Humanities Coaching in Indore", path: "/humanities-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={humanitiesContent.hero} />
        <WhyChooseSection
          heading={humanitiesContent.whyChoose.heading}
          subheading={humanitiesContent.whyChoose.subheading}
          benefits={humanitiesContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={humanitiesContent.courses.heading}
          subheading={humanitiesContent.courses.subheading}
          courses={humanitiesContent.courses.items}
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={humanitiesContent.highlights.heading}
          subheading={humanitiesContent.highlights.subheading}
          highlights={humanitiesContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={humanitiesContent.leadForm.courseOptions} />
        <FAQSection faqs={humanitiesContent.faqs} />
        <FinalCTASection
          headline={humanitiesContent.finalCTA.headline}
          highlightText={humanitiesContent.finalCTA.highlightText}
          subheadline={humanitiesContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in 11th & 12th Humanities Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in 11th & 12th Humanities Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default HumanitiesCoaching;
