import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import type { FAQItem } from "@/data/pageContent";

interface FAQSectionProps {
  faqs?: FAQItem[];
}

const FAQSection = ({ faqs = [] }: FAQSectionProps) => {
  return (
    <section className="py-14 md:py-20" id="faq">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          Frequently Asked Questions
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          Everything you need to know about coaching at Dalmia Academy
        </p>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="text-left font-heading text-foreground">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
