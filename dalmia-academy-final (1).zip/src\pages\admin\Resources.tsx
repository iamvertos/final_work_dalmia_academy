import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Resource {
  id: string;
  title: string;
  cover_image_url: string | null;
  description: string | null;
  class_category: string | null;
  subject: string | null;
  drive_link: string;
  published: boolean;
  created_at: string;
}

const classCategories = [
  "6th", "7th", "8th", "9th", "10th",
  "11th Commerce", "11th Science", "11th Humanities",
  "12th Commerce", "12th Science", "12th Humanities",
  "CA Foundation", "CUET",
];

const AdminResources = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Resource | null>(null);
  const [form, setForm] = useState({ title: "", description: "", class_category: "", subject: "", drive_link: "", published: true, cover_image_url: "" });
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const fetchResources = async () => {
    const { data } = await supabase.from("resources").select("*").order("created_at", { ascending: false });
    setResources(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchResources(); }, []);

  const openNew = () => {
    setEditing(null);
    setForm({ title: "", description: "", class_category: "", subject: "", drive_link: "", published: true, cover_image_url: "" });
    setDialogOpen(true);
  };

  const openEdit = (r: Resource) => {
    setEditing(r);
    setForm({
      title: r.title,
      description: r.description || "",
      class_category: r.class_category || "",
      subject: r.subject || "",
      drive_link: r.drive_link,
      published: r.published,
      cover_image_url: r.cover_image_url || "",
    });
    setDialogOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `resources/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("blog-images").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    } else {
      const { data: urlData } = supabase.storage.from("blog-images").getPublicUrl(path);
      setForm((f) => ({ ...f, cover_image_url: urlData.publicUrl }));
    }
    setUploading(false);
  };

  const handleSave = async () => {
    if (!form.title || !form.drive_link) {
      toast({ title: "Title and Google Drive link are required", variant: "destructive" });
      return;
    }
    const payload = {
      title: form.title,
      description: form.description || null,
      class_category: form.class_category || null,
      subject: form.subject || null,
      drive_link: form.drive_link,
      published: form.published,
      cover_image_url: form.cover_image_url || null,
    };

    if (editing) {
      const { error } = await supabase.from("resources").update(payload).eq("id", editing.id);
      if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return; }
    } else {
      const { error } = await supabase.from("resources").insert(payload);
      if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return; }
    }
    toast({ title: editing ? "Resource updated" : "Resource created" });
    setDialogOpen(false);
    fetchResources();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this resource?")) return;
    await supabase.from("resources").delete().eq("id", id);
    toast({ title: "Resource deleted" });
    fetchResources();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold font-heading text-foreground">Resources</h1>
        <Button onClick={openNew} className="gap-2"><Plus className="h-4 w-4" /> Add Resource</Button>
      </div>

      {loading ? (
        <p className="text-muted-foreground">Loading...</p>
      ) : resources.length === 0 ? (
        <p className="text-muted-foreground">No resources yet.</p>
      ) : (
        <div className="space-y-3">
          {resources.map((r) => (
            <div key={r.id} className="bg-card border border-border rounded-lg p-4 flex items-center gap-4">
              {r.cover_image_url && (
                <img src={r.cover_image_url} alt="" className="w-16 h-16 rounded object-cover shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground truncate">{r.title}</h3>
                <p className="text-xs text-muted-foreground">
                  {r.class_category} · {r.subject}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <a href={r.drive_link} target="_blank" rel="noopener noreferrer">
                  <Button variant="ghost" size="icon"><ExternalLink className="h-4 w-4" /></Button>
                </a>
                <Button variant="ghost" size="icon" onClick={() => openEdit(r)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(r.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Resource" : "Add Resource"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
            </div>
            <div>
              <Label>Class / Category</Label>
              <Select value={form.class_category} onValueChange={(v) => setForm((f) => ({ ...f, class_category: v }))}>
                <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
                <SelectContent>
                  {classCategories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Subject</Label>
              <Input value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} placeholder="e.g. Maths, Accountancy" />
            </div>
            <div>
              <Label>Cover Image</Label>
              <Input type="file" accept="image/*" onChange={handleImageUpload} disabled={uploading} />
              {form.cover_image_url && (
                <img src={form.cover_image_url} alt="Cover" className="mt-2 h-32 rounded object-cover" />
              )}
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={3} />
            </div>
            <div>
              <Label>Google Drive Link</Label>
              <Input value={form.drive_link} onChange={(e) => setForm((f) => ({ ...f, drive_link: e.target.value }))} placeholder="https://drive.google.com/..." />
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.published} onCheckedChange={(v) => setForm((f) => ({ ...f, published: v }))} />
              <Label>Published</Label>
            </div>
            <Button onClick={handleSave} className="w-full">{editing ? "Update Resource" : "Add Resource"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminResources;
