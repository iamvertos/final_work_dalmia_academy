import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { schoolContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const schoolCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/school-coaching#course",
  name: "6th to 10th All Subjects Coaching",
  description:
    "Comprehensive school tuition for Class 6 to 10 (CBSE & MP Board) at Dalmia Academy, Indore. Concept-based learning across Mathematics, Science, English, Social Science, and Hindi with small batches, regular tests, and early competitive exam readiness for NTSE, Olympiads, and beyond.",
  url: "https://dalmiaacademy.com/school-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "MiddleSchool",
  teaches: [
    "Mathematics",
    "Arithmetic",
    "Algebra",
    "Geometry",
    "Science",
    "Physics",
    "Chemistry",
    "Biology",
    "English",
    "Grammar",
    "Comprehension",
    "Writing Skills",
    "Literature",
    "Social Science",
    "History",
    "Geography",
    "Civics",
    "Hindi",
    "Vyakaran",
    "Sahitya",
    "Lekhan",
  ],
  coursePrerequisites: "Class 6 to Class 10 students (CBSE or MP Board)",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "Class 6th–8th Coaching",
      description:
        "Foundation-building coaching for Classes 6 to 8 covering all major subjects — Mathematics, Science, English, Social Science, and Hindi — in small batches with concept clarity and regular practice.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "Class 9th–10th Coaching",
      description:
        "Board-oriented coaching for Classes 9 and 10 with mock tests, answer writing skills, time management, and exam presentation strategies for CBSE and MP Board students.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  about: [
    { "@type": "Thing", name: "CBSE School Coaching" },
    { "@type": "Thing", name: "MP Board School Coaching" },
    { "@type": "Thing", name: "NTSE Preparation" },
    { "@type": "Thing", name: "Olympiad Preparation" },
    { "@type": "Thing", name: "School Tuition" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/school-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "5",
    reviewCount: "8",
    bestRating: "5",
    worstRating: "1",
  },
};

const SchoolCoaching = () => {
  const seo = getPageSeo("/school-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/school-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/school-coaching" }),
          schoolCourseSchema,
          faqSchema(schoolContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Class 6-10 Coaching in Indore", path: "/school-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={schoolContent.hero} />
        <WhyChooseSection
          heading={schoolContent.whyChoose.heading}
          subheading={schoolContent.whyChoose.subheading}
          benefits={schoolContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={schoolContent.courses.heading}
          subheading={schoolContent.courses.subheading}
          courses={schoolContent.courses.items}
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={schoolContent.highlights.heading}
          subheading={schoolContent.highlights.subheading}
          highlights={schoolContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={schoolContent.leadForm.courseOptions} />
        <FAQSection faqs={schoolContent.faqs} />
        <FinalCTASection
          headline={schoolContent.finalCTA.headline}
          highlightText={schoolContent.finalCTA.highlightText}
          subheadline={schoolContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in 6th-10th Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in 6th-10th Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default SchoolCoaching;
