import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import RichTextSection from "@/components/RichTextSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { cfaContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const cfaCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/cfa-coaching#course",
  name: "CFA Coaching in Indore",
  description:
    "CFA (Chartered Financial Analyst) coaching at Dalmia Academy, Indore. Structured preparation for all 3 CFA levels covering Ethics, Equity, Fixed Income, Derivatives, Portfolio Management and more with expert faculty and small batches.",
  url: "https://dalmiaacademy.com/cfa-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "ProfessionalCertificate",
  teaches: [
    "Ethics & Professional Standards", "Quantitative Methods", "Economics",
    "Financial Reporting & Analysis", "Corporate Issuers", "Equity Investments",
    "Fixed Income", "Derivatives", "Alternative Investments", "Portfolio Management",
  ],
  coursePrerequisites: "Bachelor's degree or final year of graduation",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      postalCode: "452001",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "CFA Level I",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "CFA Level II",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "CFA Level III",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Counselling Available",
    url: "https://dalmiaacademy.com/cfa-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
};

const cfaContentBlocks = [
  {
    heading: "What is CFA and Why Is It the Gold Standard in Finance?",
    content: `<p>The <strong>CFA (Chartered Financial Analyst)</strong> charter, awarded by <strong>CFA Institute</strong>, is the most respected and recognized investment management credential in the world. With over 190,000 charterholders across 160+ countries, the CFA designation signals deep expertise in financial analysis, portfolio management, and ethical practice.</p>
<p>CFA charterholders dominate roles in equity research, portfolio management, investment banking, risk management, and wealth management at the world's leading financial institutions — Goldman Sachs, JP Morgan, BlackRock, and more.</p>
<p><strong>Dalmia Academy brings CFA coaching to Indore</strong> — combining our 30+ years of financial education expertise with CFA Institute's rigorous, practice-based curriculum. No need to travel to Mumbai or Delhi for quality CFA preparation.</p>`,
  },
  {
    heading: "CFA Exam Structure — 3 Progressive Levels",
    content: `<p>The CFA Program has 3 levels, each progressively more challenging:</p>
<p><strong>Level I — Knowledge & Comprehension:</strong> 180 MCQs across two 2.25-hour sessions. Tests foundational knowledge across all 10 topic areas. Pass rate: ~35-45%. Focus areas: Ethics (highest weight), Financial Reporting & Analysis, and Quantitative Methods.</p>
<p><strong>Level II — Application & Analysis:</strong> Item set format (vignettes followed by MCQs). Tests your ability to apply concepts to real scenarios. Pass rate: ~40-50%. Focus areas: Equity Valuation, Fixed Income Analysis, Financial Reporting, and Ethics.</p>
<p><strong>Level III — Synthesis & Portfolio Management:</strong> Constructed response (essay) + item sets. Tests your ability to synthesize knowledge for portfolio construction and wealth management. Pass rate: ~50-55%. Focus: Portfolio Management, Asset Allocation, and IPS Writing.</p>
<p>Most candidates take <strong>2.5-4 years</strong> to complete all 3 levels. At Dalmia Academy, our structured study plans help you stay on track and pass each level efficiently.</p>`,
  },
  {
    heading: "CFA Eligibility & Charter Requirements",
    content: `<p><strong>Exam Eligibility:</strong> You need a Bachelor's degree (or be in the final year) OR have 4,000 hours of professional work experience OR a combination totalling 4 years. B.Com, BBA, MBA, CA, engineering — all qualify. You can register for Level I while still in your final year of graduation.</p>
<p><strong>Charter Requirements (after passing all 3 levels):</strong></p>
<p>1. <strong>4,000 hours of relevant work experience</strong> in investment decision-making (can be completed before, during, or after the exams)</p>
<p>2. <strong>CFA Institute membership</strong> and adherence to the Code of Ethics and Standards of Professional Conduct</p>
<p>3. <strong>Professional conduct references</strong> from 2-3 professional contacts</p>
<p>At Dalmia Academy, we provide <strong>complete guidance</strong> on exam registration, study planning, work experience documentation, and charter application — not just exam coaching.</p>`,
  },
];

const CFACoaching = () => {
  const seo = getPageSeo("/cfa-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/cfa-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/cfa-coaching" }),
          cfaCourseSchema,
          faqSchema(cfaContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "CFA Coaching in Indore", path: "/cfa-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <main>
        <HeroSection content={cfaContent.hero} />
        <WhyChooseSection
          heading={cfaContent.whyChoose.heading}
          subheading={cfaContent.whyChoose.subheading}
          benefits={cfaContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={cfaContent.courses.heading}
          subheading={cfaContent.courses.subheading}
          courses={cfaContent.courses.items}
        />
        <RichTextSection
          sectionHeading="Everything You Need to Know About CFA"
          blocks={cfaContentBlocks}
          lastUpdated="May 2026"
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={cfaContent.highlights.heading}
          subheading={cfaContent.highlights.subheading}
          highlights={cfaContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={cfaContent.leadForm.courseOptions} />
        <FAQSection faqs={cfaContent.faqs} />
        <FinalCTASection
          headline={cfaContent.finalCTA.headline}
          highlightText={cfaContent.finalCTA.highlightText}
          subheadline={cfaContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in CFA Coaching at Dalmia Academy, Indore. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in CFA Coaching at Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default CFACoaching;
