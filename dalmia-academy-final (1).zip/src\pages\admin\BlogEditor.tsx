import { useEffect, useState, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Save, Eye, Upload, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import RichTextEditor from "@/components/admin/RichTextEditor";
import SEOPanel from "@/components/admin/SEOPanel";

const categories = ["General", "News", "Tips", "Results", "Career Guidance", "Exam Updates"];

const slugify = (text: string) =>
  text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const estimateReadingTime = (html: string) => {
  const text = html.replace(/<[^>]*>/g, "");
  const words = text.split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(words / 200));
};

const BlogEditor = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isNew = !id;

  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [postId, setPostId] = useState<string | null>(id || null);
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [category, setCategory] = useState("General");
  const [published, setPublished] = useState(false);
  const [authorName, setAuthorName] = useState("Dalmia Academy");
  const [coverImageUrl, setCoverImageUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [autoSavedAt, setAutoSavedAt] = useState<string | null>(null);

  const [seoData, setSeoData] = useState({
    focus_keyword: "",
    meta_title: "",
    meta_description: "",
    meta_keywords: "",
    canonical_url: "",
    og_image_url: "",
    schema_type: "Article",
  });

  const dirtyRef = useRef(false);
  const lastSavedHashRef = useRef("");

  // Load existing post
  useEffect(() => {
    if (!id) return;
    const load = async () => {
      const { data, error } = await supabase.from("blog_posts").select("*").eq("id", id).maybeSingle();
      if (error || !data) {
        toast({ title: "Post not found", variant: "destructive" });
        navigate("/admin/blog");
        return;
      }
      setTitle(data.title);
      setSlug(data.slug);
      setContent(data.content || "");
      setExcerpt(data.excerpt || "");
      setCategory(data.category || "General");
      setPublished(data.published || false);
      setAuthorName((data as any).author_name || "Dalmia Academy");
      setCoverImageUrl(data.cover_image_url || "");
      setAutoSavedAt((data as any).auto_saved_at);
      setSeoData({
        focus_keyword: (data as any).focus_keyword || "",
        meta_title: (data as any).meta_title || "",
        meta_description: (data as any).meta_description || "",
        meta_keywords: (data as any).meta_keywords || "",
        canonical_url: (data as any).canonical_url || "",
        og_image_url: (data as any).og_image_url || "",
        schema_type: (data as any).schema_type || "Article",
      });
      setLoading(false);
    };
    load();
  }, [id]);

  const handleTitleChange = (val: string) => {
    setTitle(val);
    if (isNew && !postId) setSlug(slugify(val));
    dirtyRef.current = true;
  };

  const handleContentChange = useCallback((html: string) => {
    setContent(html);
    dirtyRef.current = true;
  }, []);

  const buildPayload = () => ({
    title,
    slug,
    content: content || null,
    excerpt: excerpt || null,
    category,
    published,
    cover_image_url: coverImageUrl || null,
    author_name: authorName,
    reading_time_minutes: estimateReadingTime(content),
    ...seoData,
    focus_keyword: seoData.focus_keyword || null,
    meta_title: seoData.meta_title || null,
    meta_description: seoData.meta_description || null,
    meta_keywords: seoData.meta_keywords || null,
    canonical_url: seoData.canonical_url || null,
    og_image_url: seoData.og_image_url || null,
    schema_type: seoData.schema_type || "Article",
  });

  const savePost = async (showToast = true, publish?: boolean) => {
    if (!title || !slug) {
      toast({ title: "Title and slug are required", variant: "destructive" });
      return;
    }
    setSaving(true);
    const payload: any = buildPayload();
    if (publish !== undefined) payload.published = publish;
    payload.auto_saved_at = new Date().toISOString();

    let error;
    if (postId) {
      ({ error } = await supabase.from("blog_posts").update(payload).eq("id", postId));
    } else {
      const res = await supabase.from("blog_posts").insert(payload).select("id").single();
      error = res.error;
      if (res.data) setPostId(res.data.id);
    }

    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }

    setAutoSavedAt(payload.auto_saved_at);
    if (publish !== undefined) setPublished(publish);
    dirtyRef.current = false;
    lastSavedHashRef.current = content;
    if (showToast) {
      toast({
        title: publish ? "Post published!" : publish === false ? "Moved to draft" : "Post saved",
      });
    }
  };

  // Auto-save every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (dirtyRef.current && title && slug && content !== lastSavedHashRef.current) {
        savePost(false);
      }
    }, 30000);
    return () => clearInterval(interval);
  }, [title, slug, content, postId]);

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `blog/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("blog-images").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    } else {
      const { data: urlData } = supabase.storage.from("blog-images").getPublicUrl(path);
      setCoverImageUrl(urlData.publicUrl);
      dirtyRef.current = true;
    }
    setUploading(false);
  };

  if (loading) {
    return <div className="p-8 text-muted-foreground">Loading editor...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Top Bar */}
      <div className="sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center justify-between gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate("/admin/blog")} className="gap-1">
          <ArrowLeft className="h-4 w-4" /> Posts
        </Button>
        <div className="flex items-center gap-2">
          {published ? (
            <Button variant="outline" size="sm" onClick={() => savePost(true, false)}>Move to Draft</Button>
          ) : (
            <Button variant="outline" size="sm" onClick={() => savePost(true)} disabled={saving}>
              <Save className="h-4 w-4 mr-1" /> Save Draft
            </Button>
          )}
          {slug && (
            <Button variant="outline" size="sm" asChild>
              <a href={`/blog/${slug}`} target="_blank" rel="noopener noreferrer">
                <Eye className="h-4 w-4 mr-1" /> Preview
              </a>
            </Button>
          )}
          <Button size="sm" onClick={() => savePost(true, true)} disabled={saving}>
            {published ? "Update" : "Publish"}
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-6 flex flex-col lg:flex-row gap-6">
        {/* Main Editor */}
        <div className="flex-1 min-w-0 space-y-4">
          <Input
            value={title}
            onChange={(e) => handleTitleChange(e.target.value)}
            placeholder="Post Title"
            className="text-2xl font-bold font-heading h-auto py-3 border-none shadow-none focus-visible:ring-0 bg-transparent px-0"
          />
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Slug:</span>
            <Input
              value={slug}
              onChange={(e) => { setSlug(e.target.value); dirtyRef.current = true; }}
              className="text-sm h-8"
            />
          </div>

          <RichTextEditor content={content} onChange={handleContentChange} />

          {autoSavedAt && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              Auto-saved {new Date(autoSavedAt).toLocaleString("en-IN", { hour: "2-digit", minute: "2-digit" })}
            </div>
          )}

          <SEOPanel data={seoData} onChange={(d) => { setSeoData(d); dirtyRef.current = true; }} slug={slug} postTitle={title} />
        </div>

        {/* Sidebar */}
        <div className="w-full lg:w-72 space-y-4 shrink-0">
          <div className="border border-border rounded-lg p-4 bg-card space-y-4">
            <div>
              <Label className="text-xs text-muted-foreground">Status</Label>
              <p className={`font-semibold text-sm ${published ? "text-green-600" : "text-amber-600"}`}>
                {published ? "Published" : "Draft"}
              </p>
            </div>

            <div>
              <Label>Category</Label>
              <Select value={category} onValueChange={(v) => { setCategory(v); dirtyRef.current = true; }}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Author Name</Label>
              <Input
                value={authorName}
                onChange={(e) => { setAuthorName(e.target.value); dirtyRef.current = true; }}
                className="mt-1"
              />
            </div>
          </div>

          <div className="border border-border rounded-lg p-4 bg-card space-y-3">
            <Label>Featured Image</Label>
            <label className="flex items-center gap-2 cursor-pointer text-sm text-primary hover:underline">
              <Upload className="h-4 w-4" />
              {uploading ? "Uploading..." : "Upload Image"}
              <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} disabled={uploading} />
            </label>
            {coverImageUrl && (
              <div className="relative">
                <img src={coverImageUrl} alt="Cover" className="w-full h-36 object-cover rounded" />
                <Button
                  variant="destructive"
                  size="sm"
                  className="absolute top-1 right-1 h-6 text-xs"
                  onClick={() => { setCoverImageUrl(""); dirtyRef.current = true; }}
                >
                  Remove
                </Button>
              </div>
            )}
          </div>

          <div className="border border-border rounded-lg p-4 bg-card space-y-2">
            <Label>Excerpt</Label>
            <Textarea
              value={excerpt}
              onChange={(e) => { setExcerpt(e.target.value); dirtyRef.current = true; }}
              rows={3}
              placeholder="Brief summary for listings..."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogEditor;
