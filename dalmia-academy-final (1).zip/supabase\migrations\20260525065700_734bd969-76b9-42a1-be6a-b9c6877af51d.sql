
-- Restrict trigger function from being called directly via API
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon, authenticated, public;

-- Remove broad SELECT policy that allows listing files in the public blog-images bucket.
-- Public bucket URLs continue to serve files directly without needing this policy.
DROP POLICY IF EXISTS "Anyone can view blog images" ON storage.objects;
