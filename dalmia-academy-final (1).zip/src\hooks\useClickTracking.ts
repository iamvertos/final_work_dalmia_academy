import { supabase } from "@/integrations/supabase/client";
import { pushClick } from "@/lib/gtm";

const getUtmParams = () => {
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: params.get("utm_source") || null,
    utm_medium: params.get("utm_medium") || null,
    utm_campaign: params.get("utm_campaign") || null,
    utm_content: params.get("utm_content") || null,
    utm_term: params.get("utm_term") || null,
  };
};

export const trackClick = (eventType: "phone_click" | "whatsapp_click", sourceComponent: string) => {
  const utmParams = getUtmParams();
  // Push to GTM dataLayer so tags (Ads, Meta, GA4) can fire from a single source.
  pushClick({ type: eventType, source: sourceComponent });
  // Fire and forget — don't block user navigation
  supabase.from("click_events").insert({
    event_type: eventType,
    page_url: window.location.pathname,
    source_component: sourceComponent,
    ...utmParams,
  }).then(() => {});
};
