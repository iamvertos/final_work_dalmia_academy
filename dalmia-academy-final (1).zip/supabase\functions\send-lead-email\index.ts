const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const lead = await req.json();
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (!resendApiKey) {
      return new Response(JSON.stringify({ error: 'RESEND_API_KEY not configured' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    const extraRows = lead.extra && typeof lead.extra === 'object' ? `
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Child Class</td><td style="padding:8px;border:1px solid #ddd;">${lead.extra.child_class || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Batch Preference</td><td style="padding:8px;border:1px solid #ddd;">${lead.extra.batch_preference || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">City</td><td style="padding:8px;border:1px solid #ddd;">${lead.extra.city || '-'}</td></tr>
    ` : '';

    const html = `
      <h2>🎓 New Lead from Dalmia Academy Website</h2>
      <table style="border-collapse:collapse;width:100%;max-width:500px;">
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Name</td><td style="padding:8px;border:1px solid #ddd;">${lead.name || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Phone</td><td style="padding:8px;border:1px solid #ddd;">${lead.phone || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Email</td><td style="padding:8px;border:1px solid #ddd;">${lead.email || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Course</td><td style="padding:8px;border:1px solid #ddd;">${lead.course_interested || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Source</td><td style="padding:8px;border:1px solid #ddd;">${lead.source || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Page</td><td style="padding:8px;border:1px solid #ddd;">${lead.page_url || '-'}</td></tr>
        ${extraRows}
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">UTM Source</td><td style="padding:8px;border:1px solid #ddd;">${lead.utm_source || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">UTM Medium</td><td style="padding:8px;border:1px solid #ddd;">${lead.utm_medium || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">UTM Campaign</td><td style="padding:8px;border:1px solid #ddd;">${lead.utm_campaign || '-'}</td></tr>
        <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">Submitted At</td><td style="padding:8px;border:1px solid #ddd;">${timestamp}</td></tr>
      </table>
    `;

    const emailPayload: Record<string, unknown> = {
      from: 'Dalmia Academy <onboarding@resend.dev>',
      to: ['dalmiaacademy.sm@gmail.com'],
      // CC and BCC require a verified domain on Resend.
      // Once you verify your domain at resend.com/domains, uncomment these
      // and update the 'from' address to use your verified domain:
      // cc: ['Pramoddalmia1966@gmail.com'],
      // bcc: ['marketingvertos@gmail.com'],
      subject: `New Lead: ${lead.name || 'Unknown'} — ${lead.course_interested || 'General'}`,
      html,
    };

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailPayload),
    });

    const data = await res.json();

    if (!res.ok) {
      console.error('Resend error:', data);
      return new Response(JSON.stringify({ error: data }), {
        status: res.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ success: true, id: data.id }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('send-lead-email error:', err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
