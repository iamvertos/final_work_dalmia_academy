import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, Search, Phone } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";
import { format } from "date-fns";

const SummerLeads = () => {
  const [leads, setLeads] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("summer_leads" as any)
        .select("*")
        .order("created_at", { ascending: false });
      setLeads((data as any) || []);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return leads;
    return leads.filter(
      (l) =>
        (l.parent_name || "").toLowerCase().includes(q) ||
        (l.child_name || "").toLowerCase().includes(q) ||
        (l.phone || "").includes(q),
    );
  }, [leads, search]);

  const exportCSV = () => {
    const headers = [
      "Date",
      "Parent Name",
      "Child Name",
      "Class",
      "Phone",
      "Activity",
      "Batch",
      "City",
      "Source",
      "UTM Source",
      "UTM Medium",
      "UTM Campaign",
    ];
    const rows = filtered.map((l) => [
      format(new Date(l.created_at), "yyyy-MM-dd HH:mm"),
      l.parent_name,
      l.child_name,
      l.class_grade,
      l.phone,
      l.activity,
      l.batch_preference,
      l.city,
      l.source || "",
      l.utm_source || "",
      l.utm_medium || "",
      l.utm_campaign || "",
    ]);
    const csv = [headers, ...rows]
      .map((r) => r.map((c: any) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `summer-leads-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-heading font-bold">Summer Camp Registrations</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} entries</p>
        </div>
        <Button variant="outline" size="sm" onClick={exportCSV}>
          <Download className="h-4 w-4 mr-1" /> Export CSV
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by parent name, child name, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {loading ? (
        <p className="text-muted-foreground">Loading...</p>
      ) : (
        <div className="rounded-lg border border-border overflow-x-auto bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Parent</TableHead>
                <TableHead>Child</TableHead>
                <TableHead>Class</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead className="hidden md:table-cell">Activity</TableHead>
                <TableHead className="hidden md:table-cell">Batch</TableHead>
                <TableHead className="hidden lg:table-cell">City</TableHead>
                <TableHead className="hidden lg:table-cell">Source</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                    No registrations yet
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-xs whitespace-nowrap">
                      {format(new Date(l.created_at), "MMM dd, HH:mm")}
                    </TableCell>
                    <TableCell className="font-medium">{l.parent_name}</TableCell>
                    <TableCell>{l.child_name}</TableCell>
                    <TableCell>{l.class_grade}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:+91${l.phone}`}
                          className="text-primary hover:underline flex items-center gap-1"
                          title="Call"
                        >
                          <Phone className="h-3.5 w-3.5" />
                          {l.phone}
                        </a>
                        <a
                          href={`https://wa.me/91${l.phone}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-green-600 hover:text-green-700"
                          title="WhatsApp"
                        >
                          <WhatsAppIcon className="h-4 w-4" />
                        </a>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{l.activity}</TableCell>
                    <TableCell className="hidden md:table-cell">{l.batch_preference}</TableCell>
                    <TableCell className="hidden lg:table-cell">{l.city}</TableCell>
                    <TableCell className="hidden lg:table-cell text-xs">
                      {l.utm_source ? `${l.utm_source}/${l.utm_medium || "-"}` : l.source}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default SummerLeads;