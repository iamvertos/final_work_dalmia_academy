import mentorPhoto from "@/assets/dalmia-sir-photo.webp";

const MentorSection = () => {
  return (
    <section className="py-14 md:py-20 bg-muted" id="mentor">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-10">
          Meet Your Mentor
        </h2>

        <div className="flex flex-col md:flex-row items-center gap-8 max-w-4xl mx-auto">
          <div className="w-48 h-48 md:w-56 md:h-56 rounded-2xl overflow-hidden shadow-lg border-4 border-accent/30 flex-shrink-0">
            <img
              src={mentorPhoto}
              alt="Dalmia Sir — CUET Mentor at Dalmia Academy Indore"
              width={224}
              height={224}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>

          <div>
            <h3 className="text-xl md:text-2xl font-bold font-heading text-foreground mb-2">
              Dalmia Sir
            </h3>
            <p className="text-secondary font-semibold mb-4">Founder & Lead Mentor, Dalmia Academy</p>
            <p className="text-muted-foreground leading-relaxed mb-3">
              With over a decade of experience in coaching Commerce and Science students, Dalmia Sir has
              guided hundreds of students toward academic success. His concept-based teaching philosophy
              ensures every student builds a strong foundation — not just for CUET, but for their entire
              academic career.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Under his mentorship, students develop clarity, confidence, and exam readiness through
              structured preparation, regular assessments, and personal attention that sets Dalmia Academy
              apart from the rest.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MentorSection;
