import type { BenefitItem } from "@/data/pageContent";

interface WhyChooseSectionProps {
  heading?: string;
  subheading?: string;
  benefits?: BenefitItem[];
}

const WhyChooseSection = ({
  heading = "Why Choose Dalmia Academy for CUET?",
  subheading = "The best CUET coaching in Indore with a proven approach to help students succeed",
  benefits,
}: WhyChooseSectionProps) => {
  const defaultBenefits: BenefitItem[] = [];
  const items = benefits ?? defaultBenefits;

  return (
    <section className="py-14 md:py-20 bg-muted" id="why-choose">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          {heading}
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          {subheading}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {items.map((b) => (
            <div
              key={b.title}
              className="bg-card rounded-lg p-6 shadow-sm border border-border hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 rounded-lg bg-secondary/15 flex items-center justify-center mb-4">
                <b.icon className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="text-lg font-semibold font-heading text-foreground mb-2">{b.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseSection;
