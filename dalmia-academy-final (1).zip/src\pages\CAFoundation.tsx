import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import RichTextSection from "@/components/RichTextSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { caFoundationContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";

import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const caCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/ca-foundation#course",
  name: "CA Foundation & CSEET Coaching",
  description:
    "Structured coaching for CA Foundation and CS Executive Entrance Test (CSEET) aspirants at Dalmia Academy, Indore. 30+ years of proven results with concept-based teaching, strategic mock tests, and personalized one-on-one mentorship for first-attempt success.",
  url: "https://dalmiaacademy.com/ca-foundation",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "ProfessionalCertificate",
  teaches: [
    "Accounting",
    "Business Law",
    "Economics",
    "Quantitative Aptitude",
    "Business Environment & Law",
    "Business Management",
    "Accounting Fundamentals",
  ],
  coursePrerequisites: "Class 12 pass or appearing (Commerce stream preferred)",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "CA Foundation Coaching",
      description:
        "Complete preparation for CA Foundation with concept clarity, ICAI-pattern mock tests, previous year papers, and expert mentorship for first-attempt success. Covers Accounting, Law, Economics, and Quantitative Aptitude.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
      instructor: {
        "@type": "Person",
        name: "Pramod Dalmia",
        jobTitle: "Founder & Academic Mentor",
      },
    },
    {
      "@type": "CourseInstance",
      name: "CSEET (CS Foundation) Coaching",
      description:
        "Comprehensive CSEET preparation with structured study plans and regular ICSI-pattern practice tests. Covers Business Environment & Law, Business Management, Economics, and Accounting Fundamentals.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  about: [
    { "@type": "Thing", name: "Chartered Accountancy" },
    { "@type": "Thing", name: "CA Foundation Exam" },
    { "@type": "Thing", name: "CSEET" },
    { "@type": "Thing", name: "Company Secretary" },
    { "@type": "Thing", name: "Professional Exam Coaching" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/ca-foundation",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "5",
    reviewCount: "8",
    bestRating: "5",
    worstRating: "1",
  },
};

const caContentBlocks = [
  {
    heading: "CA Foundation Syllabus Breakdown — What We Cover",
    content: `<p>The CA Foundation exam conducted by ICAI consists of four papers. At Dalmia Academy, each paper is taught by a specialist faculty member with decades of experience in CA coaching in Indore:</p>
<p><strong>Paper 1 — Accounting:</strong> Financial Statements of Sole Proprietors, Partnership Firms, and Companies. Covers Journal Entries, Ledger, Trial Balance, Depreciation, Bank Reconciliation, Rectification of Errors, and Company Final Accounts. Taught by faculty with 35+ years of Accountancy expertise.</p>
<p><strong>Paper 2 — Business Law:</strong> Indian Contract Act, Sale of Goods Act, Indian Partnership Act, Companies Act 2013, LLP Act, and Negotiable Instruments Act. Our faculty uses real case studies and practical scenarios to make law concepts easy to retain.</p>
<p><strong>Paper 3 — Business Economics & Business and Commercial Knowledge:</strong> Micro Economics (demand, supply, production, cost), Macro Economics (national income, money & banking, fiscal policy), and Business & Commercial Knowledge covering business environment, organizations, and government policies.</p>
<p><strong>Paper 4 — Quantitative Aptitude:</strong> Business Mathematics (ratio, proportion, equations, logarithms), Logical Reasoning (number series, direction tests, seating arrangements), and Statistics (measures of central tendency, dispersion, correlation, regression, probability).</p>`,
  },
  {
    heading: "Our Study Pattern & Methodology",
    content: `<p>What sets Dalmia Academy apart from other CA coaching classes in Indore is our structured three-phase methodology:</p>
<p><strong>Phase 1 — Concept Building (60% of course):</strong> Every chapter is taught from scratch with real-life examples. We don't assume prior knowledge. Faculty with 25-35+ years of teaching experience break down complex topics into simple, digestible modules. Each session ends with a quick recap and Q&A.</p>
<p><strong>Phase 2 — Practice & Mock Tests (30% of course):</strong> Students solve ICAI previous year papers (10+ years), RTPs (Revision Test Papers), and MTPs (Mock Test Papers) under timed, exam-like conditions. Every test is followed by individual performance analysis showing chapter-wise strengths and weaknesses.</p>
<p><strong>Phase 3 — Revision & Exam Strategy (10% of course):</strong> Three structured revision rounds before each exam attempt. Quick-reference summary sheets for every chapter. Time management strategies for the actual exam — how much time per question, which sections to attempt first, and how to maximize marks in the last 30 minutes.</p>`,
  },
  {
    heading: "Batch Information & Modes",
    content: `<p><strong>Batch Size:</strong> Strictly limited to 25 students per batch. This is a core principle at Dalmia Academy — we believe CA Foundation coaching requires individual attention, which large batches of 50-100 students simply cannot provide.</p>
<p><strong>Mode:</strong> Offline classroom coaching at our Indore centre. All classes are conducted in-person at 108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Road, Indore 452001. We believe face-to-face interaction with faculty is essential for CA Foundation success.</p>
<p><strong>Timings:</strong> Morning and evening batches available to accommodate students also preparing for Class 12 board exams or attending college. Weekend doubt-clearing sessions are available.</p>
<p><strong>Language:</strong> Bilingual instruction in Hindi and English, ensuring concepts are crystal clear regardless of the student's medium of schooling.</p>`,
  },
  {
    heading: "Why Indore Students Choose Dalmia Over Out-of-City CA Coaching",
    content: `<p>Many coaching institutes ranking for "CA coaching in Indore" are actually based in Jaipur, Bangalore, or Gurgaon — offering online classes or franchise models with no real Indore presence. Here's why that matters and why Indore students prefer Dalmia Academy:</p>
<p><strong>Real classroom, real faculty:</strong> Our faculty physically teaches at our Geeta Bhawan Square centre. Students can walk in for doubt clearing after class, during breaks, or even on weekends. This personal access is impossible with out-of-city online institutes.</p>
<p><strong>Local support network:</strong> Being in Indore since 1991, we understand the academic ecosystem here — board exam schedules, college timings, and the specific challenges Indore students face. Our study plans are tailored to local realities.</p>
<p><strong>Proven local results:</strong> Our 90%+ first-attempt pass rate comes from students who studied right here in Indore. These aren't national statistics from a franchise network — they're results from our Tulsi Tower centre.</p>
<p><strong>Convenient location:</strong> Located at Geeta Bhawan Square on AB Road, Dalmia Academy is easily accessible from Vijay Nagar, Palasia, Sapna Sangeeta, New Palasia, Bhawarkua, and other central Indore areas.</p>`,
  },
  {
    heading: "Fee Structure & How to Join",
    content: `<p>Dalmia Academy offers competitive and transparent fee structures for CA Foundation and CSEET coaching in Indore. Our fees are affordable compared to large chain institutes, with the added advantage of small batches and personal mentorship.</p>
<p><strong>Flexible payment options</strong> are available. We believe financial constraints should never stop a deserving student from pursuing CA.</p>
<p><strong>To enquire about fees and current batch schedule:</strong></p>
<p>Call: <strong>+91-95757-76655</strong> or <strong>+91-91091-09651</strong><br/>
Visit: 108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Road, Indore 452001<br/>
Or simply fill out the enquiry form on this page — our counsellor will call you within 24 hours.</p>
<p><strong>Free demo classes</strong> are available for all new students. Experience our teaching methodology before you commit.</p>`,
  },
];

const CAFoundation = () => {
  const seo = getPageSeo("/ca-foundation");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/ca-foundation"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/ca-foundation" }),
          caCourseSchema,
          faqSchema(caFoundationContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "CA Coaching in Indore", path: "/ca-foundation" },
          ]),
        ]}
      />

      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={caFoundationContent.hero} />
        <WhyChooseSection
          heading={caFoundationContent.whyChoose.heading}
          subheading={caFoundationContent.whyChoose.subheading}
          benefits={caFoundationContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={caFoundationContent.courses.heading}
          subheading={caFoundationContent.courses.subheading}
          courses={caFoundationContent.courses.items}
        />
        <RichTextSection
          sectionHeading="Everything You Need to Know About CA Coaching in Indore"
          blocks={caContentBlocks}
          lastUpdated="May 2026"
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={caFoundationContent.highlights.heading}
          subheading={caFoundationContent.highlights.subheading}
          highlights={caFoundationContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={caFoundationContent.leadForm.courseOptions} />
        <FAQSection faqs={caFoundationContent.faqs} />
        <FinalCTASection
          headline={caFoundationContent.finalCTA.headline}
          highlightText={caFoundationContent.finalCTA.highlightText}
          subheadline={caFoundationContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in CA / CS Foundation Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in CA / CS Foundation Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default CAFoundation;
