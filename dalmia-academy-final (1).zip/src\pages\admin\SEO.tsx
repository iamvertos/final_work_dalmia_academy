import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Play, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

type ChecklistItem = {
  id: string;
  key: string;
  label: string;
  description: string | null;
  category: string;
  severity: string;
  sort_order: number;
  status: string;
  notes: string | null;
};

type Scan = {
  id: string;
  started_at: string;
  finished_at: string | null;
  status: string;
  total_routes: number;
  passed: number;
  failed: number;
  warnings: number;
};

const severityColor = (sev: string) =>
  sev === "high" ? "destructive" : sev === "medium" ? "default" : sev === "low" ? "secondary" : "outline";

const SEOPage = () => {
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [scans, setScans] = useState<Scan[]>([]);
  const [running, setRunning] = useState(false);

  const loadAll = async () => {
    const [{ data: c }, { data: s }] = await Promise.all([
      supabase.from("seo_checklist_items").select("*").order("sort_order"),
      supabase.from("seo_scans").select("*").order("started_at", { ascending: false }).limit(20),
    ]);
    setItems(c ?? []);
    setScans(s ?? []);
  };

  useEffect(() => { loadAll(); }, []);

  const toggleStatus = async (item: ChecklistItem) => {
    const next = item.status === "done" ? "todo" : "done";
    setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, status: next } : i)));
    const { error } = await supabase.from("seo_checklist_items").update({ status: next }).eq("id", item.id);
    if (error) toast({ title: "Update failed", description: error.message, variant: "destructive" });
  };

  const saveNotes = async (item: ChecklistItem, notes: string) => {
    setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, notes } : i)));
    await supabase.from("seo_checklist_items").update({ notes }).eq("id", item.id);
  };

  const runAudit = async () => {
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke("seo-audit-run", { body: {} });
      if (error) throw error;
      toast({ title: "Audit complete", description: `${data.passed} pass · ${data.warnings} warn · ${data.failed} fail` });
      await loadAll();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast({ title: "Audit failed", description: msg, variant: "destructive" });
    } finally {
      setRunning(false);
    }
  };

  const grouped = items.reduce<Record<string, ChecklistItem[]>>((acc, i) => {
    (acc[i.category] ||= []).push(i);
    return acc;
  }, {});
  const doneCount = items.filter((i) => i.status === "done").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Technical SEO</h1>
          <p className="text-muted-foreground text-sm">Checklist, automated audit, and AI recommendations.</p>
        </div>
        <Button onClick={runAudit} disabled={running}>
          {running ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Play className="h-4 w-4 mr-2" />}
          {running ? "Auditing…" : "Run audit"}
        </Button>
      </div>

      <Tabs defaultValue="checklist">
        <TabsList>
          <TabsTrigger value="checklist">Checklist ({doneCount}/{items.length})</TabsTrigger>
          <TabsTrigger value="audit">Latest Audit</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="checklist" className="space-y-4 mt-4">
          {Object.entries(grouped).map(([cat, list]) => (
            <Card key={cat}>
              <CardHeader><CardTitle className="text-base">{cat}</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {list.map((item) => (
                  <div key={item.id} className="flex items-start gap-3 pb-3 border-b last:border-0">
                    <Checkbox
                      checked={item.status === "done"}
                      onCheckedChange={() => toggleStatus(item)}
                      className="mt-1"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`font-medium text-sm ${item.status === "done" ? "line-through text-muted-foreground" : ""}`}>
                          {item.label}
                        </span>
                        <Badge variant={severityColor(item.severity) as any} className="text-xs">{item.severity}</Badge>
                      </div>
                      {item.description && (
                        <p className="text-xs text-muted-foreground mt-1">{item.description}</p>
                      )}
                      <Textarea
                        placeholder="Notes…"
                        defaultValue={item.notes ?? ""}
                        onBlur={(e) => {
                          if (e.target.value !== (item.notes ?? "")) saveNotes(item, e.target.value);
                        }}
                        className="mt-2 min-h-[60px] text-xs"
                      />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="audit" className="mt-4">
          <LatestScanCard scan={scans[0]} />
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Scan History</CardTitle></CardHeader>
            <CardContent>
              {scans.length === 0 ? (
                <p className="text-sm text-muted-foreground">No scans yet. Click "Run audit" to start.</p>
              ) : (
                <div className="divide-y">
                  {scans.map((s) => (
                    <Link
                      key={s.id}
                      to={`/admin/seo/scans/${s.id}`}
                      className="flex items-center justify-between py-3 hover:bg-muted/50 px-2 -mx-2 rounded"
                    >
                      <div>
                        <div className="text-sm font-medium">{format(new Date(s.started_at), "PPp")}</div>
                        <div className="text-xs text-muted-foreground">
                          {s.total_routes} routes · {s.passed} pass · {s.warnings} warn · {s.failed} fail
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={s.status === "complete" ? "default" : s.status === "failed" ? "destructive" : "secondary"}>
                          {s.status}
                        </Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

const LatestScanCard = ({ scan }: { scan?: Scan }) => {
  if (!scan) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          No audit run yet. Click "Run audit" above to scan the live site.
        </CardContent>
      </Card>
    );
  }
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center justify-between">
          <span>Latest scan · {format(new Date(scan.started_at), "PPp")}</span>
          <Link to={`/admin/seo/scans/${scan.id}`}>
            <Button size="sm" variant="outline">View details</Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-4 text-center">
          <Stat label="Routes" value={scan.total_routes} />
          <Stat label="Passed" value={scan.passed} tone="text-green-600" />
          <Stat label="Warnings" value={scan.warnings} tone="text-amber-600" />
          <Stat label="Failed" value={scan.failed} tone="text-destructive" />
        </div>
      </CardContent>
    </Card>
  );
};

const Stat = ({ label, value, tone }: { label: string; value: number; tone?: string }) => (
  <div>
    <div className={`text-2xl font-bold ${tone ?? ""}`}>{value}</div>
    <div className="text-xs text-muted-foreground">{label}</div>
  </div>
);

export default SEOPage;