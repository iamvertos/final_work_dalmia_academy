import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Search } from "lucide-react";
import { useState } from "react";

interface SEOData {
  focus_keyword: string;
  meta_title: string;
  meta_description: string;
  meta_keywords: string;
  canonical_url: string;
  og_image_url: string;
  schema_type: string;
}

interface SEOPanelProps {
  data: SEOData;
  onChange: (data: SEOData) => void;
  slug: string;
  postTitle: string;
}

const SEOPanel = ({ data, onChange, slug, postTitle }: SEOPanelProps) => {
  const [isOpen, setIsOpen] = useState(false);

  const update = (key: keyof SEOData, value: string) => {
    onChange({ ...data, [key]: value });
  };

  const displayTitle = data.meta_title || postTitle || "Post Title";
  const displayDesc = data.meta_description || "Add a meta description for better SEO...";
  const displayUrl = `dalmia-academy.lovable.app/blog/${slug || "your-post-slug"}`;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="border border-border rounded-lg bg-card">
      <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
        <div className="flex items-center gap-2">
          <Search className="h-5 w-5 text-primary" />
          <span className="font-semibold text-foreground">SEO Settings</span>
        </div>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </CollapsibleTrigger>
      <CollapsibleContent className="px-4 pb-4 space-y-4">
        {/* Google Preview */}
        <div className="border border-border rounded-lg p-4 bg-background">
          <p className="text-xs text-muted-foreground mb-2 font-medium">Google Search Preview</p>
          <div className="space-y-0.5">
            <p className="text-sm text-green-700 truncate">{displayUrl}</p>
            <p className="text-lg text-blue-700 font-medium truncate leading-tight">{displayTitle}</p>
            <p className="text-sm text-muted-foreground line-clamp-2">{displayDesc}</p>
          </div>
        </div>

        <div>
          <Label>Focus Keyword</Label>
          <Input
            value={data.focus_keyword}
            onChange={(e) => update("focus_keyword", e.target.value)}
            placeholder="e.g. CUET coaching Indore"
          />
        </div>

        <div>
          <div className="flex justify-between items-center mb-1">
            <Label>Meta Title</Label>
            <span className={`text-xs ${(data.meta_title?.length || 0) > 60 ? "text-destructive" : "text-muted-foreground"}`}>
              {data.meta_title?.length || 0}/60
            </span>
          </div>
          <Input
            value={data.meta_title}
            onChange={(e) => update("meta_title", e.target.value)}
            placeholder={postTitle || "Custom title for search engines"}
          />
        </div>

        <div>
          <div className="flex justify-between items-center mb-1">
            <Label>Meta Description</Label>
            <span className={`text-xs ${(data.meta_description?.length || 0) > 160 ? "text-destructive" : "text-muted-foreground"}`}>
              {data.meta_description?.length || 0}/160
            </span>
          </div>
          <Textarea
            value={data.meta_description}
            onChange={(e) => update("meta_description", e.target.value)}
            placeholder="Brief description for search results..."
            rows={3}
          />
        </div>

        <div>
          <Label>Meta Keywords</Label>
          <Input
            value={data.meta_keywords}
            onChange={(e) => update("meta_keywords", e.target.value)}
            placeholder="keyword1, keyword2, keyword3"
          />
        </div>

        <div>
          <Label>Canonical URL</Label>
          <Input
            value={data.canonical_url}
            onChange={(e) => update("canonical_url", e.target.value)}
            placeholder="https://dalmia-academy.lovable.app/blog/..."
          />
        </div>

        <div>
          <Label>OG Image URL</Label>
          <Input
            value={data.og_image_url}
            onChange={(e) => update("og_image_url", e.target.value)}
            placeholder="Leave empty to use featured image"
          />
        </div>

        <div>
          <Label>Schema Type</Label>
          <Select value={data.schema_type || "Article"} onValueChange={(v) => update("schema_type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Article">Article</SelectItem>
              <SelectItem value="BlogPosting">BlogPosting</SelectItem>
              <SelectItem value="NewsArticle">NewsArticle</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default SEOPanel;
