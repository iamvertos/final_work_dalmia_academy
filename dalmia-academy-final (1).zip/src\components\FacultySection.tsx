import pramodPhoto from "@/assets/dalmia-sir-photo.webp";
import mekhalaPhoto from "@/assets/Mekhala_Kanade.webp";
import rashmiPhoto from "@/assets/Rashmi_Pawar.webp";
import sunilPhoto from "@/assets/Sunil_Jain.webp";
import rakeshPhoto from "@/assets/Rakesh_Thakur.webp";
import ajayPhoto from "@/assets/Ajay_Bagodiya.webp";
import nidhiPhoto from "@/assets/Nidhi_Ghosh.webp";
import mohiniPhoto from "@/assets/Mohini_Ojha.webp";
import anandPhoto from "@/assets/Anand_Potdar.webp";
import { Badge } from "@/components/ui/badge";

const faculty = [
  {
    name: "Pramod Dalmia",
    subject: "Accounts & Economics",
    experience: "35+ Years",
    role: "Founder & Academic Mentor",
    photo: pramodPhoto,
    featured: true,
    highlights: [
      "Strong foundation for CA & Commerce",
      "Focus on analytical thinking",
      "Personal attention to every student",
    ],
  },
  {
    name: "Nidhi Ghosh",
    subject: "History & Political Science",
    experience: "7+ Years",
    role: "Senior Faculty",
    photo: nidhiPhoto,
    highlights: ["Engaging conceptual teaching", "Strong exam-oriented approach"],
  },
  {
    name: "Mohini Ojha",
    subject: "Geography",
    experience: "15+ Years",
    role: "Senior Faculty",
    photo: mohiniPhoto,
    highlights: ["In-depth conceptual clarity", "Exam-oriented teaching methodology"],
  },
  {
    name: "Anand Potdar",
    subject: "Spoken English, Communication Coach",
    experience: "20+ Years",
    role: "Senior Faculty",
    photo: anandPhoto,
    highlights: ["Communication skills development", "Fluency-focused training"],
  },
  {
    name: "Mekhala Kanade",
    subject: "Accountancy",
    experience: "25+ Years",
    role: "Senior Faculty",
    photo: mekhalaPhoto,
    highlights: ["Board-focused preparation", "Step-by-step explanation"],
  },
  {
    name: "Rashmi Pawar",
    subject: "Economics",
    experience: "29+ Years",
    role: "Senior Faculty",
    photo: rashmiPhoto,
    highlights: ["Strong macro & micro foundation", "Graph-based explanation"],
  },
  {
    name: "Sunil Jain",
    subject: "Mathematics",
    experience: "28+ Years",
    role: "Senior Faculty",
    photo: sunilPhoto,
    highlights: ["Concept clarity before formulas", "Practice-based learning"],
  },
  {
    name: "Rakesh Thakur",
    subject: "Accountancy",
    experience: "36+ Years",
    role: "Senior Academician",
    photo: rakeshPhoto,
    highlights: ["Comprehensive subject coverage", "Regular testing & evaluation"],
  },
  {
    name: "Ajay Bagodiya",
    subject: "Business Law",
    experience: "35+ Years",
    role: "Senior Advocate",
    photo: ajayPhoto,
    highlights: ["Practical case-based teaching", "Strong exam application focus"],
  },
];

const FacultySection = () => {
  return (
    <section className="py-14 md:py-20" id="faculty">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          Meet Our Expert Faculty
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          Learn from mentors who build strong foundations — 25–36+ years of teaching expertise
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {faculty.map((f) => (
            <div
              key={f.name}
              className={`bg-card rounded-xl border-2 overflow-hidden shadow-sm hover:shadow-lg transition-all ${
                f.featured ? "border-accent/50 ring-2 ring-accent/20" : "border-border"
              }`}
            >
              <div className="flex items-center gap-4 p-5">
                <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 border-2 border-accent/20">
                  <img
                    src={f.photo}
                    alt={`${f.name} — ${f.subject} Faculty at Dalmia Academy`}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div>
                  <h3 className="font-bold font-heading text-foreground text-base">
                    {f.name}
                  </h3>
                  <Badge variant="secondary" className="text-[10px] mb-1">
                    {f.subject}
                  </Badge>
                  <p className="text-xs text-muted-foreground">{f.role}</p>
                </div>
              </div>

              <div className="px-5 pb-5">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs font-semibold text-secondary">{f.experience} Experience</span>
                  {f.featured && (
                    <Badge className="bg-accent text-accent-foreground text-[10px]">Founder</Badge>
                  )}
                </div>
                <ul className="space-y-1">
                  {f.highlights.map((h) => (
                    <li key={h} className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <span className="text-secondary mt-0.5">✔</span>
                      {h}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FacultySection;
