import { Phone, Menu, X, ChevronDown, ChevronRight } from "lucide-react";
import { trackClick } from "@/hooks/useClickTracking";
import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import logo from "@/assets/dalmia-academy-logo.webp";

const courseLinks = [
  { label: "Humanities 11th & 12th", path: "/humanities-coaching" },
  { label: "Commerce 11th & 12th", path: "/commerce-coaching" },
  { label: "CA / CS Foundation", path: "/ca-foundation" },
  { label: "IPMAT & CUET-UG", path: "/cuet-coaching" },
  { label: "6th–10th All Subjects", path: "/school-coaching" },
  { label: "Spoken English", path: "/spoken-english" },
  { label: "ACCA", path: "/acca-coaching" },
  { label: "US CMA", path: "/us-cma-coaching" },
  { label: "US CPA", path: "/us-cpa-coaching" },
  { label: "CFA", path: "/cfa-coaching" },
];

const mainLinks = [
  { label: "Home", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Results", path: "/results" },
  { label: "Blog", path: "/blog" },
  
  { label: "Contact", path: "/contact" },
];

const StickyHeader = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [coursesOpen, setCoursesOpen] = useState(false);
  const [desktopDropdown, setDesktopDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();
  const location = useLocation();

  const isCoursePage = courseLinks.some((c) => c.path === location.pathname);

  // Close desktop dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDesktopDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleMouseEnter = () => {
    clearTimeout(timeoutRef.current);
    setDesktopDropdown(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setDesktopDropdown(false), 200);
  };

  const linkClass = (path: string) =>
    `px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
      location.pathname === path
        ? "bg-primary/10 text-primary font-semibold"
        : "text-muted-foreground hover:text-foreground hover:bg-muted"
    }`;

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <img src={logo} alt="Dalmia Academy Logo" width={192} height={48} loading="eager" fetchPriority="high" className="h-10 md:h-12 w-auto" />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {/* Home */}
          <Link to="/" className={linkClass("/")}>Home</Link>

          {/* Courses dropdown */}
          <div
            ref={dropdownRef}
            className="relative"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <button
              onClick={() => setDesktopDropdown(!desktopDropdown)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors inline-flex items-center gap-1 ${
                isCoursePage
                  ? "bg-primary/10 text-primary font-semibold"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              Courses
              <ChevronDown className={`h-3.5 w-3.5 transition-transform ${desktopDropdown ? "rotate-180" : ""}`} />
            </button>

            {desktopDropdown && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-popover border border-border rounded-lg shadow-lg z-[60] py-2">
                {courseLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setDesktopDropdown(false)}
                    className={`block px-4 py-2.5 text-sm transition-colors ${
                      location.pathname === link.path
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-popover-foreground hover:bg-muted"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* About, Results, Contact */}
          {mainLinks.slice(1).map((link) => (
            <Link key={link.path} to={link.path} className={linkClass(link.path)}>
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2 md:gap-3">
          <a
            href="tel:+919575776655"
            onClick={() => trackClick("phone_click", "sticky_header")}
            className="hidden md:flex items-center gap-2 text-primary font-semibold font-heading text-sm"
          >
            <Phone className="h-4 w-4" />
            +91 95757 76655
          </a>
          <Button
            asChild
            className="hidden sm:inline-flex bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-semibold text-sm"
          >
            <a href="#lead-form">Book Free Demo</a>
          </Button>
          <button
            className="lg:hidden p-2 text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <nav className="lg:hidden border-t border-border bg-background px-4 pb-4">
          <Link
            to="/"
            onClick={() => setMobileOpen(false)}
            className={`block py-2.5 text-sm font-medium border-b border-border/50 ${
              location.pathname === "/" ? "text-primary font-semibold" : "text-muted-foreground"
            }`}
          >
            Home
          </Link>

          {/* Mobile Courses collapsible */}
          <div className="border-b border-border/50">
            <button
              onClick={() => setCoursesOpen(!coursesOpen)}
              className={`w-full flex items-center justify-between py-2.5 text-sm font-medium ${
                isCoursePage ? "text-primary font-semibold" : "text-muted-foreground"
              }`}
            >
              Courses
              <ChevronRight className={`h-4 w-4 transition-transform ${coursesOpen ? "rotate-90" : ""}`} />
            </button>
            {coursesOpen && (
              <div className="pl-4 pb-2 space-y-0.5">
                {courseLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => { setMobileOpen(false); setCoursesOpen(false); }}
                    className={`block py-2 text-sm ${
                      location.pathname === link.path
                        ? "text-primary font-semibold"
                        : "text-muted-foreground"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {mainLinks.slice(1).map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setMobileOpen(false)}
              className={`block py-2.5 text-sm font-medium border-b border-border/50 last:border-0 ${
                location.pathname === link.path ? "text-primary font-semibold" : "text-muted-foreground"
              }`}
            >
              {link.label}
            </Link>
          ))}

          <Button
            asChild
            className="w-full mt-3 bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-semibold text-sm"
          >
            <a href="#lead-form" onClick={() => setMobileOpen(false)}>
              Book Free Demo
            </a>
          </Button>
        </nav>
      )}
    </header>
  );
};

export default StickyHeader;
