import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import RichTextSection from "@/components/RichTextSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { usCmaContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const usCmaCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/us-cma-coaching#course",
  name: "US CMA Coaching in Indore",
  description:
    "US CMA (Certified Management Accountant) coaching at Dalmia Academy, Indore. Structured preparation for both CMA parts — Financial Planning, Performance & Analytics and Strategic Financial Management — with expert faculty and small batches.",
  url: "https://dalmiaacademy.com/us-cma-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "ProfessionalCertificate",
  teaches: [
    "Financial Planning", "Performance Management", "Cost Management",
    "Internal Controls", "Financial Statement Analysis", "Corporate Finance",
    "Decision Analysis", "Risk Management", "Investment Decisions", "Professional Ethics",
  ],
  coursePrerequisites: "Bachelor's degree (B.Com, BBA, MBA, CA all qualify)",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      postalCode: "452001",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "US CMA — Both Parts",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Counselling Available",
    url: "https://dalmiaacademy.com/us-cma-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
};

const usCmaContentBlocks = [
  {
    heading: "What is US CMA and Why Is It in Demand?",
    content: `<p>The <strong>US CMA (Certified Management Accountant)</strong> is a globally recognized credential from IMA (Institute of Management Accountants). Unlike CA which focuses on audit and compliance, CMA focuses on <strong>management accounting, financial planning, analysis, control, and strategic decision support</strong> — skills that CFOs and finance leaders need.</p>
<p>US CMA holders are in high demand at MNCs, Indian corporates, banks, and consulting firms. The average salary for CMAs in India is ₹15-30 LPA, with senior professionals earning significantly more. Globally, CMAs earn 58% more than non-certified peers according to IMA's salary survey.</p>
<p><strong>Dalmia Academy brings US CMA coaching to Indore</strong> — our 30+ years of accounting and management teaching expertise is the perfect foundation for CMA's strategy-focused syllabus.</p>`,
  },
  {
    heading: "US CMA Exam Structure — 2 Parts",
    content: `<p>The CMA exam has 2 parts, each a 4-hour computer-based test:</p>
<p><strong>Part 1 — Financial Planning, Performance & Analytics:</strong> External Financial Reporting Decisions (15%), Planning, Budgeting & Forecasting (20%), Performance Management (20%), Cost Management (15%), Internal Controls (15%), Technology & Analytics (15%). This part tests your ability to plan, budget, forecast, and manage costs.</p>
<p><strong>Part 2 — Strategic Financial Management:</strong> Financial Statement Analysis (20%), Corporate Finance (20%), Decision Analysis (25%), Risk Management (10%), Investment Decisions (10%), Professional Ethics (15%). This part tests strategic thinking, decision-making, and ethical judgment.</p>
<p>Each part has <strong>100 MCQs + 2 essay questions</strong>. You need 360/500 to pass. At Dalmia Academy, we prepare you for both MCQ accuracy and essay writing technique.</p>`,
  },
  {
    heading: "US CMA vs CA vs ACCA — Choosing the Right Path",
    content: `<p><strong>Choose US CMA if:</strong> You want to work in corporate finance, FP&A, controllership, or aspire to CFO roles. CMA is the fastest credential to complete (6-12 months) and has the highest ROI for management accounting careers.</p>
<p><strong>Choose CA if:</strong> You want to practice as an auditor, work in tax consulting, or need the Indian statutory framework expertise.</p>
<p><strong>Choose ACCA if:</strong> You want international mobility with a broad accounting qualification recognized in 180+ countries.</p>
<p><strong>CMA + CA or CMA + ACCA</strong> is a powerful combination. Many professionals add CMA to their CA/ACCA to strengthen their management accounting and strategy skills. At Dalmia Academy Indore, we offer CA, ACCA, and CMA coaching — so we can guide you on the best combination for your career goals.</p>`,
  },
];

const USCMACoaching = () => {
  const seo = getPageSeo("/us-cma-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/us-cma-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/us-cma-coaching" }),
          usCmaCourseSchema,
          faqSchema(usCmaContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "US CMA Coaching in Indore", path: "/us-cma-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <main>
        <HeroSection content={usCmaContent.hero} />
        <WhyChooseSection
          heading={usCmaContent.whyChoose.heading}
          subheading={usCmaContent.whyChoose.subheading}
          benefits={usCmaContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={usCmaContent.courses.heading}
          subheading={usCmaContent.courses.subheading}
          courses={usCmaContent.courses.items}
        />
        <RichTextSection
          sectionHeading="Everything You Need to Know About US CMA"
          blocks={usCmaContentBlocks}
          lastUpdated="May 2026"
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={usCmaContent.highlights.heading}
          subheading={usCmaContent.highlights.subheading}
          highlights={usCmaContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={usCmaContent.leadForm.courseOptions} />
        <FAQSection faqs={usCmaContent.faqs} />
        <FinalCTASection
          headline={usCmaContent.finalCTA.headline}
          highlightText={usCmaContent.finalCTA.highlightText}
          subheadline={usCmaContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in US CMA Coaching at Dalmia Academy, Indore. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in US CMA Coaching at Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default USCMACoaching;
