import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";

type Result = {
  id: string;
  route_path: string;
  status_code: number | null;
  title: string | null;
  description: string | null;
  canonical: string | null;
  h1_count: number | null;
  og_title: string | null;
  og_image: string | null;
  schema_types: string[] | null;
  issues: Array<{ code: string; severity: string; message: string }>;
  severity: string;
  ai_recommendation: string | null;
};

const sevBadge = (s: string) =>
  s === "high" ? "destructive" : s === "medium" ? "default" : s === "low" ? "secondary" : "outline";

const SEOScanDetail = () => {
  const { scanId } = useParams();
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(true);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "issues">("issues");

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("seo_scan_results").select("*").eq("scan_id", scanId).order("severity").order("route_path");
    setResults((data ?? []) as unknown as Result[]);
    setLoading(false);
  };

  useEffect(() => { if (scanId) load(); }, [scanId]);

  const generateAI = async (id: string) => {
    setGeneratingId(id);
    try {
      const { data, error } = await supabase.functions.invoke("seo-recommend", { body: { result_id: id } });
      if (error) throw error;
      setResults((prev) => prev.map((r) => (r.id === id ? { ...r, ai_recommendation: data.recommendation } : r)));
      toast({ title: "Recommendation ready" });
    } catch (e) {
      toast({ title: "AI request failed", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    } finally {
      setGeneratingId(null);
    }
  };

  const visible = filter === "all" ? results : results.filter((r) => r.severity !== "ok");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <Link to="/admin/seo">
          <Button variant="ghost" size="sm"><ArrowLeft className="h-4 w-4 mr-2" /> Back</Button>
        </Link>
        <div className="flex gap-2">
          <Button variant={filter === "issues" ? "default" : "outline"} size="sm" onClick={() => setFilter("issues")}>Issues only</Button>
          <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>All routes</Button>
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center text-muted-foreground"><Loader2 className="h-6 w-6 animate-spin mx-auto" /></div>
      ) : visible.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">No routes match.</CardContent></Card>
      ) : (
        visible.map((r) => (
          <Card key={r.id}>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between flex-wrap gap-2">
                <span className="font-mono">{r.route_path}</span>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">HTTP {r.status_code ?? "—"}</Badge>
                  <Badge variant={sevBadge(r.severity) as any}>{r.severity}</Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="grid md:grid-cols-2 gap-3">
                <Field label="Title" value={r.title} hint={r.title ? `${r.title.length} chars` : undefined} />
                <Field label="Description" value={r.description} hint={r.description ? `${r.description.length} chars` : undefined} />
                <Field label="Canonical" value={r.canonical} />
                <Field label="H1 count" value={String(r.h1_count ?? 0)} />
                <Field label="OG title" value={r.og_title} />
                <Field label="OG image" value={r.og_image} />
                <Field label="Schema types" value={(r.schema_types ?? []).join(", ") || "(none)"} />
              </div>

              {r.issues.length > 0 && (
                <div>
                  <div className="font-medium text-xs uppercase text-muted-foreground mb-1">Issues</div>
                  <ul className="space-y-1">
                    {r.issues.map((i, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Badge variant={sevBadge(i.severity) as any} className="text-xs">{i.severity}</Badge>
                        <span>{i.message}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="pt-2 border-t">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium text-xs uppercase text-muted-foreground">AI recommendation</div>
                  <Button size="sm" variant="outline" onClick={() => generateAI(r.id)} disabled={generatingId === r.id}>
                    {generatingId === r.id ? <Loader2 className="h-3 w-3 mr-2 animate-spin" /> : <Sparkles className="h-3 w-3 mr-2" />}
                    {r.ai_recommendation ? "Regenerate" : "Generate"}
                  </Button>
                </div>
                {r.ai_recommendation ? (
                  <pre className="whitespace-pre-wrap text-xs bg-muted p-3 rounded font-sans">{r.ai_recommendation}</pre>
                ) : (
                  <p className="text-xs text-muted-foreground">No recommendation generated yet.</p>
                )}
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
};

const Field = ({ label, value, hint }: { label: string; value: string | null; hint?: string }) => (
  <div>
    <div className="text-xs uppercase text-muted-foreground">{label}{hint ? ` · ${hint}` : ""}</div>
    <div className="text-sm break-words">{value || <span className="text-destructive">missing</span>}</div>
  </div>
);

export default SEOScanDetail;