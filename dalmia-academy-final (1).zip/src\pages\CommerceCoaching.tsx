import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { commerceContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const commerceCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/commerce-coaching#course",
  name: "11th & 12th Commerce Coaching",
  description:
    "Comprehensive Commerce coaching for Class 11 and 12 at Dalmia Academy, Indore. Board + CA/CS integrated preparation with 30+ years of experience. Covers Accountancy, Economics, Business Studies, and Applied Mathematics with concept-based teaching and board exam strategy.",
  url: "https://dalmiaacademy.com/commerce-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "HighSchool",
  teaches: [
    "Accountancy",
    "Economics",
    "Business Studies",
    "Applied Mathematics",
    "Micro Economics",
    "Macro Economics",
    "Indian Economy",
    "Financial Statements",
    "Partnership Accounts",
    "Company Accounts",
    "Management Principles",
    "Business Finance",
    "Marketing",
    "Algebra",
    "Calculus",
    "Probability",
    "Linear Programming",
  ],
  coursePrerequisites: "Completed Class 10",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "11th Commerce",
      description:
        "Foundation-building year covering Accountancy, Economics, Business Studies, and Applied Maths for Class 11 Commerce students with CA/CS integrated prep.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "12th Commerce",
      description:
        "Board-focused preparation for Class 12 Commerce students. Includes exam strategy, revision cycles, mock tests, and integrated CUET/CA foundation coaching.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  about: [
    { "@type": "Thing", name: "CBSE Commerce" },
    { "@type": "Thing", name: "MP Board Commerce" },
    { "@type": "Thing", name: "Board Exam Preparation" },
    { "@type": "Thing", name: "Applied Mathematics" },
    { "@type": "Thing", name: "CA Foundation Preparation" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/commerce-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "5",
    reviewCount: "8",
    bestRating: "5",
    worstRating: "1",
  },
};

const CommerceCoaching = () => {
  const seo = getPageSeo("/commerce-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/commerce-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/commerce-coaching" }),
          commerceCourseSchema,
          faqSchema(commerceContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Commerce Coaching in Indore", path: "/commerce-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <AnnouncementBanner variant="commerce" />
      <main>
        <HeroSection content={commerceContent.hero} />
        <WhyChooseSection
          heading={commerceContent.whyChoose.heading}
          subheading={commerceContent.whyChoose.subheading}
          benefits={commerceContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={commerceContent.courses.heading}
          subheading={commerceContent.courses.subheading}
          courses={commerceContent.courses.items}
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={commerceContent.highlights.heading}
          subheading={commerceContent.highlights.subheading}
          highlights={commerceContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={commerceContent.leadForm.courseOptions} />
        <FAQSection faqs={commerceContent.faqs} />
        <FinalCTASection
          headline={commerceContent.finalCTA.headline}
          highlightText={commerceContent.finalCTA.highlightText}
          subheadline={commerceContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in 11th & 12th Commerce Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in 11th & 12th Commerce Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default CommerceCoaching;
