import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import LeadStatusBadge, { LEAD_STATUSES } from "./LeadStatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { format } from "date-fns";

interface Counselor {
  id: string;
  email: string;
  name: string;
}

interface LeadDetailPanelProps {
  lead: any;
  open: boolean;
  onClose: () => void;
  onUpdated: () => void;
}

const LeadDetailPanel = ({ lead, open, onClose, onUpdated }: LeadDetailPanelProps) => {
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();
  const [status, setStatus] = useState(lead?.status || "New");
  const [notes, setNotes] = useState(lead?.notes || "");
  const [followUpDate, setFollowUpDate] = useState(lead?.follow_up_date || "");
  const [assignedCounselor, setAssignedCounselor] = useState(lead?.assigned_counselor || "");
  const [counselors, setCounselors] = useState<Counselor[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open && lead) {
      setStatus(lead.status || "New");
      setNotes(lead.notes || "");
      setFollowUpDate(lead.follow_up_date || "");
      setAssignedCounselor(lead.assigned_counselor || "");
    }
  }, [open, lead]);

  useEffect(() => {
    if (isAdmin && open) {
      supabase.functions.invoke("manage-counselor", { body: { action: "list" } }).then(({ data }) => {
        setCounselors(data?.counselors || []);
      });
    }
  }, [isAdmin, open]);

  const handleSave = async () => {
    if (!lead) return;
    setSaving(true);

    const oldStatus = lead.status;
    const updates: any = { status, notes, follow_up_date: followUpDate || null };
    if (isAdmin) {
      updates.assigned_counselor = assignedCounselor || null;
    }

    const { error } = await supabase
      .from("leads")
      .update(updates)
      .eq("id", lead.id);

    setSaving(false);
    if (error) {
      toast({ title: "Error saving", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Lead updated" });
      onUpdated();
    }
  };

  if (!lead) return null;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="font-heading">{lead.name}</SheetTitle>
        </SheetHeader>
        <div className="mt-6 space-y-5">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground">Phone</p>
              <p className="font-medium">{lead.phone}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Email</p>
              <p className="font-medium">{lead.email || "—"}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Course</p>
              <p className="font-medium">{lead.course_interested}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Source</p>
              <p className="font-medium">{lead.source}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Page URL</p>
              <p className="font-medium text-xs break-all">{lead.page_url || "—"}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Created</p>
              <p className="font-medium">{format(new Date(lead.created_at), "PPp")}</p>
            </div>
            {lead.utm_source && (
              <div className="col-span-2">
                <p className="text-muted-foreground">UTM</p>
                <p className="font-medium text-xs">
                  {[lead.utm_source, lead.utm_medium, lead.utm_campaign].filter(Boolean).join(" / ")}
                </p>
              </div>
            )}
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {LEAD_STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {isAdmin && (
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Assigned Team Member</label>
              <select
                value={assignedCounselor}
                onChange={(e) => setAssignedCounselor(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="">Unassigned</option>
                {counselors.map((c) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.email})</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">Follow-up Date</label>
            <Input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-1 block">Notes</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              placeholder="Add notes about this lead..."
            />
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full">
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default LeadDetailPanel;
