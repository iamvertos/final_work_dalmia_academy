import { useState, useEffect } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Users, UserCog, LogOut, FileText, BookOpen, Sun, Activity, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

const AdminLayout = () => {
  const { user, loading, isAdmin, isCounselor, signOut } = useAuth();
  const location = useLocation();
  const [showRetry, setShowRetry] = useState(false);

  useEffect(() => {
    if (!loading) return;
    const timer = setTimeout(() => setShowRetry(true), 5000);
    return () => clearTimeout(timer);
  }, [loading]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <p className="text-muted-foreground">Loading...</p>
        {showRetry && (
          <div className="flex flex-col items-center gap-2">
            <p className="text-sm text-muted-foreground">Taking longer than expected.</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => window.location.reload()}>
                Retry
              </Button>
              <Link to="/admin/login">
                <Button size="sm">Go to Login</Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (!user || (!isAdmin && !isCounselor)) {
    return <Navigate to="/admin/login" replace />;
  }

  const navItems = [
    { label: "Dashboard", path: "/admin", icon: LayoutDashboard, show: isAdmin },
    { label: "Leads", path: "/admin/leads", icon: Users, show: true },
    { label: "Summer Camp", path: "/admin/summer-leads", icon: Sun, show: true },
    { label: "Team", path: "/admin/team", icon: UserCog, show: isAdmin },
    { label: "Blog Posts", path: "/admin/blog", icon: FileText, show: isAdmin },
    { label: "Resources", path: "/admin/resources", icon: BookOpen, show: isAdmin },
    { label: "GTM Debug", path: "/admin/gtm-debug", icon: Activity, show: isAdmin },
    { label: "SEO", path: "/admin/seo", icon: Search, show: isAdmin },
  ].filter((item) => item.show);

  return (
    <div className="min-h-screen flex bg-muted">
      <aside className="w-60 bg-card border-r border-border hidden md:flex flex-col">
        <div className="p-4 border-b border-border">
          <h2 className="font-heading font-bold text-lg text-primary">Dalmia Admin</h2>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-muted-foreground"
            onClick={signOut}
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen">
        <header className="md:hidden bg-card border-b border-border p-3 flex items-center justify-between">
          <h2 className="font-heading font-bold text-primary">Admin</h2>
          <div className="flex gap-2">
            {navItems.map((item) => (
              <Link key={item.path} to={item.path}>
                <Button variant={location.pathname === item.path ? "default" : "ghost"} size="sm">
                  <item.icon className="h-4 w-4" />
                </Button>
              </Link>
            ))}
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
