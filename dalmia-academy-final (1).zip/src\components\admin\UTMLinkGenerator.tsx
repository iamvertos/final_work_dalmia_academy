import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, Link as LinkIcon, CheckCircle, AlertCircle } from "lucide-react";

const PAGES = [
  { label: "Home", path: "/" },
  { label: "IPMAT & CUET-UG", path: "/cuet-coaching" },
  { label: "CA / CS", path: "/ca-foundation" },
  { label: "Commerce 11th & 12th", path: "/commerce-coaching" },
  { label: "Humanities 11th & 12th", path: "/humanities-coaching" },
  { label: "6th–10th", path: "/school-coaching" },
  { label: "Spoken English", path: "/spoken-english" },
  { label: "About Us", path: "/about" },
  { label: "Contact", path: "/contact" },
  { label: "Results", path: "/results" },
];

const hasInvalidChars = (val: string) => /[\s<>"{}|\\^`]/.test(val);

const UTMLinkGenerator = () => {
  const [page, setPage] = useState("/");
  const [source, setSource] = useState("google");
  const [medium, setMedium] = useState("cpc");
  const [campaign, setCampaign] = useState("");
  const [content, setContent] = useState("");
  const [term, setTerm] = useState("");
  const [copied, setCopied] = useState(false);

  const baseUrl = "https://dalmiaacademy.com";

  const generatedUrl = (() => {
    const params = new URLSearchParams();
    if (source) params.set("utm_source", source);
    if (medium) params.set("utm_medium", medium);
    if (campaign) params.set("utm_campaign", campaign);
    if (content) params.set("utm_content", content);
    if (term) params.set("utm_term", term);
    const qs = params.toString();
    return `${baseUrl}${page}${qs ? "?" + qs : ""}`;
  })();

  // Validation
  const errors: string[] = [];
  if (!campaign.trim()) errors.push("Campaign name is required");
  if (campaign && hasInvalidChars(campaign)) errors.push("Campaign has invalid characters (spaces/special chars)");
  if (content && hasInvalidChars(content)) errors.push("Content has invalid characters");
  if (term && hasInvalidChars(term)) errors.push("Term has invalid characters");

  let urlValid = false;
  try {
    new URL(generatedUrl);
    urlValid = true;
  } catch {
    errors.push("Generated URL is malformed");
  }

  const isValid = errors.length === 0 && urlValid;

  const handleCopy = () => {
    if (!isValid) return;
    navigator.clipboard.writeText(generatedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const pageName = PAGES.find((p) => p.path === page)?.label ?? page;
  const utmParams = [
    source && { key: "utm_source", value: source },
    medium && { key: "utm_medium", value: medium },
    campaign && { key: "utm_campaign", value: campaign },
    content && { key: "utm_content", value: content },
    term && { key: "utm_term", value: term },
  ].filter(Boolean) as { key: string; value: string }[];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <LinkIcon className="h-4 w-4" />
          UTM Tracking Link Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Landing Page</label>
            <Select value={page} onValueChange={setPage}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PAGES.map((p) => (
                  <SelectItem key={p.path} value={p.path}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Source</label>
            <Select value={source} onValueChange={setSource}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="google">Google</SelectItem>
                <SelectItem value="facebook">Facebook / Meta</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="youtube">YouTube</SelectItem>
                <SelectItem value="whatsapp">WhatsApp</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Medium</label>
            <Select value={medium} onValueChange={setMedium}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="cpc">CPC (Paid Search)</SelectItem>
                <SelectItem value="social">Social</SelectItem>
                <SelectItem value="display">Display</SelectItem>
                <SelectItem value="video">Video</SelectItem>
                <SelectItem value="organic">Organic</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Campaign Name *</label>
            <Input value={campaign} onChange={(e) => setCampaign(e.target.value)} placeholder="e.g. cuet_june_2026" />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Content (optional)</label>
            <Input value={content} onChange={(e) => setContent(e.target.value)} placeholder="e.g. banner_ad_1" />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">Term (optional)</label>
            <Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="e.g. cuet_coaching_indore" />
          </div>
        </div>

        {/* Validation Status */}
        <div className={`flex items-start gap-2 text-sm ${isValid ? "text-green-600" : "text-destructive"}`}>
          {isValid ? (
            <div className="flex items-center gap-1.5">
              <CheckCircle className="h-4 w-4" />
              <span>Valid URL — ready to copy</span>
            </div>
          ) : (
            <div className="space-y-1">
              {errors.map((err, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{err}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* URL Preview Breakdown */}
        <div className="rounded-lg border p-3 space-y-2 text-sm">
          <p className="font-medium text-muted-foreground">URL Preview</p>
          <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
            <span className="text-muted-foreground">Base:</span>
            <span className="font-mono">{baseUrl}</span>
            <span className="text-muted-foreground">Page:</span>
            <span className="font-mono">{pageName} ({page})</span>
            {utmParams.map((p) => (
              <span key={p.key} className="contents">
                <span className="text-muted-foreground">{p.key}:</span>
                <span className="font-mono">{p.value}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Generated URL + Copy */}
        <div className="bg-muted rounded-lg p-3 flex items-center gap-2">
          <code className="text-sm break-all flex-1">{generatedUrl}</code>
          <Button size="sm" variant="outline" onClick={handleCopy} disabled={!isValid} className="shrink-0">
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default UTMLinkGenerator;
