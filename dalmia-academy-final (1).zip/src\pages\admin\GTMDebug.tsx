import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { pushPageView, pushClick, pushFormView, pushFormSubmit } from "@/lib/gtm";

type DLEntry = {
  id: number;
  ts: number;
  event: string;
  payload: Record<string, unknown>;
};

const TRACKED = ["page_view", "phone_click", "whatsapp_click", "form_view", "form_submit"] as const;
type Tracked = (typeof TRACKED)[number];

let counter = 0;
const nextId = () => ++counter;

const formatTime = (ts: number) =>
  new Date(ts).toLocaleTimeString([], { hour12: false }) +
  "." +
  String(ts % 1000).padStart(3, "0");

const GTMDebug = () => {
  const [entries, setEntries] = useState<DLEntry[]>([]);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.dataLayer = window.dataLayer || [];
    const dl = window.dataLayer;

    // Snapshot existing entries
    const initial: DLEntry[] = dl.map((raw) => {
      const obj = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
      const { event, ...rest } = obj as { event?: unknown } & Record<string, unknown>;
      return {
        id: nextId(),
        ts: Date.now(),
        event: typeof event === "string" ? event : "(no event)",
        payload: rest,
      };
    });
    setEntries(initial);

    const originalPush = dl.push.bind(dl);
    dl.push = ((...args: Record<string, unknown>[]) => {
      const result = originalPush(...args);
      const captured: DLEntry[] = args.map((raw) => {
        const obj = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
        const { event, ...rest } = obj as { event?: unknown } & Record<string, unknown>;
        return {
          id: nextId(),
          ts: Date.now(),
          event: typeof event === "string" ? event : "(no event)",
          payload: rest,
        };
      });
      setEntries((prev) => [...prev, ...captured]);
      return result;
    }) as typeof dl.push;

    return () => {
      dl.push = originalPush;
    };
  }, []);

  const filtered = useMemo(
    () => (showAll ? entries : entries.filter((e) => (TRACKED as readonly string[]).includes(e.event))),
    [entries, showAll]
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const e of entries) c[e.event] = (c[e.event] || 0) + 1;
    return c;
  }, [entries]);

  const latestByEvent = useMemo(() => {
    const map: Partial<Record<Tracked, DLEntry>> = {};
    for (const e of entries) {
      if ((TRACKED as readonly string[]).includes(e.event)) {
        map[e.event as Tracked] = e;
      }
    }
    return map;
  }, [entries]);

  const fireTestEvents = () => {
    pushPageView({ path: "/admin/gtm-debug", title: "GTM Debug (test)" });
    pushClick({ type: "phone_click", source: "gtm_debug_test", link_url: "tel:+919575776655" });
    pushClick({ type: "whatsapp_click", source: "gtm_debug_test", link_url: "https://wa.me/919575776655" });
    pushFormView("gtm_debug_test_form");
    pushFormSubmit({ form_name: "gtm_debug_test_form", course: "test", value: 1 });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-bold text-primary">GTM Debug</h1>
          <p className="text-sm text-muted-foreground">
            Live mirror of <code>window.dataLayer</code> pushes. Container: GTM-N8GWKPZW.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={fireTestEvents}>
            Trigger test events
          </Button>
          <Button size="sm" variant="outline" onClick={() => setEntries([])}>
            Clear log
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Event counts</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {TRACKED.map((ev) => (
            <Badge key={ev} variant="secondary" className="font-mono">
              {ev} × {counts[ev] || 0}
            </Badge>
          ))}
          {Object.entries(counts)
            .filter(([ev]) => !(TRACKED as readonly string[]).includes(ev))
            .map(([ev, n]) => (
              <Badge key={ev} variant="outline" className="font-mono opacity-70">
                {ev} × {n}
              </Badge>
            ))}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {TRACKED.map((ev) => {
          const last = latestByEvent[ev];
          return (
            <Card key={ev}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center justify-between text-sm font-mono">
                  <span>{ev}</span>
                  <span className="text-xs text-muted-foreground font-sans">
                    {last ? formatTime(last.ts) : "no events yet"}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {last ? (
                  <pre className="text-xs bg-muted rounded p-3 overflow-auto max-h-48">
                    {JSON.stringify(last.payload, null, 2)}
                  </pre>
                ) : (
                  <p className="text-xs text-muted-foreground">Waiting for first {ev}…</p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-base">Event log ({filtered.length})</CardTitle>
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <Switch checked={showAll} onCheckedChange={setShowAll} />
            Show all events (incl. gtm.js, gtm.dom…)
          </label>
        </CardHeader>
        <CardContent>
          {filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events captured yet.</p>
          ) : (
            <div className="space-y-2 max-h-[60vh] overflow-auto">
              {[...filtered].reverse().map((e) => (
                <details key={e.id} className="border border-border rounded-lg bg-card">
                  <summary className="cursor-pointer px-3 py-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Badge
                        variant={(TRACKED as readonly string[]).includes(e.event) ? "default" : "outline"}
                        className="font-mono text-[11px]"
                      >
                        {e.event}
                      </Badge>
                      <span className="text-xs text-muted-foreground truncate">
                        {Object.keys(e.payload).length} keys
                      </span>
                    </div>
                    <span className="text-[11px] text-muted-foreground font-mono shrink-0">
                      {formatTime(e.ts)}
                    </span>
                  </summary>
                  <pre className="text-xs bg-muted m-2 rounded p-3 overflow-auto">
                    {JSON.stringify(e.payload, null, 2)}
                  </pre>
                </details>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default GTMDebug;