import { pushFormSubmit } from "@/lib/gtm";

declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
    fbq?: (...args: any[]) => void;
  }
}

interface ConversionData {
  value?: number;
  currency?: string;
  course?: string;
  form_name?: string;
}

export const useConversionTracking = () => {
  const trackConversion = (data?: ConversionData) => {
    // GTM dataLayer — preferred path going forward.
    pushFormSubmit({
      form_name: data?.form_name || "general_enquiry",
      course: data?.course,
      value: data?.value,
      currency: data?.currency,
    });

    // Google Ads conversion
    if (typeof window.gtag === "function") {
      window.gtag("event", "conversion", {
        send_to: window.__GOOGLE_ADS_CONVERSION_LABEL || "",
        value: data?.value || 0,
        currency: data?.currency || "INR",
      });
    }

    // Meta Pixel
    if (typeof window.fbq === "function") {
      window.fbq("track", "Lead", {
        content_name: data?.course || "General Enquiry",
        currency: data?.currency || "INR",
        value: data?.value || 0,
      });
    }
  };

  return { trackConversion };
};

// Augment window for conversion IDs
declare global {
  interface Window {
    __GOOGLE_ADS_CONVERSION_LABEL?: string;
  }
}
