import logo from "@/assets/dalmia-academy-logo.webp";
import { Star } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";

const ReviewLinks = () => {
  const links = [
    {
      name: "Google Review",
      url: "https://g.page/r/CeMHsFZS8BlvEBM/review",
      emoji: "🔍",
      color: "from-blue-500 to-blue-600",
    },
    {
      name: "JustDial Review",
      url: "https://www.justdial.com/Indore/Dalmia-Academy-Geeta-Bhawan-Square-South-Tukoganj/0731PX731-X731-170521202219-M2W8_BZDET/writereview",
      emoji: "📞",
      color: "from-yellow-500 to-orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 flex items-center justify-center p-4">
      <SEO {...getPageSeo("/review")} path="/review" />
      <div className="w-full max-w-[400px] flex flex-col items-center gap-6">
        {/* Logo */}
        <img src={logo} alt="Dalmia Academy" width={96} height={96} loading="eager" className="w-24 h-24 rounded-full shadow-xl border-4 border-white/20 object-contain bg-white" />

        {/* Title */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white">Dalmia Academy</h1>
          <p className="text-white/70 mt-1 text-sm">Share your experience with us! ⭐</p>
        </div>

        {/* Stars */}
        <div className="flex gap-1">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
          ))}
        </div>

        {/* Links */}
        <div className="w-full flex flex-col gap-4">
          {links.map((link) => (
            <a
              key={link.name}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`w-full bg-gradient-to-r ${link.color} text-white rounded-2xl p-5 flex items-center gap-4 shadow-lg hover:scale-[1.03] active:scale-[0.98] transition-transform`}
            >
              <span className="text-3xl">{link.emoji}</span>
              <div>
                <div className="font-semibold text-lg">{link.name}</div>
                <div className="text-white/80 text-xs">Tap to leave a review</div>
              </div>
            </a>
          ))}
        </div>

        {/* QR Code */}
        <div className="bg-white p-4 rounded-2xl shadow-lg flex flex-col items-center gap-2">
          <QRCodeSVG value="https://dalmia-academy.lovable.app/review" size={160} />
          <p className="text-gray-800 text-sm font-semibold">Scan to review ✨</p>
        </div>

        <p className="text-white/40 text-xs mt-4">Your feedback means the world to us 💙</p>
      </div>
    </div>
  );
};

export default ReviewLinks;
