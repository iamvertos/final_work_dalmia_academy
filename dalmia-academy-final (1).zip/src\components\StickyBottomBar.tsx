import { Phone } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";
import { trackClick } from "@/hooks/useClickTracking";

interface StickyBottomBarProps {
  whatsappMessage?: string;
}

const StickyBottomBar = ({ whatsappMessage }: StickyBottomBarProps) => {
  const whatsappUrl = whatsappMessage
    ? `https://wa.me/919575776655?text=${encodeURIComponent(whatsappMessage)}`
    : "https://wa.me/919575776655";

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-card border-t border-border shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
      <div className="grid grid-cols-2 divide-x divide-border">
        <a
          href="tel:+919575776655"
          onClick={() => trackClick("phone_click", "sticky_bottom_bar")}
          className="flex items-center justify-center gap-2 py-3.5 font-heading font-semibold text-primary text-sm"
        >
          <Phone className="h-4 w-4" />
          Call Now
        </a>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackClick("whatsapp_click", "sticky_bottom_bar")}
          className="flex items-center justify-center gap-2 py-3.5 font-heading font-semibold text-green-600 text-sm"
        >
          <WhatsAppIcon className="h-4 w-4" />
          WhatsApp
        </a>
      </div>
    </div>
  );
};

export default StickyBottomBar;
