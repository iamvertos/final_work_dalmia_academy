
-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'counselor');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles (avoids RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- user_roles RLS: only admins can read
CREATE POLICY "Admins can read user_roles"
ON public.user_roles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create leads table
CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  course_interested TEXT NOT NULL,
  message TEXT,
  source TEXT DEFAULT 'direct',
  campaign_name TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  utm_content TEXT,
  utm_term TEXT,
  page_url TEXT,
  ip_address TEXT,
  assigned_counselor UUID REFERENCES auth.users(id),
  status TEXT NOT NULL DEFAULT 'New',
  follow_up_date DATE,
  notes TEXT,
  admission_status TEXT,
  payment_status TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Anyone can insert leads (public form submissions)
CREATE POLICY "Anyone can insert leads"
ON public.leads FOR INSERT TO anon, authenticated
WITH CHECK (true);

-- Admins can read all leads
CREATE POLICY "Admins can read all leads"
ON public.leads FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Counselors can read assigned leads
CREATE POLICY "Counselors can read assigned leads"
ON public.leads FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'counselor') AND assigned_counselor = auth.uid());

-- Admins can update all leads
CREATE POLICY "Admins can update all leads"
ON public.leads FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Counselors can update assigned leads
CREATE POLICY "Counselors can update assigned leads"
ON public.leads FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'counselor') AND assigned_counselor = auth.uid());

-- Admins can delete leads
CREATE POLICY "Admins can delete leads"
ON public.leads FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create lead_status_logs table
CREATE TABLE public.lead_status_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  old_status TEXT,
  new_status TEXT NOT NULL,
  changed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.lead_status_logs ENABLE ROW LEVEL SECURITY;

-- Authenticated users can insert status logs
CREATE POLICY "Authenticated can insert status logs"
ON public.lead_status_logs FOR INSERT TO authenticated
WITH CHECK (true);

-- Admins can read all status logs
CREATE POLICY "Admins can read status logs"
ON public.lead_status_logs FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Auto-update updated_at on leads
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_leads_updated_at
BEFORE UPDATE ON public.leads
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
