
-- Drop unused tables
DROP TABLE IF EXISTS public.lead_status_logs;
DROP TABLE IF EXISTS public.ad_campaigns;

-- Add 'team' to role enum (must be committed before use)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'team';
