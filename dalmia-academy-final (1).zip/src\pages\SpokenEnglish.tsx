import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import HighlightsSection from "@/components/HighlightsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { spokenEnglishContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const spokenEnglishCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/spoken-english#course",
  name: "Spoken English & Personality Development",
  description:
    "Build English fluency and a confident personality in 90 days at Dalmia Academy, Indore. Daily speaking practice, fear removal training, body language coaching, and interview preparation for students, job seekers, and working professionals.",
  url: "https://dalmiaacademy.com/spoken-english",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "en",
  educationalLevel: "LifelongLearning",
  teaches: [
    "Spoken English",
    "Sentence Formation",
    "Pronunciation",
    "Vocabulary",
    "Everyday Conversation",
    "Confidence Development",
    "Corporate English",
    "Public Speaking",
    "Group Discussions",
    "Interview Preparation",
    "Professional Etiquette",
    "Body Language",
    "Personality Development",
  ],
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "3-Month Confidence Builder",
      description:
        "Basic to advanced spoken English skills over 3 months with daily practice, vocabulary building, sentence formation, pronunciation, and confidence development.",
      courseMode: "Onsite",
      duration: "P3M",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
      instructor: {
        "@type": "Person",
        name: "Anand Potdar",
        jobTitle: "Senior Faculty — Spoken English & Communication Coach",
      },
    },
    {
      "@type": "CourseInstance",
      name: "6-Month Advanced Mastery",
      description:
        "Advanced program covering corporate English communication, public speaking, group discussions, interview mastery, and professional etiquette over 6 months.",
      courseMode: "Onsite",
      duration: "P6M",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
      instructor: {
        "@type": "Person",
        name: "Anand Potdar",
        jobTitle: "Senior Faculty — Spoken English & Communication Coach",
      },
    },
  ],
  audience: [
    { "@type": "Audience", audienceType: "College Students" },
    { "@type": "Audience", audienceType: "Job Seekers" },
    { "@type": "Audience", audienceType: "Working Professionals" },
  ],
  about: [
    { "@type": "Thing", name: "English Communication" },
    { "@type": "Thing", name: "Interview Preparation" },
    { "@type": "Thing", name: "Public Speaking" },
    { "@type": "Thing", name: "Personality Development" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/spoken-english",
    availability: "https://schema.org/InStock",
    priceCurrency: "INR",
  },
};

const SpokenEnglish = () => {
  const seo = getPageSeo("/spoken-english");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/spoken-english"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/spoken-english" }),
          spokenEnglishCourseSchema,
          faqSchema(spokenEnglishContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Spoken English in Indore", path: "/spoken-english" },
          ]),
        ]}
      />
      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={spokenEnglishContent.hero} />
        <WhyChooseSection
          heading={spokenEnglishContent.whyChoose.heading}
          subheading={spokenEnglishContent.whyChoose.subheading}
          benefits={spokenEnglishContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={spokenEnglishContent.courses.heading}
          subheading={spokenEnglishContent.courses.subheading}
          courses={spokenEnglishContent.courses.items}
        />
        <AboutSection />
        <HighlightsSection
          heading={spokenEnglishContent.highlights.heading}
          subheading={spokenEnglishContent.highlights.subheading}
          highlights={spokenEnglishContent.highlights.items}
        />
        <LeadFormSection courseOptions={spokenEnglishContent.leadForm.courseOptions} />
        <FAQSection faqs={spokenEnglishContent.faqs} />
        <FinalCTASection
          headline={spokenEnglishContent.finalCTA.headline}
          highlightText={spokenEnglishContent.finalCTA.highlightText}
          subheadline={spokenEnglishContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in Spoken English at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in Spoken English at Dalmia Academy. Please share details." />
    </div>
  );
};

export default SpokenEnglish;
