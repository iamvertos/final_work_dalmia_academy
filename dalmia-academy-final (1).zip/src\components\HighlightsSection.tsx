import type { HighlightItem } from "@/data/pageContent";

interface HighlightsSectionProps {
  heading?: string;
  subheading?: string;
  highlights?: HighlightItem[];
}

const HighlightsSection = ({
  heading = "Program Highlights",
  subheading = "Everything you need for a complete CUET preparation journey",
  highlights = [],
}: HighlightsSectionProps) => {
  return (
    <section className="py-14 md:py-20" id="highlights">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          {heading}
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          {subheading}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
          {highlights.map((h) => (
            <div key={h.title} className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
              <div className="w-10 h-10 rounded-full bg-accent/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                <h.icon className="h-5 w-5 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold font-heading text-foreground mb-1">{h.title}</h3>
                <p className="text-sm text-muted-foreground">{h.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HighlightsSection;
