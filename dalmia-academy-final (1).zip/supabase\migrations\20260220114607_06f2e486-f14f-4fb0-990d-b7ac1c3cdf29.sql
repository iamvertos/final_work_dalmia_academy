
CREATE TABLE public.click_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  page_url text,
  source_component text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  utm_content text,
  utm_term text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.click_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert click_events"
  ON public.click_events FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Admins can read click_events"
  ON public.click_events FOR SELECT
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Team can read click_events"
  ON public.click_events FOR SELECT
  USING (has_role(auth.uid(), 'team'));
