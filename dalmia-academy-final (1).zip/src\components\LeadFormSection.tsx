import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useConversionTracking } from "@/hooks/useConversionTracking";
import { pushFormView } from "@/lib/gtm";

interface LeadFormSectionProps {
  courseOptions?: { value: string; label: string }[];
}

const defaultOptions = [
  { value: "Commerce", label: "Commerce CUET Prep" },
  { value: "Science", label: "Science CUET Prep" },
];

const getUtmParams = () => {
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: params.get("utm_source") || null,
    utm_medium: params.get("utm_medium") || null,
    utm_campaign: params.get("utm_campaign") || null,
    utm_content: params.get("utm_content") || null,
    utm_term: params.get("utm_term") || null,
  };
};

const getSource = () => {
  const params = new URLSearchParams(window.location.search);
  const utmSource = params.get("utm_source");
  if (utmSource) {
    if (utmSource.toLowerCase().includes("google")) return "google";
    if (utmSource.toLowerCase().includes("meta") || utmSource.toLowerCase().includes("facebook") || utmSource.toLowerCase().includes("instagram")) return "meta";
    return "organic";
  }
  const ref = document.referrer;
  if (ref.includes("google")) return "google";
  if (ref.includes("facebook") || ref.includes("instagram")) return "meta";
  if (ref) return "organic";
  return "direct";
};

const LeadFormSection = ({ courseOptions = defaultOptions }: LeadFormSectionProps) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { trackConversion } = useConversionTracking();
  const [form, setForm] = useState({ name: "", phone: "", email: "", course: courseOptions[0]?.value ?? "" });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    pushFormView("general_enquiry");
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      toast({ title: "Please fill all fields", variant: "destructive" });
      return;
    }
    setLoading(true);

    try {
      const utm = getUtmParams();
      const source = getSource();
      const leadData = {
        name: form.name.trim(),
        phone: form.phone.trim(),
        email: form.email.trim() || null,
        course_interested: form.course,
        source,
        page_url: window.location.href,
        ...utm,
      };

      const { error } = await supabase.from("leads").insert(leadData);

      if (error) {
        toast({ title: "Something went wrong", description: "Please try again.", variant: "destructive" });
      } else {
        // Fire conversion tracking (GTM dataLayer + Ads/Meta)
        trackConversion({ course: form.course, form_name: "general_enquiry" });

        // Send email notification (fire-and-forget)
        supabase.functions.invoke("send-lead-email", { body: leadData });

        // Redirect to thank-you page for conversion tracking
        navigate("/thank-you");
      }
    } catch {
      toast({ title: "Something went wrong", description: "Please try again.", variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <section className="py-14 md:py-20 bg-primary" id="lead-form">
      <div className="container mx-auto px-4">
        <div className="max-w-lg mx-auto bg-card rounded-2xl p-8 shadow-xl">
          <h2 className="text-2xl md:text-3xl font-bold font-heading text-center text-primary mb-2">
            Get Free Counseling
          </h2>
          <p className="text-center text-muted-foreground mb-6 text-sm">
            Fill in your details and get a callback within 24 hours
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              placeholder="Your Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
            <Input
              placeholder="Phone Number"
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              required
            />
            <Input
              placeholder="Email (optional)"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <label htmlFor="course-select" className="sr-only">
              Select a Course
            </label>
            <select
              id="course-select"
              aria-label="Select a Course"
              value={form.course}
              onChange={(e) => setForm({ ...form, course: e.target.value })}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {courseOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-bold text-base h-12"
            >
              {loading ? "Submitting..." : "Get a Callback Within 24 Hours"}
            </Button>
          </form>

          <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground mt-4">
            <ShieldCheck className="h-3.5 w-3.5" />
            No spam. We respect your privacy.
          </p>
        </div>
      </div>
    </section>
  );
};

export default LeadFormSection;
