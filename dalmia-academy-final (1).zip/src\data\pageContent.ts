import { Target, Users, BookOpen, Brain, ClipboardCheck, HeartHandshake, FileText, BarChart3, HelpCircle, BookMarked, Layers, RefreshCw, Atom, FlaskConical, Calculator, Leaf, Globe, Languages, PenLine, Award, TrendingUp, Briefcase, LineChart } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface HeroContent {
  headline: string;
  highlightText: string;
  subheadline: string;
  benefits: string[];
  stats: { value: string; label: string }[];
}

export interface BenefitItem {
  icon: LucideIcon;
  title: string;
  desc: string;
}

export interface CourseItem {
  icon: LucideIcon;
  title: string;
  subjects: string[];
  desc: string;
}

export interface HighlightItem {
  icon: LucideIcon;
  title: string;
  desc: string;
}

export interface FAQItem {
  q: string;
  a: string;
}

export interface TestimonialItem {
  name: string;
  text: string;
  course: string;
}

export interface PageContent {
  slug: string;
  pageTitle: string;
  metaDescription: string;
  hero: HeroContent;
  whyChoose: {
    heading: string;
    subheading: string;
    benefits: BenefitItem[];
  };
  courses: {
    heading: string;
    subheading: string;
    items: CourseItem[];
  };
  highlights: {
    heading: string;
    subheading: string;
    items: HighlightItem[];
  };
  faqs: FAQItem[];
  testimonials: TestimonialItem[];
  leadForm: {
    courseOptions: { value: string; label: string }[];
  };
  finalCTA: {
    headline: string;
    highlightText: string;
    subheadline: string;
  };
}

// ─── CUET Content (existing) ────────────────────────────────────────
export const cuetContent: PageContent = {
  slug: "cuet-coaching",
  pageTitle: "Best CUET & IPMAT Coaching in Indore — Dalmia Academy",
  metaDescription: "Best CUET-UG and IPMAT coaching in Indore. Board-integrated preparation with daily mocks, sectional drills, mentorship & small batches at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best CUET & IPMAT Coaching in Indore —",
    highlightText: "Secure Your University Admission",
    subheadline: "Board + IPMAT & CUET-UG integrated preparation at Dalmia Academy, Indore. Expert faculty, small batches of 25, and structured exam strategy near Geeta Bhawan Square.",
    benefits: ["Limited Batches", "Expert Faculty", "IPMAT & CUET Pattern Prep", "Board + CUET Together"],
    stats: [
      { value: "10+", label: "Years Experience" },
      { value: "500+", label: "Students Guided" },
      { value: "25", label: "Max Batch Size" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best CUET & IPMAT Coaching in Indore",
    subheading: "The best IPMAT & CUET-UG coaching in Indore with a proven approach and 30+ years of academic mentorship",
    benefits: [
      { icon: Target, title: "IPMAT & CUET-UG Focused Strategy", desc: "Curriculum designed specifically around the IPMAT & CUET-UG exam patterns and syllabus for maximum results. Our CUET coaching in Indore covers both domain subjects and the General Test with equal depth." },
      { icon: Users, title: "Experienced Faculty Since 1991", desc: "Learn from educators with 25-35+ years of experience in Board and competitive exam preparation at our Indore centre. Our faculty understands the exact requirements of CUET-UG and IPMAT exam patterns." },
      { icon: BookOpen, title: "Small Batches of 25 Students", desc: "Every CUET batch is limited to 25 students ensuring personal attention, doubt resolution, and individual feedback. This small-batch model is central to our high success rate in CUET coaching in Indore." },
      { icon: Brain, title: "Concept-Based Teaching", desc: "Focus on building strong fundamentals rather than rote learning. Our concept-first approach helps students tackle new question patterns confidently in CUET-UG classes in Indore and IPMAT entrance exams alike." },
      { icon: ClipboardCheck, title: "Regular Mock Tests & Analysis", desc: "Frequent IPMAT & CUET-UG pattern mock tests with detailed performance analysis. Whether preparing for IIM Indore IPM or central university admission, each student receives individual feedback to improve strategically." },
      { icon: HeartHandshake, title: "Personal Mentorship & Career Guidance", desc: "One-on-one mentorship at our Geeta Bhawan Square centre. Students searching for CUET coaching near me in Indore will find us easily accessible from Vijay Nagar, Palasia, and Sapna Sangeeta." },
    ],
  },
  courses: {
    heading: "IPMAT & CUET-UG Courses Offered",
    subheading: "Structured programs for Commerce and Science students preparing for IPMAT & CUET-UG",
    items: [
      { icon: BookOpen, title: "Commerce IPMAT & CUET-UG Prep", subjects: ["Accountancy", "Economics", "Business Studies", "English", "General Test"], desc: "Complete preparation for Commerce students targeting top universities through IPMAT & CUET-UG, with Board alignment." },
      { icon: Target, title: "Science CUET-UG Prep", subjects: ["Physics", "Chemistry", "Maths / Biology", "English", "General Test"], desc: "Comprehensive Science preparation combining Board syllabus with CUET-UG specific strategies." },
    ],
  },
  highlights: {
    heading: "Program Highlights",
    subheading: "Everything you need for a complete IPMAT & CUET-UG preparation journey",
    items: [
      { icon: FileText, title: "IPMAT & CUET-UG Pattern Mocks", desc: "Practice with exams designed exactly like the real IPMAT & CUET-UG" },
      { icon: BarChart3, title: "Performance Analysis", desc: "Detailed reports to identify strengths and weak areas" },
      { icon: HelpCircle, title: "Doubt Solving Sessions", desc: "Dedicated sessions to clear every doubt, big or small" },
      { icon: BookMarked, title: "Structured Study Material", desc: "Comprehensive notes and resources curated for IPMAT & CUET-UG" },
      { icon: Layers, title: "Board + CUET-UG Alignment", desc: "Syllabus mapped to cover both Board and CUET-UG together" },
      { icon: RefreshCw, title: "Weekly Revisions", desc: "Regular revision cycles to reinforce learning and retention" },
    ],
  },
  faqs: [
    { q: "Which is the best CUET coaching in Indore?", a: "Dalmia Academy is one of Indore's most trusted CUET & IPMAT coaching institutes with 30+ years of academic mentorship. Located at Geeta Bhawan Square on AB Road, we offer Board + CUET integrated preparation with small batches of 25 and experienced faculty." },
    { q: "Is this coaching suitable for non-JEE/NEET students?", a: "Absolutely! Dalmia Academy's IPMAT & CUET-UG program in Indore is specifically designed for students who are not pursuing JEE or NEET. It's ideal for Commerce and Science students aiming for top central universities and IIMs." },
    { q: "Do you cover both Board exams and IPMAT/CUET-UG?", a: "Yes. Our integrated approach ensures that Board syllabus and IPMAT & CUET-UG preparation happen simultaneously, so students in Indore don't have to choose between the two or join separate coaching." },
    { q: "Are demo classes available?", a: "Yes, we offer free demo classes at our Indore centre so you can experience our teaching methodology before enrolling. Call +91-95757-76655 or fill the form above to book your demo." },
    { q: "How are mock tests conducted?", a: "We conduct regular IPMAT & CUET-UG pattern mock tests in a simulated exam environment at our centre. Each test is followed by detailed analysis and one-on-one feedback to help students improve systematically." },
    { q: "What subjects are covered in CUET preparation?", a: "For Commerce: Accountancy, Economics, Business Studies, English, and General Test. For Science: Physics, Chemistry, Maths/Biology, English, and General Test. All subjects follow the latest CUET-UG syllabus with board alignment." },
    { q: "Which is the best IPMAT coaching in Indore?", a: "Dalmia Academy is among the best IPMAT coaching institutes in Indore with structured preparation for IIM Indore's IPM program and other IIM IPMAT exams. Our integrated approach covers Quantitative Ability, Verbal Ability, and Logical Reasoning alongside board preparation at our Geeta Bhawan Square centre." },
    { q: "What are the CUET coaching fees in Indore at Dalmia Academy?", a: "Our CUET & IPMAT coaching fees are competitive and affordable with flexible payment options. We offer Board + CUET integrated preparation so students save on separate coaching costs. Contact us at +91-95757-76655 for current batch and fee details." },
    { q: "Can Dalmia Academy help with IIM Indore IPM preparation?", a: "Yes! Our IPMAT coaching in Indore specifically targets IIM Indore's IPM program along with other IIM IPMAT exams. The integrated syllabus covers all sections — Quantitative Ability, Verbal Ability — with dedicated mock tests and doubt-clearing sessions." },
  ],
  testimonials: [
    { name: "Priya S.", text: "Dalmia Academy made CUET preparation stress-free. The concept-based approach helped me understand topics deeply instead of just memorizing. I felt fully confident on exam day.", course: "Commerce CUET" },
    { name: "Arjun M.", text: "The small batch size meant I could always ask questions. Mock tests were exactly like the real CUET. The faculty's personal attention made all the difference in my preparation.", course: "Science CUET" },
    { name: "Sneha R.", text: "I was worried about managing both Board exams and CUET, but Dalmia Academy's integrated approach covered everything seamlessly. Highly recommend for serious aspirants!", course: "Commerce CUET" },
  ],
  leadForm: {
    courseOptions: [
      { value: "Commerce", label: "Commerce IPMAT & CUET-UG Prep" },
      { value: "Science", label: "Science CUET-UG Prep" },
    ],
  },
  finalCTA: {
    headline: "Limited Seats Available —",
    highlightText: "Enroll Early",
    subheadline: "Don't miss your chance to prepare with Indore's best IPMAT & CUET-UG coaching. Book your seat today!",
  },
};

// ─── CA & CS Foundation Content ─────────────────────────────────────
export const caFoundationContent: PageContent = {
  slug: "ca-foundation",
  pageTitle: "Best CA Coaching in Indore | CA Foundation & CSEET — Dalmia Academy",
  metaDescription: "Best CA coaching in Indore since 1991. CA Foundation and CSEET preparation with 90%+ pass rate, small batches of 25, expert faculty & personal mentorship at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best CA Coaching in Indore —",
    highlightText: "CA Foundation & CSEET",
    subheadline: "Indore's most trusted CA coaching since 1991. Structured preparation with 90%+ first-attempt pass rate, small batches of 25, and personal mentorship at Dalmia Academy, Geeta Bhawan Square, AB Road.",
    benefits: ["Free Demo Available", "90%+ Pass Rate", "Batches of 25", "30+ Years in Indore"],
    stats: [
      { value: "30+", label: "Years in Indore" },
      { value: "1000+", label: "CA Students Guided" },
      { value: "90%+", label: "First-Attempt Pass Rate" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best CA Coaching in Indore",
    subheading: "Unlike out-of-city online-only institutes, Dalmia Academy is a real Indore classroom institute since 1991 — located at Geeta Bhawan Square, AB Road",
    benefits: [
      { icon: HeartHandshake, title: "30+ Years of CA Coaching in Indore", desc: "Dalmia Academy has been preparing CA aspirants in Indore since 1991. Over three decades of classroom coaching at Geeta Bhawan Square means thousands of students have walked through our doors and cleared their CA Foundation on the first attempt. No other CA coaching in Indore matches this track record." },
      { icon: Users, title: "Senior Faculty with 25-35+ Years Experience", desc: "Our CA Foundation faculty includes Pramod Dalmia Sir (35+ years, Accounts & Economics), Rakesh Thakur Sir (36+ years, Accountancy), and Ajay Bagodiya Sir (35+ years, Business Law). This depth of teaching experience is unmatched among CA coaching classes in Indore." },
      { icon: Brain, title: "Concept-Based Teaching, Not Rote Learning", desc: "We focus on building deep conceptual clarity in Accounting, Business Law, Economics, and Quantitative Aptitude. Students understand the 'why' behind every concept, which helps them tackle new question patterns in ICAI exams confidently." },
      { icon: ClipboardCheck, title: "ICAI-Pattern Mock Tests & Performance Analysis", desc: "Regular mock tests designed on the exact ICAI exam pattern with detailed performance analysis. Each student receives individual feedback on strengths and weak areas, so they can focus their revision strategically before the CA Foundation exam." },
      { icon: BookOpen, title: "Small Batches of 25 Students Only", desc: "Every CA Foundation and CSEET batch is strictly limited to 25 students. This ensures personal attention, thorough doubt resolution, and a focused learning environment — something large CA coaching centres in Indore simply cannot offer." },
      { icon: Target, title: "1-on-1 Mentorship & Career Guidance", desc: "Beyond classroom teaching, every student gets personal mentorship from senior faculty. From study planning and time management to career guidance for CA Intermediate and beyond — we support students at every step of their Chartered Accountancy journey." },
    ],
  },
  courses: {
    heading: "CA Foundation & CSEET Courses in Indore",
    subheading: "Structured programs for aspiring Chartered Accountants and Company Secretaries at our Indore centre",
    items: [
      { icon: ClipboardCheck, title: "CA Foundation Coaching", subjects: ["Accounting", "Business Law", "Business Economics", "Quantitative Aptitude"], desc: "Complete CA Foundation preparation covering all four ICAI papers. Includes concept clarity sessions, previous year paper practice, ICAI-pattern mock tests, and one-on-one mentorship for first-attempt success. Ideal for Class 12 Commerce students in Indore." },
      { icon: BookOpen, title: "CSEET (CS Foundation) Coaching", subjects: ["Business Environment & Law", "Business Management", "Economics", "Accounting Fundamentals"], desc: "Comprehensive CSEET preparation with structured study plans aligned to ICSI syllabus. Regular practice tests, doubt-clearing sessions, and exam strategy guidance to help Indore students clear the Company Secretary entrance on their first attempt." },
    ],
  },
  highlights: {
    heading: "What Makes Our CA Coaching Different",
    subheading: "A structured approach designed specifically for CA Foundation and CSEET success in Indore",
    items: [
      { icon: Layers, title: "CA Foundation Syllabus Breakdown", desc: "All four papers — Accounting, Business Law, Economics, Quantitative Aptitude — taught in structured modules with clear milestones" },
      { icon: FileText, title: "ICAI Previous Year Paper Practice", desc: "Solve 10+ years of previous CA Foundation papers under exam conditions with faculty-guided answer review" },
      { icon: HelpCircle, title: "Daily Doubt-Clearing Sessions", desc: "Dedicated doubt-clearing slots every day — no student leaves with an unresolved question" },
      { icon: Target, title: "Individual Study Plans", desc: "Each student receives a personalized study plan based on their strengths, weaknesses, and exam timeline" },
      { icon: BarChart3, title: "Weekly Progress Reports", desc: "Detailed weekly assessments tracking chapter-wise progress so students and parents know exactly where they stand" },
      { icon: RefreshCw, title: "Revision Cycles Before Exam", desc: "Three structured revision rounds covering all chapters, with focused revision tests and quick-reference summary sheets" },
    ],
  },
  faqs: [
    { q: "Which is the best CA coaching in Indore?", a: "Dalmia Academy is widely regarded as the best CA coaching in Indore with 30+ years of classroom teaching experience since 1991. Located at Geeta Bhawan Square on AB Road, we offer small batches of 25 students, 90%+ first-attempt pass rate, and faculty with 25-35+ years of experience. Unlike out-of-city institutes that offer only online classes for Indore, Dalmia Academy provides genuine in-person CA Foundation coaching." },
    { q: "What is the CA Foundation syllabus covered at Dalmia Academy?", a: "We cover the complete ICAI CA Foundation syllabus across all four papers: Paper 1 — Accounting (Financial Statements, Partnership, Company Accounts), Paper 2 — Business Law (Indian Contract Act, Companies Act, GST), Paper 3 — Business Economics & Business and Commercial Knowledge, and Paper 4 — Quantitative Aptitude (Maths, Statistics, Logical Reasoning). Each paper is taught by a specialist faculty member." },
    { q: "What is the fee structure for CA coaching in Indore at Dalmia Academy?", a: "Our CA Foundation coaching fees are competitive and affordable compared to other CA coaching classes in Indore. We offer flexible payment options. Please contact us at +91-95757-76655 or fill the enquiry form above for the current fee structure and batch details." },
    { q: "What is the success rate of CA Foundation students?", a: "Dalmia Academy maintains a 90%+ first-attempt pass rate for CA Foundation students. Our structured approach combining concept-based teaching, ICAI-pattern mock tests, and personal mentorship ensures students are thoroughly prepared. Many of our students have scored distinction marks in CA Foundation." },
    { q: "Do you offer demo classes for CA Foundation coaching?", a: "Yes, we offer free demo classes so you can experience our teaching methodology and meet our faculty before enrolling. Simply fill out the form above or call us at +91-95757-76655 to book your free demo session at our Geeta Bhawan Square centre." },
    { q: "How is Dalmia Academy different from other CA coaching in Indore?", a: "Three key differences: (1) We are a real Indore classroom institute since 1991, not an out-of-city branch or online-only centre. (2) Our batches are strictly limited to 25 students for personal attention. (3) Our faculty includes practitioners with 25-35+ years of teaching experience. Most large CA coaching centres have 50-100+ students per batch and rely on video lectures." },
    { q: "Is CSEET coaching also available?", a: "Yes. Along with CA Foundation, we offer complete CSEET (Company Secretary Executive Entrance Test) coaching covering all four sections: Business Environment & Law, Business Management, Economics, and Accounting Fundamentals. The same quality of small batches and personal mentorship applies to CSEET students." },
    { q: "What batch timings are available for CA Foundation?", a: "We offer flexible batch timings including morning and evening batches to accommodate students who are also preparing for Class 12 board exams or attending college. Offline classes are held at our centre at 108-109, Tulsi Tower, Geeta Bhawan Square, AB Road, Indore. Contact us for the current batch schedule." },
  ],
  testimonials: [
    { name: "Rahul K.", text: "Dalmia Academy's CA Foundation coaching gave me the conceptual clarity I needed. The mock tests were exactly like the real exam. Cleared in my first attempt!", course: "CA Foundation" },
    { name: "Ananya T.", text: "The small batch size meant every doubt was addressed. Faculty with 30+ years experience made complex topics simple. Highly recommended for serious aspirants.", course: "CSEET" },
    { name: "Vikram P.", text: "The personalized mentorship kept me focused throughout. The structured approach and regular assessments made all the difference in my preparation.", course: "CA Foundation" },
  ],
  leadForm: {
    courseOptions: [
      { value: "CA Foundation", label: "CA Foundation Prep" },
      { value: "CSEET", label: "CSEET (CS Foundation) Prep" },
    ],
  },
  finalCTA: {
    headline: "Start Your CA Journey in Indore —",
    highlightText: "Sahi Guidance. Sahi Direction.",
    subheadline: "Limited seats in each batch. Book your free demo today at Dalmia Academy, Geeta Bhawan Square, and take the first step toward becoming a Chartered Accountant!",
  },
};

// ─── 11th & 12th Commerce Content ───────────────────────────────────
export const commerceContent: PageContent = {
  slug: "commerce-coaching",
  pageTitle: "Best Commerce Coaching in Indore | 11th & 12th — Dalmia Academy",
  metaDescription: "Best commerce coaching in Indore for Class 11 & 12. Board + CA/CS integrated preparation with Applied Maths, small batches & 30+ years experience at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best Commerce Coaching in Indore —",
    highlightText: "Score 90%+ & Prepare for CA/CS",
    subheadline: "Indore's most trusted commerce coaching since 1991. Build strong concepts in Accountancy, Economics & Business Studies with Board + CA/CS integrated preparation at Dalmia Academy, Geeta Bhawan Square.",
    benefits: ["Board + CA/CS Integrated", "30+ Years in Indore", "Batches of 25", "Applied Maths Available"],
    stats: [
      { value: "30+", label: "Years Experience" },
      { value: "1000+", label: "Students Guided" },
      { value: "25", label: "Max Batch Size" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best Commerce Coaching in Indore",
    subheading: "Indore's most trusted commerce coaching with 30+ years of proven results in board & competitive exam preparation since 1991",
    benefits: [
      { icon: Layers, title: "Board + CA/CS Integrated Prep", desc: "Simultaneous preparation for Board exams along with CA, CS & CUET foundation — no need to choose between them. Our commerce coaching in Indore saves students a full year of separate coaching by integrating professional exam prep into the school syllabus." },
      { icon: HeartHandshake, title: "30+ Years of Commerce Coaching in Indore", desc: "Since 1991, Dalmia Academy has been Indore's most trusted commerce coaching institute. Three decades of classroom teaching at Geeta Bhawan Square means thousands of commerce students have built their careers from this very centre." },
      { icon: Brain, title: "Concept-Based Teaching", desc: "Deep conceptual clarity in accounts coaching in Indore, economics tuition in Indore, and Business Studies — not rote learning. Our faculty uses real-world examples and case studies to make concepts stick for board exams and CA/CS preparation." },
      { icon: BookOpen, title: "Small Batches of 25 Students", desc: "Every 11th & 12th coaching in Indore batch is strictly limited to 25 students. This ensures personal attention, thorough doubt resolution, and individual focus that large coaching centres cannot match." },
      { icon: ClipboardCheck, title: "Exam Strategy & Board Exam Coaching", desc: "Time management, answer presentation, and scoring techniques for CBSE and MP Board exams. Our board exam coaching in Indore trains students to write high-scoring answers for Accountancy, Economics, and theory papers." },
      { icon: Target, title: "Career Guidance & Mentorship", desc: "Students seeking commerce tuition near me in Indore will find Dalmia Academy at Geeta Bhawan Square easily accessible. One-on-one mentorship for CA, CS, CMA, MBA — guiding students from Class 11 itself." },
    ],
  },
  courses: {
    heading: "Subjects We Cover",
    subheading: "Comprehensive coaching for all Commerce subjects with Board + competitive exam alignment",
    items: [
      { icon: ClipboardCheck, title: "Accountancy", subjects: ["Financial Statements", "Partnership", "Company Accounts", "Practice Sheets"], desc: "Strong fundamentals with structured practice sheets and exam-level questions for confident board performance." },
      { icon: BarChart3, title: "Economics", subjects: ["Micro Economics", "Macro Economics", "Indian Economy", "Real-life Examples"], desc: "Micro & macro concepts explained with real-life examples for deep understanding and easy retention." },
      { icon: BookOpen, title: "Business Studies", subjects: ["Management Principles", "Business Finance", "Marketing", "Board Pattern Writing"], desc: "Simplified explanations with board-pattern writing practice to score maximum marks in theory papers." },
      { icon: Brain, title: "Applied Maths", subjects: ["Algebra", "Calculus", "Probability", "Linear Programming"], desc: "Step-by-step concept clarity for boards & entrance exams — perfect for students opting for Applied Maths." },
    ],
  },
  highlights: {
    heading: "Our Teaching Method",
    subheading: "A structured approach designed to build strong foundations and deliver top results",
    items: [
      { icon: BookMarked, title: "Foundation Building", desc: "Strong basics built in Class 11 to ensure smooth and confident learning in Class 12" },
      { icon: FileText, title: "Structured Practice", desc: "Regular assignments, chapter tests, and mock exams to reinforce learning continuously" },
      { icon: RefreshCw, title: "Revision Strategy", desc: "Multiple revision cycles before board exams to ensure thorough preparation and retention" },
      { icon: Target, title: "Exam Strategy Guidance", desc: "Time management, answer presentation, and scoring techniques for maximum marks" },
      { icon: Layers, title: "Integrated CA/CS Preparation", desc: "Foundation-level preparation for CA & CS runs alongside board coaching seamlessly" },
      { icon: HeartHandshake, title: "Career Guidance & Mentorship", desc: "Personalized career counseling to help students choose the right professional path" },
    ],
  },
  faqs: [
    { q: "Which is the best commerce coaching in Indore?", a: "Dalmia Academy is widely regarded as the best commerce coaching in Indore with 30+ years of experience since 1991. We offer Board + CA/CS integrated preparation, Applied Maths, small batches of 25, and faculty with decades of teaching expertise — all at our Geeta Bhawan Square centre." },
    { q: "Are demo classes available?", a: "Yes! We offer free demo classes at our Indore centre so you can experience our teaching methodology and faculty quality before enrolling. Call +91-95757-76655 or fill the form above to book your demo session." },
    { q: "Is Applied Maths included in the coaching?", a: "Absolutely. We offer complete Applied Maths coaching as part of our commerce coaching in Indore, covering Algebra, Calculus, Probability, and Linear Programming — all topics required for board exams and entrance tests." },
    { q: "Do you prepare students for CUET/CA along with board exams?", a: "Yes. Our integrated approach covers Board syllabus alongside foundation-level preparation for CA, CS & CUET — so students are ready for multiple opportunities after 12th. This Board + CA/CS integration is a key strength of our commerce coaching." },
    { q: "What boards do you cover for commerce coaching?", a: "We provide commerce coaching for both CBSE and MP Board students in Indore. Our preparation is tailored to each board's specific syllabus, exam patterns, and marking schemes." },
    { q: "Do you offer 11th Commerce coaching separately from 12th?", a: "Yes. We offer separate coaching for Class 11 Commerce and Class 12 Commerce in Indore. Class 11 focuses on building strong foundations in Accountancy, Economics, and Business Studies. Class 12 is more board-focused with mock exams, revision cycles, and exam strategy." },
    { q: "What are the commerce coaching fees in Indore at Dalmia Academy?", a: "Our commerce coaching fees are affordable with flexible payment options. Contact us at +91-95757-76655 or fill the enquiry form for the current fee structure and batch details at our Geeta Bhawan Square centre." },
  ],
  testimonials: [
    { name: "Riya P.", text: "Dalmia Academy's Commerce coaching helped me score 95%+ in boards. The integrated CA Foundation prep saved me a year of separate coaching. Best decision ever!", course: "12th Commerce" },
    { name: "Kunal S.", text: "Applied Maths was made so easy here. The step-by-step approach and regular practice tests built my confidence. Faculty with 30+ years experience truly makes a difference.", course: "11th Commerce" },
    { name: "Pooja M.", text: "The small batch size meant every doubt was cleared on the spot. Board + CUET integrated preparation was exactly what I needed. Highly recommend for commerce students in Indore!", course: "12th Commerce" },
  ],
  leadForm: {
    courseOptions: [
      { value: "11th Commerce", label: "11th Commerce" },
      { value: "12th Commerce", label: "12th Commerce" },
    ],
  },
  finalCTA: {
    headline: "Strong Foundation Today =",
    highlightText: "Successful Career Tomorrow",
    subheadline: "Sahi Guidance. Sahi Direction. Banayein Strong Foundation at Dalmia Academy, Indore — Limited seats available. Enroll now!",
  },
};

// ─── 11th & 12th Science Content ────────────────────────────────────
export const scienceContent: PageContent = {
  slug: "science-coaching",
  pageTitle: "Best 11th & 12th Science Coaching in Indore | Dalmia Academy",
  metaDescription: "Build strong concepts, score 90%+ & prepare for JEE/NEET with the best Science coaching in Indore at Dalmia Academy. CBSE & MP Board.",
  hero: {
    headline: "Strong Concepts. Top Results.",
    highlightText: "Score 90%+ in Science",
    subheadline: "Science in Classes 11 & 12 is the foundation of your future career — whether you aim for Engineering, Medical, Research, or Competitive Exams. At Dalmia Academy, we ensure strong conceptual clarity and board exam excellence.",
    benefits: ["CBSE & MP Board", "JEE/NEET Foundation", "Small Batches", "Experienced Faculty"],
    stats: [
      { value: "30+", label: "Years Experience" },
      { value: "1000+", label: "Students Guided" },
      { value: "25", label: "Max Batch Size" },
    ],
  },
  whyChoose: {
    heading: "Why Choose Dalmia Academy for Science?",
    subheading: "Indore's most trusted Science coaching with 30+ years of proven results in board & competitive exam preparation",
    benefits: [
      { icon: Brain, title: "Concept-Based Learning", desc: "Focus on understanding fundamentals deeply rather than memorization, building lasting knowledge for boards and beyond." },
      { icon: ClipboardCheck, title: "Regular Tests & Performance Tracking", desc: "Chapter tests, revision tests, and pre-board mocks with detailed analysis to track progress continuously." },
      { icon: BookOpen, title: "Small Batch Size", desc: "Batches limited to 25 students ensuring personal attention, thorough doubt resolution and individual focus." },
      { icon: Users, title: "Experienced Faculty", desc: "Learn from educators with 30+ years of academic excellence in Science coaching and mentorship." },
      { icon: FileText, title: "Structured Notes & Assignments", desc: "Curated study material and assignments aligned with board expectations for efficient and focused preparation." },
      { icon: Target, title: "Competitive Exam Readiness", desc: "Strong fundamentals that naturally support JEE/NEET/NDA/CUET foundation without additional coaching burden." },
    ],
  },
  courses: {
    heading: "Subjects We Cover",
    subheading: "Comprehensive coaching for all Science subjects with Board + competitive exam alignment",
    items: [
      { icon: Atom, title: "Physics", subjects: ["Mechanics", "Electrodynamics", "Optics", "Numericals & Derivations"], desc: "Concept-first approach with extensive numerical practice and derivation clarity for confident board performance." },
      { icon: FlaskConical, title: "Chemistry", subjects: ["Physical Chemistry", "Organic Chemistry", "Inorganic Chemistry", "Exam-Focused Questions"], desc: "Physical, Organic & Inorganic Chemistry with structured notes and exam-focused question practice." },
      { icon: Calculator, title: "Mathematics", subjects: ["Calculus", "Algebra", "Coordinate Geometry", "Board-Pattern Practice"], desc: "Step-by-step problem-solving techniques with board-pattern writing practice for maximum marks." },
      { icon: Leaf, title: "Biology", subjects: ["Botany", "Zoology", "Diagrams & Practicals", "Answer Presentation"], desc: "Diagram-based learning with conceptual clarity and answer presentation guidance for scoring excellence." },
    ],
  },
  highlights: {
    heading: "Our Teaching Approach",
    subheading: "A structured approach designed to build strong foundations and deliver top results",
    items: [
      { icon: BookMarked, title: "Strong Foundation in Class 11", desc: "Solid basics built in Class 11 so students don't struggle in Class 12" },
      { icon: FileText, title: "Intensive Class 12 Preparation", desc: "Board-focused writing practice and scoring strategy for maximum marks" },
      { icon: Target, title: "JEE/NEET Foundation Readiness", desc: "Strong fundamentals that naturally support competitive exam preparation" },
      { icon: HelpCircle, title: "Doubt Sessions & Personalized Guidance", desc: "Dedicated doubt-clearing sessions to ensure no question goes unanswered" },
      { icon: BarChart3, title: "Exam Strategy & Time Management", desc: "Learn to manage exam time effectively with timed practice and planning" },
      { icon: HeartHandshake, title: "Motivation & Discipline", desc: "Continuous mentorship to keep students focused, motivated and disciplined" },
    ],
  },
  faqs: [
    { q: "Do you teach both CBSE & MP Board?", a: "Yes! We provide separate focused coaching for both CBSE and MP Board students, ensuring each student gets preparation aligned with their specific board requirements and exam patterns." },
    { q: "Is competitive exam preparation included?", a: "Our focus is on building strong fundamentals through concept-based teaching. This naturally supports JEE/NEET foundation preparation. Students develop the depth of understanding needed for competitive exams alongside board excellence." },
    { q: "Are demo classes available?", a: "Yes, we offer free demo classes so you can experience our teaching methodology and faculty quality before enrolling. Simply fill out the form above or call us to book your demo session." },
  ],
  testimonials: [
    { name: "Amit R.", text: "Dalmia Academy's Science coaching helped me score 95%+ in boards. The concept-based approach made Physics and Chemistry so much easier to understand. Highly recommended!", course: "12th Science PCM" },
    { name: "Neha S.", text: "The small batch size meant every doubt was cleared on the spot. Biology diagrams and answer presentation techniques were game-changers for my board exam.", course: "12th Science PCB" },
    { name: "Rohan K.", text: "The structured approach from Class 11 made Class 12 feel manageable. Mock tests exactly matched board patterns. Best coaching decision I made!", course: "11th Science PCM" },
  ],
  leadForm: {
    courseOptions: [
      { value: "PCM", label: "PCM (Physics, Chemistry, Maths)" },
      { value: "PCB", label: "PCB (Physics, Chemistry, Biology)" },
    ],
  },
  finalCTA: {
    headline: "Strong Concepts Today =",
    highlightText: "Bright Future Tomorrow",
    subheadline: "Sahi Guidance. Sahi Direction. Banayein Strong Foundation — Limited seats available. Enroll now!",
  },
};

// ─── 6th to 10th School Coaching Content ────────────────────────────
export const schoolContent: PageContent = {
  slug: "school-coaching",
  pageTitle: "Best Class 6 to 10 Coaching in Indore | Maths, Science Tuition — Dalmia Academy",
  metaDescription: "Best coaching for Class 6 to 10 in Indore. Maths, Science, English tuition near Geeta Bhawan Square. Class 9 & 10 board exam prep with small batches at Dalmia Academy.",
  hero: {
    headline: "Best Class 6 to 10 Coaching in Indore —",
    highlightText: "Maths, Science & All Subjects",
    subheadline: "Looking for Class 9 or Class 10 coaching in Indore? Dalmia Academy near Geeta Bhawan Square offers expert Maths, Science, English tuition with small batches, CBSE & MP Board preparation, and personal attention.",
    benefits: ["CBSE & MP Board", "Maths & Science Focus", "Small Batches of 25", "Near Geeta Bhawan"],
    stats: [
      { value: "30+", label: "Years Experience" },
      { value: "1000+", label: "Students Guided" },
      { value: "25", label: "Max Batch Size" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best Coaching for Class 6–10 in Indore",
    subheading: "Indore's most trusted school coaching with 30+ years of academic excellence — near Geeta Bhawan Square, AB Road",
    benefits: [
      { icon: HeartHandshake, title: "30+ Years of Coaching in Indore", desc: "Since 1991, Dalmia Academy has been building strong academic foundations for school students in Indore. Parents trust us because of three decades of consistent results at our Geeta Bhawan Square centre." },
      { icon: Users, title: "Expert Maths & Science Coaching in Indore", desc: "Our maths coaching in Indore and science coaching in Indore builds strong fundamentals from Class 6. Faculty with deep subject expertise adapt teaching to each student's pace and board requirements." },
      { icon: BookOpen, title: "Small Batches — Class 9 & 10 Focus", desc: "Every batch limited to 25 students. Whether your child needs class 10 coaching in Indore or class 9 tuition in Indore, our small batches ensure individual attention and thorough doubt resolution." },
      { icon: Brain, title: "CBSE & MP Board Coaching", desc: "Dedicated CBSE coaching in Indore and MP Board preparation — separate study plans, exam patterns, and marking scheme guidance for each board. We understand both boards inside out." },
      { icon: RefreshCw, title: "Tuition Classes Near Me — Geeta Bhawan", desc: "Searching for tuition classes near me in Indore? Dalmia Academy at Geeta Bhawan Square is easily accessible from Vijay Nagar, Palasia, Sapna Sangeeta, and central Indore areas." },
      { icon: Target, title: "Board Exam Preparation in Indore", desc: "Strong board exam preparation in Indore for Class 9 and 10 — mock tests, answer writing practice, time management, and parent-teacher feedback. Class 10 students get dedicated pre-board simulation." },
    ],
  },
  courses: {
    heading: "Subjects We Cover",
    subheading: "Comprehensive coaching for all major subjects from Class 6th to 10th",
    items: [
      { icon: Calculator, title: "Mathematics", subjects: ["Arithmetic", "Algebra", "Geometry", "Daily Practice"], desc: "Strong fundamentals with daily practice and problem-solving to build mathematical confidence." },
      { icon: FlaskConical, title: "Science", subjects: ["Physics", "Chemistry", "Biology", "Practical Explanations"], desc: "Concept-based learning with practical explanations that make Science easy and interesting." },
      { icon: PenLine, title: "English", subjects: ["Grammar", "Comprehension", "Writing Skills", "Literature"], desc: "Grammar, comprehension, and writing skills development for strong language command." },
      { icon: Globe, title: "Social Science", subjects: ["History", "Geography", "Civics", "Structured Notes"], desc: "Simplified concepts with structured notes for easy understanding and exam readiness." },
      { icon: Languages, title: "Hindi", subjects: ["Vyakaran", "Sahitya", "Lekhan", "Pariksha Taiyari"], desc: "Balanced academic growth across language subjects with focus on grammar and writing." },
    ],
  },
  highlights: {
    heading: "Our Teaching Approach",
    subheading: "A structured method designed to build strong foundations and deliver academic excellence",
    items: [
      { icon: Brain, title: "Concept-Based Learning", desc: "Simplified with examples and practical explanations for deep understanding" },
      { icon: ClipboardCheck, title: "Regular Practice & Homework Review", desc: "Daily practice sessions with performance tracking to ensure consistent progress" },
      { icon: HelpCircle, title: "Doubt Solving Sessions", desc: "No student left confused — dedicated sessions to clear every doubt thoroughly" },
      { icon: BarChart3, title: "Test Series & Report Analysis", desc: "Regular unit tests with detailed reports and parent feedback for improvement" },
      { icon: FileText, title: "Answer Writing Skills", desc: "Focused training especially for Class 9th & 10th board exam preparation" },
      { icon: BookMarked, title: "Board-Oriented Prep for 9th & 10th", desc: "Mock tests, time management, and exam presentation strategies for board success" },
    ],
  },
  faqs: [
    { q: "Do you offer Class 9 coaching near me in Indore?", a: "Yes! Dalmia Academy offers Class 9 coaching in Indore at our centre near Geeta Bhawan Square on AB Road. We are easily accessible from Vijay Nagar, Palasia, Sapna Sangeeta, and other central Indore areas. Our Class 9 coaching covers all subjects with board-oriented preparation." },
    { q: "Do you teach both CBSE & MP Board?", a: "Yes! We provide coaching for both CBSE and MP Board students from Class 6 to 10. Our preparation is tailored to each board's specific requirements, exam patterns, and marking schemes." },
    { q: "What classes do you offer coaching for in Indore?", a: "We offer comprehensive coaching from Class 6th to 10th for all major subjects including Mathematics, Science, English, Social Science, and Hindi. Our Indore centre at Geeta Bhawan Square has separate batches for each class level." },
    { q: "Are demo classes available?", a: "Yes, free demo classes are available so you can experience our teaching methodology before enrolling. Call +91-9575776655 or visit our centre at 108-109 Tulsi Tower, Geeta Bhawan Square, AB Road, Indore to book your demo." },
    { q: "How are Class 9 and 10 students prepared for board exams?", a: "For Class 9 and 10, we provide board-oriented preparation including mock tests in exam conditions, structured answer writing practice, time management strategies, and regular parent-teacher feedback. Our small batch size of 25 ensures every student gets personal attention during this critical stage." },
  ],
  testimonials: [
    { name: "Ankit P.", text: "My son's grades improved significantly after joining Dalmia Academy. The concept-based teaching made Maths and Science so much easier for him. Highly recommend!", course: "Class 8th" },
    { name: "Meera S.", text: "The small batch size means my daughter gets personal attention. The teachers are patient and ensure every doubt is cleared. Best coaching for school students in Indore!", course: "Class 10th" },
    { name: "Rajesh K.", text: "Dalmia Academy's structured approach prepared my child perfectly for board exams. The mock tests and answer writing practice were game-changers.", course: "Class 9th" },
  ],
  leadForm: {
    courseOptions: [
      { value: "Class 6th-8th", label: "Class 6th–8th" },
      { value: "Class 9th-10th", label: "Class 9th–10th" },
    ],
  },
  finalCTA: {
    headline: "Build the Right Foundation from Class 6.",
    highlightText: "Sahi Guidance. Sahi Direction.",
    subheadline: "Banayein Strong Foundation at Dalmia Academy, Indore. Book your free demo class today!",
  },
};

// ─── Spoken English & Personality Development Content ───────────────
export const spokenEnglishContent: PageContent = {
  slug: "spoken-english",
  pageTitle: "Best Spoken English Classes in Indore | Personality Development — Dalmia Academy",
  metaDescription: "Best spoken English classes in Indore. English speaking course, personality development & interview prep at Dalmia Academy, Geeta Bhawan Square. Beginner to advanced batches.",
  hero: {
    headline: "Best Spoken English Classes in Indore —",
    highlightText: "Speak Confidently in 90 Days",
    subheadline: "Looking for spoken English classes in Indore? At Dalmia Academy, Geeta Bhawan Square, we train you to think in English, speak naturally, and build a powerful personality — through daily practice and personal coaching.",
    benefits: ["Daily Speaking Practice", "Small Batches", "Interview Prep", "Near Geeta Bhawan"],
    stats: [
      { value: "90", label: "Days Program" },
      { value: "1:1", label: "Personal Attention" },
      { value: "100%", label: "Real-Life Practice" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best for Spoken English Classes in Indore",
    subheading: "Indore's trusted English speaking course with personal coaching, small batches & real communication focus at Geeta Bhawan Square",
    benefits: [
      { icon: Users, title: "Daily Speaking Practice", desc: "Speak from Day 1 — no passive listening. Every session at our Indore centre is built around active conversation and real practice. Unlike large spoken English classes in Indore, we ensure every student speaks in every class." },
      { icon: HeartHandshake, title: "Fear Removal Training", desc: "Structured exercises to remove hesitation, stage fear, and nervousness in social and professional settings. Our trainers at Geeta Bhawan Square specialize in helping shy students speak with confidence." },
      { icon: Target, title: "Body Language & Personality Coaching", desc: "Learn posture, tone, eye contact, and overall presence to make a lasting impression — complete personality development alongside your English speaking course in Indore." },
      { icon: ClipboardCheck, title: "Interview & Career Preparation", desc: "Mock interviews, role plays, group discussions, and real-life scenarios to prepare you for placements and career success. Hundreds of Indore students have cracked interviews after this program." },
      { icon: BookOpen, title: "Small Batches for Personal Attention", desc: "Individual correction and feedback in every session ensures rapid improvement and confidence building. Our English coaching in Indore maintains small batches unlike large commercial institutes." },
      { icon: Brain, title: "Real Communication, Not Textbook Grammar", desc: "Not rote grammar rules — real confidence building through practical, everyday English communication. We teach you to think in English and express yourself naturally in any situation." },
    ],
  },
  courses: {
    heading: "Programs Offered",
    subheading: "Choose the program that fits your goals and timeline",
    items: [
      { icon: BookOpen, title: "3-Month Confidence Builder", subjects: ["Sentence Formation", "Pronunciation", "Vocabulary", "Everyday Conversation", "Confidence Development"], desc: "Basic to advanced English speaking skills with daily practice, vocabulary building, and confidence development." },
      { icon: Target, title: "6-Month Advanced Mastery", subjects: ["Corporate English", "Public Speaking", "Group Discussions", "Interview Mastery", "Professional Etiquette"], desc: "Advanced program covering corporate communication, public speaking, and professional personality development." },
    ],
  },
  highlights: {
    heading: "Who Should Join & What You'll Achieve",
    subheading: "This program is for anyone who wants to speak English confidently and develop a powerful personality",
    items: [
      { icon: Users, title: "College Students", desc: "Build communication skills before your career starts — stand out in placements and interviews" },
      { icon: ClipboardCheck, title: "Job Seekers", desc: "Crack interviews and group discussions confidently with polished English and presentation skills" },
      { icon: HeartHandshake, title: "Working Professionals", desc: "Improve workplace communication, lead meetings, and command respect in professional settings" },
      { icon: Brain, title: "Speak Fluently Without Hesitation", desc: "Break the fear barrier and express yourself naturally in any conversation" },
      { icon: Target, title: "Develop a Strong Personality", desc: "Build confidence, improve body language, and create a lasting impression" },
      { icon: BookOpen, title: "Command Respect in Conversations", desc: "Speak with clarity, conviction, and confidence that earns respect everywhere" },
    ],
  },
  faqs: [
    { q: "Which is the best spoken English classes in Indore?", a: "Dalmia Academy is widely regarded as one of the best for spoken English classes in Indore. Located at Geeta Bhawan Square on AB Road, our English speaking course focuses on real communication and daily speaking practice with small batches and experienced trainers including Anand Potdar Sir with 20+ years of communication coaching experience." },
    { q: "What is the fee for spoken English classes in Indore?", a: "Our spoken English course fees are affordable and competitive compared to other English coaching in Indore. We offer 3-month and 6-month programs with flexible payment options. Contact us at +91-95757-76655 for the current fee structure." },
    { q: "Who can join this English speaking course in Indore?", a: "College students, job seekers, working professionals, homemakers — anyone who wants to improve their English speaking confidence and personality. No prior fluency required. Our spoken English near me classes at Geeta Bhawan Square are accessible to all of central Indore." },
    { q: "What is the batch size for English classes?", a: "We keep small batches to ensure personal attention and individual feedback. This allows our trainers to focus on each student's specific improvement areas — unlike large commercial English coaching centres in Indore." },
    { q: "Do you offer personality development along with spoken English?", a: "Yes! Our program includes complete personality development — body language, confidence building, interview preparation, public speaking, and group discussions. It's a full personality development course in Indore, not just grammar classes." },
    { q: "Are demo classes available for spoken English?", a: "Yes! Contact us at +91-95757-76655 or visit our centre at 108-109, Tulsi Tower, Geeta Bhawan Square, AB Road, Indore for a free demo session. Experience our teaching methodology before enrolling." },
  ],
  testimonials: [],
  leadForm: {
    courseOptions: [
      { value: "3-Month", label: "3-Month Confidence Builder" },
      { value: "6-Month", label: "6-Month Advanced Mastery" },
    ],
  },
  finalCTA: {
    headline: "Your Confidence Upgrade",
    highlightText: "Starts Today.",
    subheadline: "Speak Better. Think Better. Grow Faster. Join Dalmia Academy Today!",
  },
};

// ─── 11th & 12th Humanities Content ────────────────────────────────
export const humanitiesContent: PageContent = {
  slug: "humanities-coaching",
  pageTitle: "Best Humanities Coaching in Indore | 11th & 12th — Dalmia Academy",
  metaDescription: "Best humanities coaching in Indore for Class 11 & 12. Score 85%-95%+ in boards with expert faculty, structured answer writing & small batches at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best Humanities Coaching in Indore —",
    highlightText: "Score 85%-95%+ in Boards",
    subheadline: "Indore's most trusted humanities coaching since 1991. Master Psychology, Political Science, Geography & History with structured answer writing, concept clarity, and personal mentorship at Dalmia Academy, Geeta Bhawan Square.",
    benefits: ["Answer Writing Focus", "Concept Clarity", "Small Batches of 25", "30+ Years in Indore"],
    stats: [
      { value: "30+", label: "Years Experience" },
      { value: "1000+", label: "Students Guided" },
      { value: "25", label: "Max Batch Size" },
    ],
  },
  whyChoose: {
    heading: "Why Dalmia Academy is the Best Humanities Coaching in Indore",
    subheading: "Indore's most trusted humanities coaching with concept-based teaching, structured answer writing, and proven board results since 1991",
    benefits: [
      { icon: Brain, title: "Concept Clarity Over Rote Learning", desc: "We break down complex theories in Psychology, Political Science, Geography, and History into simple, understandable ideas. Our humanities coaching in Indore ensures students truly understand concepts rather than just memorizing textbook answers." },
      { icon: PenLine, title: "Structured Answer Writing Training", desc: "Answer writing is the single biggest scoring differentiator in humanities board exams. We train students to frame structured, well-presented answers for short, long, and source-based questions — a skill most coaching centres in Indore overlook." },
      { icon: Target, title: "Arts & Humanities — All Subjects", desc: "Complete arts coaching in Indore covering Psychology coaching in Indore, sociology, political science tuition Indore, Geography, and History. Each subject is taught by a specialist with board exam expertise." },
      { icon: BookOpen, title: "Small Batches for 11th & 12th Humanities", desc: "Every 11th humanities coaching and 12th humanities coaching batch in Indore is limited to 25 students, ensuring personal attention and individual feedback on answer writing." },
      { icon: ClipboardCheck, title: "Regular Tests & Performance Tracking", desc: "Chapter tests, pre-board mock exams, and personalized performance reports every month. Students and parents always know exactly where they stand and what areas need improvement." },
      { icon: HeartHandshake, title: "Mentorship & Career Guidance", desc: "Humanities tuition near me? Dalmia Academy at Geeta Bhawan Square is accessible from Vijay Nagar, Palasia & AB Road. One-on-one mentorship for career paths — law, psychology, civil services, journalism, and more." },
    ],
  },
  courses: {
    heading: "Subjects We Cover",
    subheading: "Comprehensive coaching for all Humanities subjects with board exam alignment and answer writing practice",
    items: [
      { icon: BookOpen, title: "Psychology", subjects: ["Human Behavior", "Cognitive Processes", "Therapeutic Approaches", "Case Studies"], desc: "Understanding human behavior, cognitive processes, and psychological concepts with real-life applications and structured answer writing." },
      { icon: BarChart3, title: "Political Science", subjects: ["Indian Constitution", "Political Theory", "Contemporary World Politics", "Indian Government"], desc: "Comprehensive Political Science coaching covering Indian Constitution, political theory, contemporary world politics, and answer writing techniques for board exam excellence." },
      { icon: Globe, title: "Geography", subjects: ["Physical Geography", "Human Geography", "Map Work", "Diagram-Based Answers"], desc: "Physical & human geography with map skills, diagram-based answers, and conceptual clarity for scoring excellence." },
      { icon: BookMarked, title: "History", subjects: ["Modern India", "World History", "Source Analysis", "Long Answer Techniques"], desc: "Modern India and world history with source-based analysis, timeline clarity, and structured long-answer techniques." },
    ],
  },
  highlights: {
    heading: "Our Teaching Approach",
    subheading: "A structured method designed to build conceptual clarity and deliver top board results",
    items: [
      { icon: BookMarked, title: "Strong Foundation in Class 11", desc: "Solid basics built in Class 11 so students don't struggle with advanced topics in Class 12" },
      { icon: FileText, title: "Intensive Class 12 Preparation", desc: "Board-focused writing practice, revision strategy, and scoring techniques for maximum marks" },
      { icon: PenLine, title: "Structured Answer Writing Training", desc: "Learn how to frame perfect answers — short, long, and source-based — for every subject" },
      { icon: ClipboardCheck, title: "Regular Tests & Mock Exams", desc: "Chapter tests, pre-boards, and full-length mock exams in exam-like conditions" },
      { icon: BarChart3, title: "Time Management & Exam Strategy", desc: "Learn to manage exam time effectively and prioritize questions for maximum scoring" },
      { icon: Users, title: "Small Batches, Personal Attention", desc: "Individual feedback and doubt-clearing in every session for rapid improvement" },
    ],
  },
  faqs: [
    { q: "Which is the best humanities coaching in Indore?", a: "Dalmia Academy is widely considered the best humanities coaching in Indore with 30+ years of teaching experience. Located at Geeta Bhawan Square on AB Road, we offer small batches of 25 students, expert faculty for Psychology, Political Science, Geography & History, and structured answer writing training that helps students score 85%-95%+ in board exams." },
    { q: "Are demo classes available?", a: "Yes! We offer free demo classes so you can experience our teaching methodology and faculty quality before enrolling. Simply fill out the form above or call us at +91-95757-76655 to book your demo session at our Geeta Bhawan Square centre." },
    { q: "Do you focus on answer writing skills?", a: "Absolutely. Answer writing is at the core of our humanities coaching in Indore. We train students to frame structured, well-presented answers for short, long, and source-based questions across all subjects — a skill most coaching centres overlook." },
    { q: "How do you prepare students for board exams?", a: "Our approach includes concept clarity, regular chapter tests, mock exams in board-like conditions, structured revision cycles, and personalized feedback to ensure students are fully prepared and confident for both CBSE and MP Board exams." },
    { q: "What subjects are covered in humanities coaching?", a: "We cover Psychology, Political Science, Geography, and History with comprehensive coaching, structured notes, and regular practice. Each subject is taught by a specialist faculty member with years of experience in board exam preparation. (Note: Economics is offered as part of our commerce coaching stream.)" },
    { q: "Who should join this program?", a: "Any student in Class 11 or 12 Humanities (arts) stream in Indore who wants to build strong concepts, improve answer writing, and score 85%-95%+ in board exams. Whether you're struggling or aiming for top marks, our arts and humanities coaching provides the guidance you need." },
    { q: "Do you offer Psychology, Sociology and Political Science coaching in Indore?", a: "Yes. Our humanities coaching in Indore covers Psychology, Political Science, Geography, and History as core subjects, plus Sociology as an optional subject. Each is taught by a specialist faculty member with board exam expertise and structured answer writing training. Economics is offered separately under our commerce coaching program." },
  ],
  testimonials: [
    { name: "Kavya M.", text: "Dalmia Academy's Humanities coaching transformed my approach to answer writing. I scored 92% in boards thanks to their structured preparation method.", course: "12th Humanities" },
    { name: "Aditya S.", text: "Psychology and Political Science became so much easier with concept-based teaching. The small batch meant every doubt was cleared instantly. Highly recommend!", course: "11th Humanities" },
    { name: "Prachi R.", text: "The answer writing training was a game-changer. I went from average marks to 90%+ in my board exams. Best coaching for Humanities students in Indore!", course: "12th Humanities" },
  ],
  leadForm: {
    courseOptions: [
      { value: "11th Humanities", label: "11th Humanities" },
      { value: "12th Humanities", label: "12th Humanities" },
    ],
  },
  finalCTA: {
    headline: "Strong Foundation in 11th. High Scores in 12th.",
    highlightText: "Sahi Guidance. Sahi Direction.",
    subheadline: "Best humanities coaching in Indore — Banayein Strong Foundation at Dalmia Academy, Geeta Bhawan Square. Limited seats available. Book your free demo class today!",
  },
};

// ─── ACCA Content ──────────────────────────────────────────────────
export const accaContent: PageContent = {
  slug: "acca-coaching",
  pageTitle: "Best ACCA Coaching in Indore | Dalmia Academy",
  metaDescription: "Best ACCA coaching in Indore. Prepare for all ACCA papers with expert faculty, structured study plans & small batches at Dalmia Academy, Geeta Bhawan Square. Free counselling available.",
  hero: {
    headline: "Best ACCA Coaching in Indore —",
    highlightText: "Your Gateway to a Global Career",
    subheadline: "Become a globally recognized Chartered Certified Accountant with structured ACCA coaching at Dalmia Academy, Indore. Expert faculty, small batches, and a proven approach to help you clear ACCA papers confidently.",
    benefits: ["Global Recognition", "Expert Faculty", "Small Batches", "Flexible Timings"],
    stats: [
      { value: "30+", label: "Years in Indore" },
      { value: "Global", label: "Career Scope" },
      { value: "13", label: "ACCA Papers" },
    ],
  },
  whyChoose: {
    heading: "Why Choose Dalmia Academy for ACCA Coaching in Indore",
    subheading: "Indore's trusted coaching institute now offering structured ACCA preparation — combining 30+ years of accounting expertise with global curriculum delivery",
    benefits: [
      { icon: Award, title: "Global Qualification, Local Coaching", desc: "ACCA is recognized in over 180 countries. At Dalmia Academy, you get world-class ACCA preparation right here in Indore — no need to travel to Mumbai or Delhi. Our Geeta Bhawan Square centre offers the same quality with personal mentorship that metro cities can't match." },
      { icon: Users, title: "Faculty with Deep Accounting Expertise", desc: "Our faculty includes Pramod Dalmia Sir (35+ years in Accounts), Rakesh Thakur Sir (36+ years), and Mekhala Kanade Ma'am (25+ years). This depth of accounting expertise is the perfect foundation for teaching ACCA's rigorous syllabus." },
      { icon: Brain, title: "Concept-First Approach for ACCA Papers", desc: "ACCA exams test application, not memorization. Our concept-based teaching methodology — perfected over 30 years — is exactly what ACCA students need. We build deep understanding of financial reporting, audit, tax, and management accounting principles." },
      { icon: BookOpen, title: "Small Batches for Personal Attention", desc: "ACCA preparation requires individual guidance — especially for Strategic Professional papers. Our batches are strictly limited to ensure every student gets personal doubt-clearing, paper review, and exam strategy advice." },
      { icon: ClipboardCheck, title: "Structured Study Plans & Mock Exams", desc: "We provide exam-session-wise study plans aligned with ACCA's quarterly exam windows. Regular mock exams under timed conditions with detailed feedback help students build exam confidence and time management skills." },
      { icon: TrendingUp, title: "Career Guidance & Placement Support", desc: "Beyond exam prep, we guide ACCA students on career paths — Big 4 firms, multinational corporations, banking, and consulting. Our network of commerce and CA alumni in Indore provides mentorship and career connections." },
    ],
  },
  courses: {
    heading: "ACCA Papers We Cover",
    subheading: "Comprehensive preparation across all three ACCA levels — Applied Knowledge, Applied Skills & Strategic Professional",
    items: [
      { icon: BookOpen, title: "Applied Knowledge (BT, MA, FA)", subjects: ["Business & Technology", "Management Accounting", "Financial Accounting"], desc: "Foundation-level ACCA papers covering business operations, management accounting techniques, and financial accounting fundamentals. Ideal for students starting their ACCA journey in Indore." },
      { icon: ClipboardCheck, title: "Applied Skills (LW, PM, TX, FR, AA, FM)", subjects: ["Corporate & Business Law", "Performance Management", "Taxation", "Financial Reporting", "Audit & Assurance", "Financial Management"], desc: "Core ACCA papers building deep expertise in law, performance management, taxation, financial reporting, audit, and financial management. Taught with practical case studies and exam-focused practice." },
      { icon: Award, title: "Strategic Professional (SBL, SBR + Options)", subjects: ["Strategic Business Leader", "Strategic Business Reporting", "Advanced Financial Management", "Advanced Audit & Assurance"], desc: "Advanced ACCA papers requiring strategic thinking and professional judgment. Our experienced faculty guides students through complex case studies, integrated scenarios, and professional-level exam technique." },
    ],
  },
  highlights: {
    heading: "What Makes Our ACCA Coaching Stand Out",
    subheading: "A structured approach designed for ACCA success from Applied Knowledge through Strategic Professional",
    items: [
      { icon: Layers, title: "Session-Wise Study Plans", desc: "Structured preparation aligned with ACCA's March, June, September & December exam sessions" },
      { icon: FileText, title: "Past Paper Practice", desc: "Extensive practice with ACCA past papers, pilot papers, and examiner reports for authentic preparation" },
      { icon: HelpCircle, title: "Doubt-Clearing Sessions", desc: "Regular doubt-clearing slots — especially critical for complex papers like SBL, SBR & AFM" },
      { icon: Target, title: "Exam Technique Training", desc: "Learn time allocation, answer structuring, and professional marks strategy for ACCA exams" },
      { icon: BarChart3, title: "Progress Tracking", desc: "Regular assessments and mock exam results tracked to ensure steady improvement across papers" },
      { icon: Briefcase, title: "Career & PER Guidance", desc: "Guidance on ACCA Practical Experience Requirement (PER) and career opportunities for ACCA affiliates" },
    ],
  },
  faqs: [
    { q: "Which is the best ACCA coaching in Indore?", a: "Dalmia Academy offers the best ACCA coaching in Indore, combining 30+ years of accounting teaching expertise with structured ACCA-specific preparation. Located at Geeta Bhawan Square on AB Road, we provide small-batch coaching with personal mentorship — something metro-based online-only institutes cannot match." },
    { q: "What is ACCA and who should pursue it?", a: "ACCA (Association of Chartered Certified Accountants) is a globally recognized accounting qualification accepted in 180+ countries. It's ideal for students who want international career opportunities in accounting, audit, tax, and finance. Commerce graduates, CA students, and working professionals can all benefit from ACCA." },
    { q: "Can I do ACCA along with my graduation?", a: "Yes! ACCA can be pursued alongside B.Com, BBA, or any graduation. Our flexible batch timings at the Indore centre accommodate college students. You can start with Applied Knowledge papers while in your first year of college." },
    { q: "How many papers does ACCA have?", a: "ACCA has 13 papers across three levels: Applied Knowledge (3 papers), Applied Skills (6 papers), and Strategic Professional (4 papers including 2 compulsory + 2 optional). We cover all levels with structured study plans aligned to ACCA exam sessions." },
    { q: "What are the career prospects after ACCA?", a: "ACCA opens doors to global career opportunities — Big 4 accounting firms (Deloitte, PwC, EY, KPMG), multinational corporations, banks, consulting firms, and international finance roles. ACCA members earn competitive salaries and can work in any of the 180+ countries where ACCA is recognized." },
    { q: "Are demo classes available for ACCA coaching?", a: "Yes! We offer free counselling and demo sessions for ACCA aspirants in Indore. Call +91-95757-76655 or fill the enquiry form to book your free session at our Geeta Bhawan Square centre." },
    { q: "What is the fee structure for ACCA coaching in Indore?", a: "Our ACCA coaching fees are competitive and affordable. We offer level-wise enrollment (Applied Knowledge, Applied Skills, Strategic Professional) with flexible payment options. Contact us at +91-95757-76655 for the current fee structure." },
  ],
  testimonials: [
    { name: "Aditya M.", text: "Dalmia Academy's strong accounting foundation helped me transition smoothly to ACCA. The faculty's 30+ years of experience in Accountancy made complex ACCA papers feel manageable.", course: "ACCA Applied Knowledge" },
    { name: "Sneha K.", text: "Finding quality ACCA coaching in Indore was difficult until I found Dalmia Academy. The small batch size and personal attention made all the difference in my preparation.", course: "ACCA Applied Skills" },
    { name: "Rohit V.", text: "The concept-based teaching approach at Dalmia Academy is exactly what ACCA exams require. No rote learning — just deep understanding and practical application.", course: "ACCA" },
  ],
  leadForm: {
    courseOptions: [
      { value: "ACCA Applied Knowledge", label: "ACCA — Applied Knowledge" },
      { value: "ACCA Applied Skills", label: "ACCA — Applied Skills" },
      { value: "ACCA Strategic Professional", label: "ACCA — Strategic Professional" },
      { value: "ACCA Full Course", label: "ACCA — Full Course" },
    ],
  },
  finalCTA: {
    headline: "Go Global with ACCA —",
    highlightText: "Start Your Journey in Indore",
    subheadline: "Limited seats available for ACCA coaching at Dalmia Academy, Geeta Bhawan Square. Book your free counselling session today!",
  },
};

// ─── US CPA Content ────────────────────────────────────────────────
export const usCpaContent: PageContent = {
  slug: "us-cpa-coaching",
  pageTitle: "Best US CPA Coaching in Indore | Dalmia Academy",
  metaDescription: "Best US CPA coaching in Indore. Prepare for all 4 CPA exam sections — AUD, BEC, FAR, REG — with expert faculty & structured study plans at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best US CPA Coaching in Indore —",
    highlightText: "Unlock Global Accounting Careers",
    subheadline: "Prepare for the US CPA exam with structured coaching at Dalmia Academy, Indore. Expert faculty with decades of accounting expertise, small batches, and a strategic approach to help you pass all 4 sections.",
    benefits: ["All 4 CPA Sections", "Expert Faculty", "Flexible Batches", "Career Guidance"],
    stats: [
      { value: "30+", label: "Years in Indore" },
      { value: "4", label: "CPA Sections" },
      { value: "US", label: "Licensed Credential" },
    ],
  },
  whyChoose: {
    heading: "Why Choose Dalmia Academy for US CPA Coaching in Indore",
    subheading: "Indore's trusted coaching institute bringing world-class US CPA preparation to central India — backed by 30+ years of accounting teaching excellence",
    benefits: [
      { icon: Award, title: "US CPA — The Gold Standard", desc: "The US CPA license is the most respected accounting credential globally. At Dalmia Academy Indore, we prepare you for this prestigious exam with the same rigour and depth that has made us Indore's top accounting coaching for over 30 years." },
      { icon: Users, title: "Accounting Faculty with 25-36 Years Experience", desc: "Our faculty's deep expertise in Accountancy, Taxation, and Audit — built over decades of teaching CA Foundation and Commerce — translates perfectly to US CPA's demanding syllabus covering FAR, AUD, REG, and BEC." },
      { icon: Brain, title: "Concept-Based CPA Preparation", desc: "US CPA exams test conceptual understanding and application through MCQs and Task-Based Simulations. Our proven concept-first teaching methodology prepares you to think critically and solve complex scenarios — not just memorize standards." },
      { icon: BookOpen, title: "Small Batches & Individual Attention", desc: "US CPA preparation requires personalized study plans based on each student's background (CA, B.Com, MBA). Our small batches ensure every student gets customized guidance on section order, study schedule, and exam strategy." },
      { icon: ClipboardCheck, title: "Section-Wise Mock Exams", desc: "Practice with CPA-pattern MCQs and Task-Based Simulations for all 4 sections. Timed mock exams with detailed performance analysis help you build speed and accuracy before the actual exam." },
      { icon: TrendingUp, title: "Career & Licensing Guidance", desc: "Beyond exam prep, we guide you on state board requirements, education evaluation, experience requirements, and ethics exam. Our goal is to help you become a licensed CPA, not just pass the exam." },
    ],
  },
  courses: {
    heading: "US CPA Exam Sections We Cover",
    subheading: "Complete preparation for all 4 sections of the Uniform CPA Examination",
    items: [
      { icon: FileText, title: "FAR — Financial Accounting & Reporting", subjects: ["US GAAP", "Government Accounting", "Not-for-Profit Accounting", "Financial Statement Analysis"], desc: "The most content-heavy CPA section. We cover US GAAP framework, governmental & not-for-profit accounting, and financial statement preparation with conceptual clarity and extensive MCQ practice." },
      { icon: ClipboardCheck, title: "AUD — Auditing & Attestation", subjects: ["Audit Planning", "Internal Controls", "Audit Evidence", "Reporting & Ethics"], desc: "Comprehensive audit preparation covering AICPA standards, audit planning, risk assessment, internal controls evaluation, and professional responsibilities. Case-study based teaching for practical understanding." },
      { icon: BarChart3, title: "REG — Regulation", subjects: ["Federal Taxation", "Business Law", "Ethics", "Tax Compliance"], desc: "Federal taxation for individuals and entities, business law, professional ethics, and tax compliance. Our tax and law faculty's decades of experience makes complex regulations accessible." },
      { icon: TrendingUp, title: "BEC — Business Environment & Concepts", subjects: ["Corporate Governance", "Economics", "Financial Management", "IT & Operations"], desc: "Business concepts including corporate governance, economic analysis, financial management, and IT. This section also includes written communication tasks — we train you on structure and professional writing." },
    ],
  },
  highlights: {
    heading: "Our US CPA Coaching Approach",
    subheading: "A structured methodology designed to help Indore students pass all 4 CPA sections efficiently",
    items: [
      { icon: Layers, title: "Strategic Section Ordering", desc: "We help you choose the optimal section order based on your background — FAR first for most, or AUD/REG if you have audit/tax experience" },
      { icon: FileText, title: "MCQ & TBS Practice", desc: "Thousands of CPA-pattern MCQs and Task-Based Simulations with detailed explanations for every answer" },
      { icon: HelpCircle, title: "Doubt-Clearing & Mentorship", desc: "Regular doubt-clearing sessions and 1-on-1 mentorship to keep you on track through the 18-month exam window" },
      { icon: Target, title: "Exam Day Strategy", desc: "Time management, testlet strategy, and mental preparation techniques for the 4-hour Prometric exam experience" },
      { icon: BarChart3, title: "Score Prediction & Tracking", desc: "Track your mock exam scores against passing benchmarks to know exactly when you're ready for each section" },
      { icon: Briefcase, title: "Licensing & Career Support", desc: "End-to-end guidance on state board applications, NTS, Prometric scheduling, and post-CPA career opportunities" },
    ],
  },
  faqs: [
    { q: "Which is the best US CPA coaching in Indore?", a: "Dalmia Academy offers the best US CPA coaching in Indore, backed by 30+ years of accounting teaching expertise. Our faculty's deep knowledge of Accountancy, Taxation, and Audit translates directly to CPA exam preparation. Located at Geeta Bhawan Square, we provide personal mentorship that large online platforms cannot match." },
    { q: "Who is eligible for the US CPA exam?", a: "Generally, you need 120-150 credit hours of education (equivalent to a Bachelor's + some additional coursework in accounting). Indian qualifications like B.Com + CA/MBA often meet requirements. We help evaluate your eligibility and guide you through the credential evaluation process." },
    { q: "How long does it take to pass all 4 CPA sections?", a: "Most candidates pass all 4 sections in 12-18 months with dedicated preparation. AICPA provides an 18-month rolling window — once you pass your first section, you must pass the remaining 3 within 18 months. Our structured study plans are designed around this timeline." },
    { q: "Can working professionals pursue US CPA?", a: "Absolutely. Many of our CPA students are working professionals. We offer flexible batch timings and weekend sessions at our Indore centre to accommodate work schedules. The key is consistent study of 15-20 hours per week." },
    { q: "What is the US CPA exam format?", a: "Each CPA section is a 4-hour computer-based exam taken at Prometric test centres. The exam includes MCQs (Multiple Choice Questions) and TBS (Task-Based Simulations). We prepare you for both formats with extensive practice under timed conditions." },
    { q: "Are demo classes available for US CPA coaching?", a: "Yes! We offer free counselling and orientation sessions for US CPA aspirants in Indore. Call +91-95757-76655 or fill the enquiry form to schedule your free session at our Geeta Bhawan Square centre." },
  ],
  testimonials: [
    { name: "Prateek S.", text: "The strong accounting foundation at Dalmia Academy made US CPA preparation much smoother. Faculty with 35+ years of experience can explain even the most complex US GAAP concepts clearly.", course: "US CPA — FAR" },
    { name: "Divya R.", text: "Finding US CPA coaching in Indore seemed impossible until Dalmia Academy. The personal attention and structured study plan kept me on track to pass all 4 sections.", course: "US CPA" },
    { name: "Karan M.", text: "The mock exams and MCQ practice sessions were incredibly helpful. Dalmia Academy's approach of building concepts first made the exam feel manageable.", course: "US CPA — AUD" },
  ],
  leadForm: {
    courseOptions: [
      { value: "US CPA Full", label: "US CPA — All 4 Sections" },
      { value: "US CPA FAR", label: "US CPA — FAR" },
      { value: "US CPA AUD", label: "US CPA — AUD" },
      { value: "US CPA REG", label: "US CPA — REG" },
      { value: "US CPA BEC", label: "US CPA — BEC" },
    ],
  },
  finalCTA: {
    headline: "Become a US CPA —",
    highlightText: "Start Your Journey in Indore",
    subheadline: "Limited seats available for US CPA coaching at Dalmia Academy, Geeta Bhawan Square. Book your free counselling session today!",
  },
};

// ─── US CMA Content ────────────────────────────────────────────────
export const usCmaContent: PageContent = {
  slug: "us-cma-coaching",
  pageTitle: "Best US CMA Coaching in Indore | Dalmia Academy",
  metaDescription: "Best US CMA coaching in Indore. Prepare for both CMA exam parts — Financial Planning & Analysis — with expert faculty & structured coaching at Dalmia Academy, Geeta Bhawan Square.",
  hero: {
    headline: "Best US CMA Coaching in Indore —",
    highlightText: "Master Management Accounting",
    subheadline: "Become a US Certified Management Accountant with expert coaching at Dalmia Academy, Indore. Strategic financial planning, performance management, and decision analysis — taught by faculty with 30+ years of accounting expertise.",
    benefits: ["IMA Certified", "2-Part Exam", "Expert Faculty", "Career Growth"],
    stats: [
      { value: "30+", label: "Years in Indore" },
      { value: "2", label: "CMA Parts" },
      { value: "₹20L+", label: "Avg CMA Salary" },
    ],
  },
  whyChoose: {
    heading: "Why Choose Dalmia Academy for US CMA Coaching in Indore",
    subheading: "Indore's trusted accounting coaching institute now offering US CMA preparation — the fastest-growing global management accounting credential",
    benefits: [
      { icon: Award, title: "US CMA — The Management Accounting Edge", desc: "The US CMA (Certified Management Accountant) credential from IMA is the global benchmark for management accounting and financial management. At Dalmia Academy Indore, we prepare you for this high-value credential with expert guidance and a structured approach." },
      { icon: Users, title: "Faculty with Decades of Accounting Depth", desc: "US CMA covers financial planning, analysis, control, and decision support. Our faculty's 25-36 years of teaching Accountancy, Economics, and Business Studies provides the perfect foundation for CMA's management-focused syllabus." },
      { icon: Brain, title: "Application-Focused Teaching", desc: "US CMA exams emphasize analysis, strategy, and decision-making — not just calculations. Our concept-first methodology trains you to think like a CFO, analyzing scenarios and making strategic financial recommendations." },
      { icon: BookOpen, title: "Small Batches & Personalized Study Plans", desc: "Every CMA student has a different background — CA, B.Com, MBA, or working professional. Our small batches allow us to create personalized study plans that maximize your strengths and address gaps efficiently." },
      { icon: ClipboardCheck, title: "IMA-Pattern Mock Exams", desc: "Regular mock exams covering both Part 1 and Part 2 with MCQs and essay questions. Detailed performance analysis shows your readiness level for each topic area, so you know exactly where to focus." },
      { icon: TrendingUp, title: "Career Acceleration & ROI", desc: "US CMAs command premium salaries in India (₹15-30 LPA) and globally. We guide you on leveraging the CMA credential for career advancement in FP&A, controllership, treasury, and C-suite roles." },
    ],
  },
  courses: {
    heading: "US CMA Exam Parts We Cover",
    subheading: "Complete preparation for both parts of the IMA Certified Management Accountant exam",
    items: [
      { icon: BarChart3, title: "Part 1 — Financial Planning, Performance & Analytics", subjects: ["External Financial Reporting", "Planning, Budgeting & Forecasting", "Performance Management", "Cost Management", "Internal Controls", "Technology & Analytics"], desc: "Covers external financial reporting decisions, planning and budgeting, performance management, cost management, internal controls, and technology & analytics. We build deep understanding of each domain with practical examples and case studies." },
      { icon: TrendingUp, title: "Part 2 — Strategic Financial Management", subjects: ["Financial Statement Analysis", "Corporate Finance", "Decision Analysis", "Risk Management", "Investment Decisions", "Professional Ethics"], desc: "Covers financial statement analysis, corporate finance, decision analysis, risk management, investment decisions, and professional ethics. Our faculty helps you develop the strategic thinking skills CMA Part 2 demands." },
    ],
  },
  highlights: {
    heading: "Our US CMA Coaching Methodology",
    subheading: "A results-driven approach to help Indore students pass both CMA parts and launch high-impact finance careers",
    items: [
      { icon: Layers, title: "Domain-Wise Structured Learning", desc: "Each of CMA's 12 domains taught in structured modules with clear milestones and checkpoints" },
      { icon: FileText, title: "MCQ & Essay Practice", desc: "Extensive practice with IMA-pattern MCQs and essay questions — both formats are critical for passing" },
      { icon: HelpCircle, title: "Doubt-Clearing & Mentorship", desc: "Regular sessions to clarify complex topics like variance analysis, capital budgeting, and risk management" },
      { icon: Target, title: "Essay Writing Technique", desc: "CMA essays require structured business communication — we train you on professional writing for the essay section" },
      { icon: BarChart3, title: "Score Tracking & Readiness", desc: "Mock exam scores tracked against the 360/500 passing benchmark so you know when you're ready" },
      { icon: Briefcase, title: "IMA Membership & Credential Guidance", desc: "End-to-end support with IMA membership, exam registration, and credential verification process" },
    ],
  },
  faqs: [
    { q: "Which is the best US CMA coaching in Indore?", a: "Dalmia Academy provides the best US CMA coaching in Indore with 30+ years of accounting expertise. Our faculty's deep knowledge of management accounting, cost accounting, and financial analysis makes us uniquely qualified to teach the CMA syllabus. Visit us at Geeta Bhawan Square, AB Road." },
    { q: "What is US CMA and how is it different from CA?", a: "US CMA (Certified Management Accountant) is a global credential from IMA focused on management accounting and financial management. While CA focuses on audit, tax, and financial reporting, CMA focuses on planning, analysis, control, and decision support. CMA is ideal for careers in corporate finance, FP&A, and CFO roles." },
    { q: "Who is eligible for the US CMA exam?", a: "You need a Bachelor's degree from an accredited institution (B.Com, BBA, MBA, CA all qualify) and 2 years of relevant work experience (can be completed within 7 years of passing). You can start the exam while still completing your experience requirement." },
    { q: "How long does it take to pass the US CMA exam?", a: "Most dedicated candidates pass both parts in 6-12 months. Each part is a 4-hour exam with MCQs and essays. We recommend 150-170 hours of study per part, which our structured coaching plan spreads across 3-4 months per part." },
    { q: "What is the salary after US CMA in India?", a: "US CMAs in India earn ₹15-30 LPA on average, with experienced professionals earning significantly more. Global salaries are even higher. CMA holders are in demand for roles in financial planning & analysis, controllership, treasury, and C-suite positions at MNCs." },
    { q: "Can I do US CMA while working?", a: "Yes, absolutely. Many of our CMA students are working professionals. We offer flexible batch timings and weekend sessions at our Indore centre. US CMA is designed for working professionals — the exam windows and IMA's flexible policies support this." },
    { q: "Are demo classes available for US CMA coaching?", a: "Yes! We offer free counselling and orientation sessions for US CMA aspirants in Indore. Call +91-95757-76655 or fill the enquiry form to schedule your free session at our Geeta Bhawan Square centre." },
  ],
  testimonials: [
    { name: "Ankit G.", text: "Dalmia Academy's deep accounting expertise made CMA preparation feel natural. The faculty's real-world examples helped me understand complex cost management and financial analysis concepts.", course: "US CMA Part 1" },
    { name: "Neha P.", text: "The structured study plan and regular mock exams at Dalmia Academy kept me on track. Passed both CMA parts within 8 months while working full-time.", course: "US CMA" },
    { name: "Siddharth K.", text: "Finding US CMA coaching in Indore was a challenge until I discovered Dalmia Academy. The small batch size and personal mentorship made all the difference.", course: "US CMA Part 2" },
  ],
  leadForm: {
    courseOptions: [
      { value: "US CMA Full", label: "US CMA — Both Parts" },
      { value: "US CMA Part 1", label: "US CMA — Part 1" },
      { value: "US CMA Part 2", label: "US CMA — Part 2" },
    ],
  },
  finalCTA: {
    headline: "Become a US CMA —",
    highlightText: "Accelerate Your Finance Career",
    subheadline: "Limited seats available for US CMA coaching at Dalmia Academy, Geeta Bhawan Square, Indore. Book your free counselling session today!",
  },
};

// ─── CFA Content ───────────────────────────────────────────────────
export const cfaContent: PageContent = {
  slug: "cfa-coaching",
  pageTitle: "Best CFA Coaching in Indore | Dalmia Academy",
  metaDescription: "Best CFA coaching in Indore. Prepare for all 3 CFA exam levels with expert faculty, structured study plans & small batches at Dalmia Academy, Geeta Bhawan Square. Free counselling available.",
  hero: {
    headline: "Best CFA Coaching in Indore —",
    highlightText: "Master the World of Finance",
    subheadline: "Become a CFA Charterholder with expert coaching at Dalmia Academy, Indore. Comprehensive preparation for all 3 CFA levels — Ethics, Portfolio Management, Equity, Fixed Income, Derivatives & more — at Geeta Bhawan Square.",
    benefits: ["Global Gold Standard", "3 Levels", "Expert Faculty", "Small Batches"],
    stats: [
      { value: "30+", label: "Years in Indore" },
      { value: "3", label: "CFA Levels" },
      { value: "Top", label: "Finance Credential" },
    ],
  },
  whyChoose: {
    heading: "Why Choose Dalmia Academy for CFA Coaching in Indore",
    subheading: "Indore's trusted coaching institute offering structured CFA preparation — combining 30+ years of financial education expertise with the CFA Institute's rigorous curriculum",
    benefits: [
      { icon: LineChart, title: "CFA — The Gold Standard in Finance", desc: "The CFA (Chartered Financial Analyst) charter is the most respected credential in investment management globally. At Dalmia Academy Indore, we bring world-class CFA preparation to central India — no need to travel to Mumbai or Delhi for quality coaching." },
      { icon: Users, title: "Faculty with Deep Financial Expertise", desc: "Our faculty's 25-36 years of teaching Economics, Accountancy, and Financial Management provides the ideal foundation for CFA's demanding curriculum covering portfolio management, equity valuation, fixed income, derivatives, and alternative investments." },
      { icon: Brain, title: "Application-Based CFA Preparation", desc: "CFA exams test practical application and analytical thinking, not just theory. Our concept-first approach — refined over 30 years — builds the deep understanding needed to tackle CFA's scenario-based questions and item sets." },
      { icon: BookOpen, title: "Small Batches for Focused Learning", desc: "CFA preparation requires individual guidance on complex topics like fixed income analytics, derivatives pricing, and portfolio construction. Our small batches ensure every student gets personal attention and doubt resolution." },
      { icon: ClipboardCheck, title: "CFA-Pattern Mock Exams", desc: "Regular mock exams mirroring CFA Institute's format — MCQs for Level I, item sets for Level II, and constructed response for Level III. Timed practice with detailed performance analysis builds exam-day confidence." },
      { icon: TrendingUp, title: "Career Guidance in Finance", desc: "Beyond exam prep, we guide CFA candidates on career paths — equity research, portfolio management, investment banking, risk management, and wealth management. Our network helps connect you to finance opportunities." },
    ],
  },
  courses: {
    heading: "CFA Exam Levels We Cover",
    subheading: "Complete preparation across all 3 levels of the CFA Program",
    items: [
      { icon: BookOpen, title: "CFA Level I — Investment Tools", subjects: ["Ethics & Professional Standards", "Quantitative Methods", "Economics", "Financial Reporting & Analysis", "Corporate Issuers", "Equity Investments", "Fixed Income", "Derivatives", "Alternative Investments", "Portfolio Management"], desc: "Foundation-level CFA covering all 10 topic areas with emphasis on knowledge and comprehension. 180 MCQs across two sessions. We build strong fundamentals in financial analysis, economics, and investment tools." },
      { icon: BarChart3, title: "CFA Level II — Asset Valuation", subjects: ["Ethics", "Equity Valuation", "Fixed Income Analysis", "Derivatives Pricing", "Alternative Investments", "Portfolio Management", "Financial Reporting"], desc: "Application-focused level testing your ability to value assets and apply investment tools. Item set format (vignettes + MCQs). Deep dive into equity valuation models, fixed income analytics, and derivatives." },
      { icon: LineChart, title: "CFA Level III — Portfolio Management", subjects: ["Ethics", "Asset Allocation", "Fixed Income PM", "Equity PM", "Alternative Investments PM", "Risk Management", "Private Wealth", "Institutional PM"], desc: "The capstone level focused on portfolio management and wealth planning. Constructed response + item sets. We train you on IPS writing, asset allocation, and portfolio construction strategies." },
    ],
  },
  highlights: {
    heading: "Our CFA Coaching Methodology",
    subheading: "A structured approach to help Indore students pass all 3 CFA levels and launch finance careers",
    items: [
      { icon: Layers, title: "Topic-Area Wise Preparation", desc: "Each of CFA's 10 topic areas taught in structured modules with concept clarity before practice" },
      { icon: FileText, title: "CFA Institute Mock Practice", desc: "Practice with CFA Institute's official mocks, topic tests, and past papers for authentic preparation" },
      { icon: HelpCircle, title: "Doubt-Clearing Sessions", desc: "Regular sessions for complex topics — fixed income duration/convexity, options pricing, and portfolio theory" },
      { icon: Target, title: "Exam Strategy & Time Management", desc: "CFA exams are time-pressured — we train you on question allocation, guessing strategy, and time management" },
      { icon: BarChart3, title: "Score Tracking & Readiness", desc: "Track mock scores against MPS (Minimum Passing Score) estimates to gauge readiness for each level" },
      { icon: Briefcase, title: "Work Experience & Charter Guidance", desc: "Guidance on meeting CFA Institute's 4,000 hours of work experience requirement and charter application" },
    ],
  },
  faqs: [
    { q: "Which is the best CFA coaching in Indore?", a: "Dalmia Academy provides the best CFA coaching in Indore, combining 30+ years of financial education expertise with structured CFA-specific preparation. Our faculty's deep knowledge of Economics, Accountancy, and Financial Management translates directly to CFA's demanding curriculum. Visit us at Geeta Bhawan Square, AB Road." },
    { q: "What is CFA and who should pursue it?", a: "CFA (Chartered Financial Analyst) is the most respected credential in investment management, awarded by CFA Institute. It's ideal for professionals aiming for careers in equity research, portfolio management, investment banking, risk management, and wealth management. The CFA charter signals deep expertise in financial analysis." },
    { q: "How many levels does the CFA exam have?", a: "The CFA Program has 3 levels. Level I tests knowledge (MCQs), Level II tests application (item sets/vignettes), and Level III tests synthesis and portfolio management (constructed response + item sets). Most candidates take 2.5-4 years to complete all 3 levels." },
    { q: "What is the eligibility for CFA?", a: "You need a Bachelor's degree (or be in the final year of graduation) OR have 4,000 hours of professional work experience OR a combination of education and work experience totaling 4 years. B.Com, BBA, MBA, CA, and engineering graduates all qualify." },
    { q: "Can I do CFA along with my job or CA?", a: "Yes! Many CFA candidates are working professionals or CA students/members. CFA exams are offered multiple times a year with flexible scheduling windows. Our batch timings at the Indore centre accommodate working professionals. CFA + CA is a powerful combination for finance careers." },
    { q: "What are career prospects after CFA?", a: "CFA charterholders work in equity research, portfolio management, investment banking, corporate finance, risk management, wealth management, and consulting. Average salaries range from ₹8-25 LPA for early career to ₹40 LPA+ for experienced professionals in India. Global opportunities are even more lucrative." },
    { q: "Are demo classes available for CFA coaching?", a: "Yes! We offer free counselling and demo sessions for CFA aspirants in Indore. Call +91-95757-76655 or fill the enquiry form to book your free session at our Geeta Bhawan Square centre." },
  ],
  testimonials: [
    { name: "Arjun D.", text: "The strong economics and financial analysis foundation at Dalmia Academy made CFA Level I preparation much smoother. Faculty with 30+ years of experience explain complex concepts with clarity.", course: "CFA Level I" },
    { name: "Priya M.", text: "Finding quality CFA coaching in Indore was tough until I found Dalmia Academy. The small batch size and personal attention on complex topics like derivatives made all the difference.", course: "CFA Level II" },
    { name: "Varun S.", text: "Dalmia Academy's concept-first approach is exactly what CFA exams demand. The mock exams and performance tracking helped me gauge my readiness perfectly.", course: "CFA" },
  ],
  leadForm: {
    courseOptions: [
      { value: "CFA Level I", label: "CFA — Level I" },
      { value: "CFA Level II", label: "CFA — Level II" },
      { value: "CFA Level III", label: "CFA — Level III" },
      { value: "CFA All Levels", label: "CFA — All Levels" },
    ],
  },
  finalCTA: {
    headline: "Become a CFA Charterholder —",
    highlightText: "Start Your Finance Career in Indore",
    subheadline: "Limited seats available for CFA coaching at Dalmia Academy, Geeta Bhawan Square. Book your free counselling session today!",
  },
};

// ─── Home Page Course Cards ─────────────────────────────────────────
export interface CourseCard {
  title: string;
  description: string;
  route: string;
  icon: LucideIcon;
  tags: string[];
}

export const homePageCourses: CourseCard[] = [
  {
    title: "11th & 12th Humanities",
    description: "Master Psychology, Political Science, Geography & History with concept-based teaching and structured answer writing practice.",
    route: "/humanities-coaching",
    icon: Globe,
    tags: ["Psychology", "Political Science", "Board Exams"],
  },
  {
    title: "11th & 12th Commerce",
    description: "Commerce with Applied Maths — build a strong foundation in Accountancy, Economics, Business Studies & more.",
    route: "/commerce-coaching",
    icon: BookOpen,
    tags: ["Applied Maths", "Board Exams"],
  },
  {
    title: "CA Foundation & CSEET",
    description: "Best CA coaching in Indore — expert preparation for CA Foundation and CSEET aspirants with 90%+ pass rate.",
    route: "/ca-foundation",
    icon: ClipboardCheck,
    tags: ["CA", "CS", "90%+ Pass Rate"],
  },
  {
    title: "6th to 10th All Subjects",
    description: "Comprehensive tuition for all subjects — build strong fundamentals and excel in school exams.",
    route: "/school-coaching",
    icon: BookMarked,
    tags: ["All Subjects", "Foundation"],
  },
  {
    title: "IPMAT & CUET-UG Coaching",
    description: "Board + IPMAT & CUET-UG integrated preparation for Commerce & Science students targeting India's top central universities & IIMs.",
    route: "/cuet-coaching",
    icon: Target,
    tags: ["Commerce", "Science", "CUET Pattern"],
  },
  {
    title: "Spoken English & Personality Development",
    description: "Boost your communication skills and confidence with our structured spoken English and personality development program.",
    route: "/spoken-english",
    icon: Users,
    tags: ["Communication", "Soft Skills"],
  },
  {
    title: "ACCA Coaching",
    description: "Become a globally recognized Chartered Certified Accountant with structured ACCA coaching in Indore.",
    route: "/acca-coaching",
    icon: Award,
    tags: ["Global", "Accounting", "13 Papers"],
  },
  {
    title: "US CMA Coaching",
    description: "Master management accounting and financial strategy with US CMA coaching in Indore.",
    route: "/us-cma-coaching",
    icon: Briefcase,
    tags: ["IMA Certified", "2 Parts", "₹20L+ Salary"],
  },
  {
    title: "US CPA Coaching",
    description: "Prepare for all 4 US CPA exam sections with expert accounting faculty in Indore.",
    route: "/us-cpa-coaching",
    icon: TrendingUp,
    tags: ["US License", "4 Sections", "Global"],
  },
  {
    title: "CFA Coaching",
    description: "Become a CFA Charterholder — the gold standard in investment management — with expert coaching in Indore.",
    route: "/cfa-coaching",
    icon: LineChart,
    tags: ["3 Levels", "Finance", "Global"],
  },
];
