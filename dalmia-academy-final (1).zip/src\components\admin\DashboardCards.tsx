import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserPlus, Clock, CheckCircle, Phone } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";

interface DashboardCardsProps {
  todayCount: number;
  monthCount: number;
  pendingFollowUps: number;
  confirmedCount: number;
  phoneClicksToday: number;
  whatsappClicksToday: number;
}

const DashboardCards = ({ todayCount, monthCount, pendingFollowUps, confirmedCount, phoneClicksToday, whatsappClicksToday }: DashboardCardsProps) => {
  const cards = [
    { title: "Leads Today", value: todayCount, icon: UserPlus, color: "text-blue-600" },
    { title: "Leads This Month", value: monthCount, icon: Users, color: "text-primary" },
    { title: "Pending Follow-ups", value: pendingFollowUps, icon: Clock, color: "text-amber-600" },
    { title: "Admissions Confirmed", value: confirmedCount, icon: CheckCircle, color: "text-green-600" },
    { title: "Phone Clicks Today", value: phoneClicksToday, icon: Phone, color: "text-blue-500" },
    { title: "WhatsApp Clicks Today", value: whatsappClicksToday, icon: WhatsAppIcon, color: "text-green-500" },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
            <card.icon className={`h-5 w-5 ${card.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-heading">{card.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardCards;
