import { SITE_NAME, SITE_URL, absoluteUrl, canonicalFor } from "@/config/site";

export function organizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: SITE_NAME,
    url: SITE_URL,
    logo: absoluteUrl("/og-default.jpg"),
    telephone: "+91-95757-76655",
    email: "dalmiaacademy@gmail.com",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Road",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      postalCode: "452001",
      addressCountry: "IN",
    },
    foundingDate: "1991",
    areaServed: "Indore",
    sameAs: [],
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE_NAME,
    url: SITE_URL,
  };
}

export function serviceSchema(opts: { name: string; description: string; url: string }) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name: opts.name,
    description: opts.description,
    url: canonicalFor(opts.url),
    provider: {
      "@type": "EducationalOrganization",
      name: SITE_NAME,
      url: SITE_URL,
    },
    areaServed: "Indore",
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: canonicalFor(it.path),
    })),
  };
}

export function articleSchema(post: {
  title: string;
  slug: string;
  description?: string | null;
  image?: string | null;
  author?: string | null;
  datePublished: string;
  dateModified?: string | null;
  schemaType?: string | null;
}) {
  return {
    "@context": "https://schema.org",
    "@type": post.schemaType || "BlogPosting",
    headline: post.title,
    description: post.description || undefined,
    image: post.image ? absoluteUrl(post.image) : undefined,
    author: { "@type": "Person", name: post.author || "Dalmia Academy" },
    publisher: {
      "@type": "Organization",
      name: SITE_NAME,
      logo: { "@type": "ImageObject", url: absoluteUrl("/og-default.jpg") },
    },
    datePublished: post.datePublished,
    dateModified: post.dateModified || post.datePublished,
    mainEntityOfPage: canonicalFor(`/blog/${post.slug}`),
    url: canonicalFor(`/blog/${post.slug}`),
  };
}

export function faqSchema(items: { question: string; answer: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((q) => ({
      "@type": "Question",
      name: q.question,
      acceptedAnswer: { "@type": "Answer", text: q.answer },
    })),
  };
}

export function homepageGraphSchema() {
  return [
    {
      "@context": "https://schema.org",
      "@type": "EducationalOrganization",
      "@id": "https://dalmiaacademy.com/#organization",
      name: "Dalmia Academy",
      legalName: "Yasharsh Educational Initiatives LLP",
      url: "https://dalmiaacademy.com/",
      logo: "https://dalmiaacademy.com/logo.png",
      description:
        "Dalmia Academy is one of Indore's most trusted coaching institutes for Commerce education and professional exam preparation. Expert coaching for CUET, CA Foundation, Commerce, Humanities, Spoken English & School Tuition — all under one roof.",
      foundingDate: "1991",
      slogan: "Strong Foundation. Smart Learning. Sure Success.",
      telephone: "+91-95757-76655",
      email: "dalmiaacademy@gmail.com",
      address: {
        "@type": "PostalAddress",
        streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
        addressLocality: "Indore",
        addressRegion: "Madhya Pradesh",
        postalCode: "452001",
        addressCountry: "IN",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: 22.7196,
        longitude: 75.8577,
        name: "Tulsi Tower, Geeta Bhawan Square, AB Rd, Indore",
      },
      sameAs: ["https://www.instagram.com/dalmia_academy_indore/"],
      contactPoint: [
        {
          "@type": "ContactPoint",
          telephone: "+91-95757-76655",
          contactType: "customer service",
          availableLanguage: ["English", "Hindi"],
        },
        {
          "@type": "ContactPoint",
          telephone: "+91-91091-09651",
          contactType: "sales",
          availableLanguage: ["English", "Hindi"],
        },
      ],
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Coaching Programs",
        itemListElement: [
          {
            "@type": "Course",
            name: "IPMAT & CUET-UG Coaching",
            description:
              "Board + IPMAT & CUET-UG integrated preparation for Commerce & Science students targeting India's top central universities & IIMs.",
            url: "https://dalmiaacademy.com/cuet-coaching",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            educationalLevel: "High School",
            teaches: ["CUET", "IPMAT", "Commerce", "Science"],
          },
          {
            "@type": "Course",
            name: "CA Foundation & CSEET",
            description:
              "Expert coaching for CA Foundation and CS Executive Entrance Test aspirants in Indore.",
            url: "https://dalmiaacademy.com/ca-foundation",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            teaches: ["CA Foundation", "CSEET", "Chartered Accountancy"],
          },
          {
            "@type": "Course",
            name: "11th & 12th Commerce",
            description:
              "Commerce with Applied Maths — build a strong foundation in Accountancy, Economics, Business Studies & more.",
            url: "https://dalmiaacademy.com/commerce-coaching",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            educationalLevel: "High School",
            teaches: ["Accountancy", "Economics", "Business Studies", "Applied Mathematics"],
          },
          {
            "@type": "Course",
            name: "11th & 12th Humanities",
            description:
              "Master Psychology, Economics, Geography & History with concept-based teaching and structured answer writing practice.",
            url: "https://dalmiaacademy.com/humanities-coaching",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            educationalLevel: "High School",
            teaches: ["Psychology", "Economics", "Geography", "History"],
          },
          {
            "@type": "Course",
            name: "Spoken English & Personality Development",
            description:
              "Boost your communication skills and confidence with our structured spoken English and personality development program.",
            url: "https://dalmiaacademy.com/spoken-english",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            teaches: ["Spoken English", "Communication Skills", "Personality Development"],
          },
          {
            "@type": "Course",
            name: "6th to 10th All Subjects Tuition",
            description:
              "Comprehensive tuition for all subjects — build strong fundamentals and excel in school exams.",
            url: "https://dalmiaacademy.com/school-coaching",
            provider: {
              "@type": "EducationalOrganization",
              name: "Dalmia Academy",
              url: "https://dalmiaacademy.com/",
            },
            educationalLevel: "Middle School",
            teaches: ["All Subjects", "School Foundation"],
          },
          {
            "@type": "Course",
            name: "ACCA Coaching",
            description: "ACCA (Association of Chartered Certified Accountants) coaching in Indore — all 13 papers across 3 levels.",
            url: "https://dalmiaacademy.com/acca-coaching",
            provider: { "@type": "EducationalOrganization", name: "Dalmia Academy", url: "https://dalmiaacademy.com/" },
            teaches: ["ACCA", "Financial Reporting", "Audit & Assurance", "Taxation"],
          },
          {
            "@type": "Course",
            name: "US CPA Coaching",
            description: "US CPA (Certified Public Accountant) coaching in Indore — all 4 sections: FAR, AUD, REG, BEC.",
            url: "https://dalmiaacademy.com/us-cpa-coaching",
            provider: { "@type": "EducationalOrganization", name: "Dalmia Academy", url: "https://dalmiaacademy.com/" },
            teaches: ["US CPA", "US GAAP", "Federal Taxation", "Auditing"],
          },
          {
            "@type": "Course",
            name: "US CMA Coaching",
            description: "US CMA (Certified Management Accountant) coaching in Indore — both parts covering financial planning and strategic management.",
            url: "https://dalmiaacademy.com/us-cma-coaching",
            provider: { "@type": "EducationalOrganization", name: "Dalmia Academy", url: "https://dalmiaacademy.com/" },
            teaches: ["US CMA", "Management Accounting", "Financial Planning", "Cost Management"],
          },
          {
            "@type": "Course",
            name: "CFA Coaching",
            description: "CFA (Chartered Financial Analyst) coaching in Indore — all 3 levels covering ethics, portfolio management, equity, fixed income and derivatives.",
            url: "https://dalmiaacademy.com/cfa-coaching",
            provider: { "@type": "EducationalOrganization", name: "Dalmia Academy", url: "https://dalmiaacademy.com/" },
            teaches: ["CFA", "Portfolio Management", "Equity Investments", "Fixed Income", "Derivatives"],
          },
        ],
      },
      employee: [
        {
          "@type": "Person",
          name: "Pramod Dalmia",
          jobTitle: "Founder & Academic Mentor",
          description:
            "Founder of Dalmia Academy with 35+ years of experience in Accounts & Economics. Builds strong foundation for CA & Commerce with focus on analytical thinking.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Accountancy", "Economics", "CA Foundation"],
        },
        {
          "@type": "Person",
          name: "Nidhi Ghosh",
          jobTitle: "Senior Faculty",
          description:
            "Senior Faculty with 7+ years of experience in History & Political Science. Known for engaging conceptual teaching and strong exam-oriented approach.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["History", "Political Science"],
        },
        {
          "@type": "Person",
          name: "Mohini Ojha",
          jobTitle: "Senior Faculty",
          description:
            "Senior Faculty with 15+ years of experience in Geography. Specializes in in-depth conceptual clarity and exam-oriented teaching methodology.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Geography"],
        },
        {
          "@type": "Person",
          name: "Anand Potdar",
          jobTitle: "Senior Faculty — Spoken English & Communication Coach",
          description:
            "Senior Faculty with 20+ years of experience. Specializes in communication skills development and fluency-focused training.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Spoken English", "Communication", "Personality Development"],
        },
        {
          "@type": "Person",
          name: "Mekhala Kanade",
          jobTitle: "Senior Faculty",
          description:
            "Senior Faculty with 25+ years of experience in Accountancy. Focuses on board-focused preparation and step-by-step explanations.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Accountancy"],
        },
        {
          "@type": "Person",
          name: "Rashmi Pawar",
          jobTitle: "Senior Faculty",
          description:
            "Senior Faculty with 29+ years of experience in Economics. Specializes in strong macro & micro foundation and graph-based explanation.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Economics", "Macroeconomics", "Microeconomics"],
        },
        {
          "@type": "Person",
          name: "Sunil Jain",
          jobTitle: "Senior Faculty",
          description:
            "Senior Faculty with 28+ years of experience in Mathematics. Emphasizes concept clarity before formulas and practice-based learning.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Mathematics", "Applied Mathematics"],
        },
        {
          "@type": "Person",
          name: "Rakesh Thakur",
          jobTitle: "Senior Academician",
          description:
            "Senior Academician with 36+ years of experience in Accountancy. Known for comprehensive subject coverage and regular testing & evaluation.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Accountancy"],
        },
        {
          "@type": "Person",
          name: "Ajay Bagodiya",
          jobTitle: "Senior Advocate — Business Law Faculty",
          description:
            "Senior Advocate with 35+ years of experience in Business Law. Specializes in practical case-based teaching and strong exam application focus.",
          worksFor: { "@type": "EducationalOrganization", name: "Dalmia Academy" },
          knowsAbout: ["Business Law", "Corporate Law"],
        },
      ],
      aggregateRating: {
        "@type": "AggregateRating",
        ratingValue: "5",
        reviewCount: "8",
        bestRating: "5",
        worstRating: "1",
      },
      review: [
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Sheetal Kushwah" },
          reviewBody:
            "Pramod Dalmia Sir's unique teaching style builds both confidence and perfection. The structured practice questions and disciplined approach kept me motivated throughout.",
          name: "Concept clarity like never before!",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Shivam Patidar" },
          reviewBody:
            "I studied Accountancy under Dalmia Sir in Class 11, 12, and CA Foundation. His focus on deep conceptual clarity helped me even at higher CA levels.",
          name: "Best Accountancy Teacher!",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Muskan Bhaiya" },
          reviewBody:
            "The concepts I learned here helped me not just in Class 12 but also in college and CFA exams. Sir ensures that every student truly understands the subject.",
          name: "Strong Foundation That Helped in College & CFA",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Rounit Soni" },
          reviewBody:
            "Dalmia Sir doesn't just teach for marks — he builds long-term clarity. His simple explanation of complex topics helped me score 95 in Accountancy.",
          name: "Scored 95 in Boards Because of Concept Clarity",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Sanskriti Sharma" },
          reviewBody:
            "I didn't just learn accounts — I learned about financial markets, mutual funds, and real-world applications. Sir stays connected with students even beyond academics.",
          name: "Beyond Academics — Real-World Learning",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Aman Lakhawat" },
          reviewBody:
            "With 30+ years of experience, Sir explains concepts through relatable examples. He personally tracks student progress and gives tailored tasks.",
          name: "Exceptional Mentor and Guide",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Vaibhav Korde" },
          reviewBody:
            "Two-way communication in class makes learning interactive. The teaching style is comforting and practical, which makes difficult topics easy to grasp.",
          name: "Interactive & Practical Teaching",
        },
        {
          "@type": "Review",
          author: { "@type": "Person", name: "Aryan Jain" },
          reviewBody:
            "Sir was always available for doubts, even beyond class hours. His guidance in Class 12 continues to help me in college and life.",
          name: "Always Available for Doubts",
        },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "@id": "https://dalmiaacademy.com/#localbusiness",
      name: "Dalmia Academy",
      url: "https://dalmiaacademy.com/",
      telephone: "+91-95757-76655",
      email: "dalmiaacademy@gmail.com",
      image: "https://dalmiaacademy.com/logo.png",
      description:
        "Indore's trusted coaching institute for CUET, CA Foundation, Commerce, Humanities, Spoken English & School Tuition since 1991. Located at Geeta Bhawan Square, AB Road — near Vijay Nagar, Palasia & Sapna Sangeeta.",
      address: {
        "@type": "PostalAddress",
        streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
        addressLocality: "Indore",
        addressRegion: "Madhya Pradesh",
        postalCode: "452001",
        addressCountry: "IN",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: 22.7196,
        longitude: 75.8577,
      },
      hasMap: "https://www.google.com/maps/place/?q=place_id:ChIJH579QzX9YjkR4wewVlLwGW8",
      openingHours: "Mo-Sa 07:00-20:00",
      priceRange: "₹₹",
      currenciesAccepted: "INR",
      paymentAccepted: "Cash, Bank Transfer, UPI",
      areaServed: { "@type": "City", name: "Indore" },
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "@id": "https://dalmiaacademy.com/#website",
      url: "https://dalmiaacademy.com/",
      name: "Dalmia Academy Indore",
      description:
        "Coaching for CUET, CA, Commerce, Humanities & School — Dalmia Academy, Indore",
      publisher: { "@type": "EducationalOrganization", "@id": "https://dalmiaacademy.com/#organization" },
      potentialAction: {
        "@type": "SearchAction",
        target: {
          "@type": "EntryPoint",
          urlTemplate: "https://dalmiaacademy.com/?s={search_term_string}",
        },
        "query-input": "required name=search_term_string",
      },
    },
  ];
}