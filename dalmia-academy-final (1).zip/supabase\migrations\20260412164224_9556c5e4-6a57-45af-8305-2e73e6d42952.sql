
CREATE TABLE public.summer_leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  parent_name TEXT NOT NULL,
  child_name TEXT NOT NULL,
  class_grade TEXT NOT NULL,
  phone TEXT NOT NULL,
  activity TEXT NOT NULL,
  batch_preference TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT 'Indore',
  source TEXT NOT NULL DEFAULT 'landing_page_form',
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  utm_content TEXT,
  utm_term TEXT,
  page_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.summer_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert summer_leads"
  ON public.summer_leads
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Admins can read summer_leads"
  ON public.summer_leads
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Team can read summer_leads"
  ON public.summer_leads
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'team'::app_role));
