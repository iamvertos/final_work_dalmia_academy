// Lightweight GTM dataLayer helpers — single source of truth for all dataLayer pushes.

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[];
  }
}

const getUtmContext = (): Record<string, string | null> => {
  if (typeof window === "undefined") return {};
  const p = new URLSearchParams(window.location.search);
  return {
    utm_source: p.get("utm_source"),
    utm_medium: p.get("utm_medium"),
    utm_campaign: p.get("utm_campaign"),
    utm_content: p.get("utm_content"),
    utm_term: p.get("utm_term"),
  };
};

export const pushDL = (event: string, payload: Record<string, unknown> = {}) => {
  if (typeof window === "undefined") return;
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event, ...getUtmContext(), ...payload });
};

export const pushPageView = (opts: { path: string; title: string }) => {
  pushDL("page_view", {
    page_path: opts.path,
    page_location: typeof window !== "undefined" ? window.location.href : "",
    page_title: opts.title,
  });
};

export const pushClick = (opts: {
  type: "phone_click" | "whatsapp_click" | "cta_click";
  source: string;
  link_url?: string;
}) => {
  pushDL(opts.type, {
    source_component: opts.source,
    link_url: opts.link_url,
  });
};

export const pushFormView = (form_name: string) => {
  pushDL("form_view", { form_name });
};

export const pushFormSubmit = (opts: {
  form_name: string;
  course?: string;
  value?: number;
  currency?: string;
}) => {
  pushDL("form_submit", {
    form_name: opts.form_name,
    course: opts.course,
    value: opts.value ?? 0,
    currency: opts.currency ?? "INR",
  });
};
