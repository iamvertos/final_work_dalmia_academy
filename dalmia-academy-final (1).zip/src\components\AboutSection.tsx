import { BookOpen, Users, Target, Award, GraduationCap, HeartHandshake } from "lucide-react";
import buildingPhoto from "@/assets/Dalmia_academy_Building_-tulsi_tower.webp";

const highlights = [
  { icon: BookOpen, text: "Concept-Based Learning — understanding over memorization" },
  { icon: Users, text: "Small Batch Size — focused attention for every student" },
  { icon: Target, text: "Board + Competitive Exam Expertise" },
  { icon: Award, text: "Regular Mock Tests & Performance Tracking" },
  { icon: GraduationCap, text: "Structured Notes & Exhaustive Practice Sheets" },
  { icon: HeartHandshake, text: "Career Guidance & Personal Mentorship" },
];

const AboutSection = () => {
  return (
    <section className="py-14 md:py-20 bg-muted" id="about">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          About Dalmia Academy
        </h2>
        <p className="text-center text-secondary font-semibold text-lg mb-10">
          Strong Foundation. Smart Learning. Sure Success.
        </p>

        <div className="flex flex-col lg:flex-row gap-10 max-w-6xl mx-auto items-center">
          {/* Building Image */}
          <div className="lg:w-5/12 flex-shrink-0">
            <div className="rounded-2xl overflow-hidden shadow-lg border-4 border-accent/20">
              <img
                src={buildingPhoto}
                alt="Dalmia Academy Building — 108-109, First Floor, Tulsi Tower, Indore"
                width={500}
                height={600}
                className="w-full h-auto object-cover"
                loading="lazy"
              />
            </div>
            <p className="text-xs text-muted-foreground text-center mt-2">
              108-109, First Floor, Tulsi Tower, Indore — Our Campus Since 1991
            </p>
          </div>

          {/* Content */}
          <div className="lg:w-7/12">
            <p className="text-muted-foreground leading-relaxed mb-4">
              Founded in <strong className="text-foreground">1991</strong>, Dalmia Academy is one of Indore's most trusted coaching institutes for Commerce education and professional exam preparation. For over <strong className="text-foreground">three decades</strong>, we have been committed to building strong academic foundations for students pursuing CA, CS, XI–XII Commerce, IPMAT, and CUET.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              <div className="bg-card rounded-lg p-4 border border-border">
                <h3 className="font-bold font-heading text-primary text-sm mb-1">🎯 Our Vision</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  To create confident, conceptually strong, and ethically grounded students who excel in academics and succeed in professional careers.
                </p>
              </div>
              <div className="bg-card rounded-lg p-4 border border-border">
                <h3 className="font-bold font-heading text-primary text-sm mb-1">🚀 Our Mission</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  To build deep conceptual clarity, prepare students for board & competitive exams with discipline, and provide personal mentorship & career guidance.
                </p>
              </div>
            </div>

            <h3 className="font-bold font-heading text-foreground text-sm mb-3">
              Why Students & Parents Trust Us
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {highlights.map((h) => (
                <div key={h.text} className="flex items-start gap-2">
                  <h.icon className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                  <span className="text-xs text-muted-foreground leading-relaxed">{h.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
