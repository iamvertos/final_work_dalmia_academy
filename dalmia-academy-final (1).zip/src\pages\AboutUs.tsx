import StickyHeader from "@/components/StickyHeader";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import LeadFormSection from "@/components/LeadFormSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";


const allCourseOptions = [
  { value: "IPMAT & CUET-UG", label: "IPMAT & CUET-UG" },
  { value: "CA / CS", label: "CA / CS Foundation" },
  { value: "Commerce 11th & 12th", label: "Commerce 11th & 12th" },
  { value: "Science 11th & 12th", label: "Science 11th & 12th" },
  { value: "6th-10th", label: "6th–10th Coaching" },
  { value: "Spoken English", label: "Spoken English" },
];

const AboutUs = () => {
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/about")} path="/about" />
      <StickyHeader />
      
      <main>
        {/* Hero Banner */}
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              About <span className="text-accent">Dalmia Academy</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
              Building strong foundations since 1991 — Indore's most trusted coaching institute for Commerce, CA, and competitive exams.
            </p>
          </div>
        </section>

        <AboutSection />
        <FacultySection />
        <LeadFormSection courseOptions={allCourseOptions} />
        <FinalCTASection
          headline="Join the Legacy of"
          highlightText="Excellence."
          subheadline="30+ years of shaping successful careers. Your journey starts here."
          whatsappMessage="Hi, I'd like to know more about Dalmia Academy, Indore. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'd like to know more about Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default AboutUs;
