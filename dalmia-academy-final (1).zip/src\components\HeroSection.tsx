import { Phone, CheckCircle } from "lucide-react";
import { trackClick } from "@/hooks/useClickTracking";
import { Button } from "@/components/ui/button";
import type { HeroContent } from "@/data/pageContent";

interface HeroSectionProps {
  content?: HeroContent;
}

const defaultContent: HeroContent = {
  headline: "Crack CUET & Secure Admission in",
  highlightText: "India's Top Universities",
  subheadline: "Board + CUET Integrated Preparation in Indore — Start Your Journey Today",
  benefits: ["Limited Batches", "Expert Faculty", "CUET Pattern Prep", "Board + CUET Together"],
  stats: [
    { value: "10+", label: "Years Experience" },
    { value: "500+", label: "Students Guided" },
    { value: "25", label: "Max Batch Size" },
  ],
};

const HeroSection = ({ content = defaultContent }: HeroSectionProps) => {
  return (
    <section className="bg-primary text-primary-foreground py-12 md:py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-3xl md:text-5xl font-extrabold font-heading leading-tight mb-4">
            {content.headline}{" "}
            <span className="text-accent">{content.highlightText}</span>
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-6 font-body">
            {content.subheadline}
          </p>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {content.benefits.map((b) => (
              <span
                key={b}
                className="inline-flex items-center gap-1.5 bg-secondary/20 text-primary-foreground rounded-full px-4 py-1.5 text-sm font-medium"
              >
                <CheckCircle className="h-4 w-4 text-accent" />
                {b}
              </span>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-10">
            <Button
              asChild
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-bold text-base"
            >
              <a href="#lead-form">Book Free Demo</a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-heading font-bold text-base"
            >
              <a href="#lead-form">Get Free Counseling</a>
            </Button>
          </div>

          <a
            href="tel:+919575776655"
            onClick={() => trackClick("phone_click", "hero")}
            className="inline-flex items-center gap-2 text-accent font-semibold text-lg mb-10"
          >
            <Phone className="h-5 w-5" />
            +91 9575776655
          </a>

          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mt-6 pt-8 border-t border-primary-foreground/20">
            {content.stats.map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-2xl md:text-3xl font-extrabold font-heading text-accent">
                  {s.value}
                </div>
                <div className="text-xs md:text-sm opacity-80">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
