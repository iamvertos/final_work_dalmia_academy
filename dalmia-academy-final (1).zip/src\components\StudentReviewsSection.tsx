import { Star } from "lucide-react";
import sheetalImg from "@/assets/sheetal_png.webp";
import shivamImg from "@/assets/Shivam.webp";
import muskanImg from "@/assets/Muskan_Bhaiya.webp";
import raunitImg from "@/assets/raunit.webp";
import sanskritiImg from "@/assets/Divya-Suryawanshi.webp";
import amanImg from "@/assets/Ashish.webp";
import vaibhavImg from "@/assets/vaibhav.webp";
import aryanImg from "@/assets/Samarish-MandalKumar-Kushwaha.webp";

const reviews = [
  {
    name: "Sheetal Kushwah",
    designation: "Student",
    headline: "Concept clarity like never before!",
    text: "Pramod Dalmia Sir's unique teaching style builds both confidence and perfection. The structured practice questions and disciplined approach kept me motivated throughout. I feel fortunate to have learned from a mentor who truly cares about student success.",
    image: sheetalImg,
  },
  {
    name: "Shivam Patidar",
    designation: "CA Final Student",
    headline: "Best Accountancy Teacher!",
    text: "I studied Accountancy under Dalmia Sir in Class 11, 12, and CA Foundation. His focus on deep conceptual clarity helped me even at higher CA levels. The detailed practice sheets cover every possible question type.",
    image: shivamImg,
  },
  {
    name: "Muskan Bhaiya",
    designation: "Student",
    headline: "Strong Foundation That Helped in College & CFA",
    text: "The concepts I learned here helped me not just in Class 12 but also in college and CFA exams. Sir ensures that every student truly understands the subject.",
    image: muskanImg,
  },
  {
    name: "Rounit Soni",
    designation: "Analyst",
    headline: "Scored 95 in Boards Because of Concept Clarity",
    text: "Dalmia Sir doesn't just teach for marks — he builds long-term clarity. His simple explanation of complex topics and constant practice mantra helped me score 95 in Accountancy.",
    image: raunitImg,
  },
  {
    name: "Sanskriti Sharma",
    designation: "Student",
    headline: "Beyond Academics — Real-World Learning",
    text: "I didn't just learn accounts — I learned about financial markets, mutual funds, and real-world applications. Sir stays connected with students even beyond academics.",
    image: sanskritiImg,
  },
  {
    name: "Aman Lakhawat",
    designation: "CA Final Student",
    headline: "Exceptional Mentor and Guide",
    text: "With 30+ years of experience, Sir explains concepts through relatable examples. He personally tracks student progress and gives tailored tasks. Exceptional mentor and guide.",
    image: amanImg,
  },
  {
    name: "Vaibhav Korde",
    designation: "Student",
    headline: "Interactive & Practical Teaching",
    text: "Two-way communication in class makes learning interactive. The teaching style is comforting and practical, which makes difficult topics easy to grasp.",
    image: vaibhavImg,
  },
  {
    name: "Aryan Jain",
    designation: "Student",
    headline: "Always Available for Doubts",
    text: "Sir was always available for doubts, even beyond class hours. His guidance in Class 12 continues to help me in college and life.",
    image: aryanImg,
  },
];

const StudentReviewsSection = () => {
  return (
    <section className="py-14 md:py-20 bg-primary/5" id="reviews">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          What Our Students Say
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          Real reviews from students who built strong foundations at Dalmia Academy
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-5xl mx-auto">
          {reviews.map((r) => (
            <div
              key={r.name}
              className="bg-card rounded-lg p-5 shadow-sm border border-border hover:shadow-md transition-shadow"
            >
              <div className="flex gap-0.5 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-accent text-accent" />
                ))}
              </div>
              <h3 className="font-bold font-heading text-foreground text-sm mb-2">
                "{r.headline}"
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed italic mb-3">
                {r.text}
              </p>
              <div className="flex items-center gap-3">
                <img
                  src={r.image}
                  alt={r.name}
                  width={40}
                  height={40}
                  loading="lazy"
                  className="w-10 h-10 rounded-full object-cover border-2 border-primary/20"
                />
                <div>
                  <p className="font-semibold font-heading text-foreground text-sm">{r.name}</p>
                  <p className="text-xs text-secondary">{r.designation}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StudentReviewsSection;
