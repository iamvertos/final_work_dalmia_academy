import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { cuetContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const cuetCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/cuet-coaching#course",
  name: "IPMAT & CUET-UG Coaching",
  description:
    "Board + IPMAT & CUET-UG integrated preparation for Commerce and Science students targeting India's top central universities and IIMs. Curriculum designed specifically around IPMAT & CUET-UG exam patterns with concept-based teaching, regular mock tests, and personal mentorship.",
  url: "https://dalmiaacademy.com/cuet-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "HighSchool",
  teaches: [
    "CUET-UG",
    "IPMAT",
    "Accountancy",
    "Economics",
    "Business Studies",
    "English",
    "General Test",
    "Physics",
    "Chemistry",
    "Mathematics",
    "Biology",
  ],
  coursePrerequisites: "Class 11 or 12 (Commerce or Science stream)",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "Commerce IPMAT & CUET-UG Prep",
      description:
        "Complete preparation for Commerce students targeting top universities through IPMAT & CUET-UG, with Board alignment. Covers Accountancy, Economics, Business Studies, English, and General Test.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
      instructor: {
        "@type": "Person",
        name: "Pramod Dalmia",
        jobTitle: "Founder & Academic Mentor",
      },
    },
    {
      "@type": "CourseInstance",
      name: "Science CUET-UG Prep",
      description:
        "Comprehensive Science preparation combining Board syllabus with CUET-UG specific strategies. Covers Physics, Chemistry, Maths/Biology, English, and General Test.",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  about: [
    { "@type": "Thing", name: "CUET-UG Exam Preparation" },
    { "@type": "Thing", name: "IPMAT Exam Preparation" },
    { "@type": "Thing", name: "Board Exam Preparation" },
    { "@type": "Thing", name: "Commerce Coaching" },
    { "@type": "Thing", name: "Science Coaching" },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Demo Available",
    url: "https://dalmiaacademy.com/cuet-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "5",
    reviewCount: "8",
    bestRating: "5",
    worstRating: "1",
  },
};

const CUETCoaching = () => {
  const seo = getPageSeo("/cuet-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/cuet-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/cuet-coaching" }),
          cuetCourseSchema,
          faqSchema(cuetContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "CUET & IPMAT Coaching in Indore", path: "/cuet-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <AnnouncementBanner />
      <main>
        <HeroSection content={cuetContent.hero} />
        <WhyChooseSection
          heading={cuetContent.whyChoose.heading}
          subheading={cuetContent.whyChoose.subheading}
          benefits={cuetContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={cuetContent.courses.heading}
          subheading={cuetContent.courses.subheading}
          courses={cuetContent.courses.items}
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={cuetContent.highlights.heading}
          subheading={cuetContent.highlights.subheading}
          highlights={cuetContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={cuetContent.leadForm.courseOptions} />
        <FAQSection faqs={cuetContent.faqs} />
        <FinalCTASection
          headline={cuetContent.finalCTA.headline}
          highlightText={cuetContent.finalCTA.highlightText}
          subheadline={cuetContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in IPMAT & CUET-UG Coaching at Dalmia Academy. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in IPMAT & CUET-UG Coaching at Dalmia Academy. Please share details." />
    </div>
  );
};

export default CUETCoaching;
