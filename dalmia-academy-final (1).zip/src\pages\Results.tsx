import StickyHeader from "@/components/StickyHeader";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { GraduationCap, Users, TrendingUp } from "lucide-react";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";

const stats = [
  { icon: GraduationCap, value: "30+", label: "Years of Excellence" },
  { icon: Users, value: "1000+", label: "Students Mentored" },
  { icon: TrendingUp, value: "90%+", label: "Pass Rate" },
];

const allCourseOptions = [
  { value: "IPMAT & CUET-UG", label: "IPMAT & CUET-UG" },
  { value: "CA / CS", label: "CA / CS Foundation" },
  { value: "Commerce 11th & 12th", label: "Commerce 11th & 12th" },
  { value: "Science 11th & 12th", label: "Science 11th & 12th" },
  { value: "6th-10th", label: "6th–10th Coaching" },
  { value: "Spoken English", label: "Spoken English" },
];

const Results = () => {
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/results")} path="/results" />
      <StickyHeader />
      <main>
        {/* Hero Banner */}
        <section className="bg-primary py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              Our Results & <span className="text-accent">Student Stories</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
              Real success stories from students who built strong foundations at Dalmia Academy.
            </p>
          </div>
        </section>

        {/* Stats Bar */}
        <section className="py-10 bg-muted">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
              {stats.map((s) => (
                <div key={s.label} className="text-center">
                  <s.icon className="h-8 w-8 text-accent mx-auto mb-2" />
                  <p className="text-3xl font-bold font-heading text-primary">{s.value}</p>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <StudentReviewsSection />
        <LeadFormSection courseOptions={allCourseOptions} />
        <FinalCTASection
          headline="Your Success Story"
          highlightText="Starts Here."
          subheadline="Join 1000+ students who trusted Dalmia Academy for their academic journey."
          whatsappMessage="Hi, I saw Dalmia Academy's results and I'm interested. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I saw Dalmia Academy's results and I'm interested. Please share details." />
    </div>
  );
};

export default Results;
