import { createContext, useContext, useEffect, useState, useRef, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User, Session } from "@supabase/supabase-js";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isCounselor: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isCounselor, setIsCounselor] = useState(false);
  const [rolesLoading, setRolesLoading] = useState(false);
  const initialLoadDone = useRef(false);

  // Decouple role checking from auth callbacks to avoid Supabase client lock deadlock
  const checkRoles = async (userId: string) => {
    try {
      const [adminResult, counselorResult] = await Promise.all([
        supabase.rpc("has_role", { _user_id: userId, _role: "admin" as const }),
        supabase.rpc("has_role", { _user_id: userId, _role: "team" as const }),
      ]);
      setIsAdmin(adminResult.data === true);
      setIsCounselor(counselorResult.data === true);
    } catch (err) {
      console.error("Failed to check user roles:", err);
      setIsAdmin(false);
      setIsCounselor(false);
    }
  };

  // Watch for user changes and check roles OUTSIDE of auth callbacks
  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setIsCounselor(false);
      return;
    }
    
    let cancelled = false;
    setRolesLoading(true);
    
    checkRoles(user.id).finally(() => {
      if (!cancelled) {
        setRolesLoading(false);
      }
    });
    
    return () => { cancelled = true; };
  }, [user?.id]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (!initialLoadDone.current) {
        console.warn("Auth loading timed out after 5s");
        initialLoadDone.current = true;
        setLoading(false);
      }
    }, 5000);

    // IMPORTANT: Only set user/session state in onAuthStateChange — NO database calls
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        if (initialLoadDone.current) {
          setLoading(false);
        }
      }
    );

    const initSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        setSession(session);
        setUser(session?.user ?? null);
      } catch (err) {
        console.error("Failed to get session:", err);
      } finally {
        initialLoadDone.current = true;
        setLoading(false);
      }
    };

    initSession();

    return () => {
      clearTimeout(timeout);
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { error: error as Error | null };
      // Just set the session/user — the useEffect watching user.id will trigger checkRoles
      if (data.session) {
        setSession(data.session);
        setUser(data.session.user);
      }
      return { error: null };
    } catch (err) {
      console.error("Sign in error:", err);
      return { error: err instanceof Error ? err : new Error("Sign in failed") };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setIsAdmin(false);
    setIsCounselor(false);
  };

  return (
    <AuthContext.Provider value={{ user, session, loading: loading || rolesLoading, isAdmin, isCounselor, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
