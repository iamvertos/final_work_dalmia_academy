// Runs before `vite dev` and `vite build` (predev/prebuild hooks); writes public/sitemap.xml.

import { writeFileSync } from "fs";
import { resolve } from "path";

const BASE_URL = "https://dalmiaacademy.com";
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || "https://bqqxdfjiaativhtknqsu.supabase.co";
const SUPABASE_ANON_KEY =
  process.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJxcXhkZmppYWF0aXZodGtucXN1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE0Mzc1MzUsImV4cCI6MjA4NzAxMzUzNX0.QOjN7lytCOBMNSD1Ct5T5ayv6A2BX5V6GLsG0I3zVrw";

type ChangeFreq = "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";

interface SitemapEntry {
  path: string;
  lastmod?: string;
  changefreq?: ChangeFreq;
  priority?: string;
}

import staticRoutes from "../src/data/static-routes.json";

const today = new Date().toISOString().split("T")[0];

const staticEntries: SitemapEntry[] = (staticRoutes as Array<{
  path: string;
  changefreq: ChangeFreq;
  priority: string;
  indexable: boolean;
}>)
  .filter((r) => r.indexable)
  .map((r) => ({
    path: r.path,
    changefreq: r.changefreq,
    priority: r.priority,
    lastmod: today,
  }));

async function fetchBlogEntries(): Promise<SitemapEntry[]> {
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/blog_posts?select=slug,updated_at&published=eq.true`,
      {
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
      },
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const rows = (await res.json()) as Array<{ slug: string; updated_at: string }>;
    return rows.map((r) => ({
      path: `/blog/${r.slug}`,
      lastmod: (r.updated_at || "").split("T")[0] || today,
      changefreq: "monthly" as ChangeFreq,
      priority: "0.7",
    }));
  } catch (err) {
    console.warn("[sitemap] Could not fetch blog posts:", (err as Error).message);
    return [];
  }
}

function generateSitemap(entries: SitemapEntry[]) {
  const urls = entries.map((e) =>
    [
      `  <url>`,
      `    <loc>${BASE_URL}${e.path}</loc>`,
      e.lastmod ? `    <lastmod>${e.lastmod}</lastmod>` : null,
      e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
      e.priority ? `    <priority>${e.priority}</priority>` : null,
      `  </url>`,
    ]
      .filter(Boolean)
      .join("\n"),
  );

  return [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
    ...urls,
    `</urlset>`,
    ``,
  ].join("\n");
}

async function main() {
  const blog = await fetchBlogEntries();
  const entries = [...staticEntries, ...blog];
  writeFileSync(resolve("public/sitemap.xml"), generateSitemap(entries));
  console.log(`sitemap.xml written (${entries.length} entries)`);
}

main();