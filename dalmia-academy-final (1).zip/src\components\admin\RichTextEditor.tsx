import { useRef, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Bold, Italic, Underline, Strikethrough, Heading2, Heading3, Heading4,
  List, ListOrdered, Link as LinkIcon, Image, Quote, Code, Minus, Undo, Redo,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";

interface RichTextEditorProps {
  content: string;
  onChange: (html: string) => void;
}

const RichTextEditor = ({ content, onChange }: RichTextEditorProps) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const [imageDialogOpen, setImageDialogOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const initializedRef = useRef(false);

  useEffect(() => {
    if (editorRef.current && !initializedRef.current) {
      editorRef.current.innerHTML = content;
      initializedRef.current = true;
    }
  }, [content]);

  const exec = useCallback((command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    handleInput();
  }, []);

  const handleInput = useCallback(() => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  }, [onChange]);

  const handleFormatBlock = useCallback((tag: string) => {
    document.execCommand("formatBlock", false, tag);
    editorRef.current?.focus();
    handleInput();
  }, [handleInput]);

  const handleInsertLink = () => {
    if (linkUrl) {
      exec("createLink", linkUrl);
    }
    setLinkDialogOpen(false);
    setLinkUrl("");
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `blog/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("blog-images").upload(path, file);
    if (error) {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    } else {
      const { data: urlData } = supabase.storage.from("blog-images").getPublicUrl(path);
      exec("insertHTML", `<img src="${urlData.publicUrl}" alt="" class="max-w-full rounded my-4" />`);
    }
    setUploading(false);
    setImageDialogOpen(false);
  };

  const handleInsertImageUrl = () => {
    if (imageUrl) {
      exec("insertHTML", `<img src="${imageUrl}" alt="" class="max-w-full rounded my-4" />`);
    }
    setImageDialogOpen(false);
    setImageUrl("");
  };

  const ToolBtn = ({ icon: Icon, onClick, title }: { icon: any; onClick: () => void; title: string }) => (
    <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={onClick} title={title}>
      <Icon className="h-4 w-4" />
    </Button>
  );

  return (
    <div className="border border-border rounded-lg overflow-hidden bg-card">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-0.5 p-2 border-b border-border bg-muted/50">
        <ToolBtn icon={Bold} onClick={() => exec("bold")} title="Bold" />
        <ToolBtn icon={Italic} onClick={() => exec("italic")} title="Italic" />
        <ToolBtn icon={Underline} onClick={() => exec("underline")} title="Underline" />
        <ToolBtn icon={Strikethrough} onClick={() => exec("strikeThrough")} title="Strikethrough" />
        <div className="w-px h-6 bg-border mx-1" />
        <ToolBtn icon={Heading2} onClick={() => handleFormatBlock("<h2>")} title="Heading 2" />
        <ToolBtn icon={Heading3} onClick={() => handleFormatBlock("<h3>")} title="Heading 3" />
        <ToolBtn icon={Heading4} onClick={() => handleFormatBlock("<h4>")} title="Heading 4" />
        <div className="w-px h-6 bg-border mx-1" />
        <ToolBtn icon={List} onClick={() => exec("insertUnorderedList")} title="Bullet List" />
        <ToolBtn icon={ListOrdered} onClick={() => exec("insertOrderedList")} title="Numbered List" />
        <div className="w-px h-6 bg-border mx-1" />
        <ToolBtn icon={LinkIcon} onClick={() => setLinkDialogOpen(true)} title="Insert Link" />
        <ToolBtn icon={Image} onClick={() => setImageDialogOpen(true)} title="Insert Image" />
        <ToolBtn icon={Quote} onClick={() => handleFormatBlock("<blockquote>")} title="Blockquote" />
        <ToolBtn icon={Code} onClick={() => handleFormatBlock("<pre>")} title="Code Block" />
        <ToolBtn icon={Minus} onClick={() => exec("insertHorizontalRule")} title="Horizontal Rule" />
        <div className="w-px h-6 bg-border mx-1" />
        <ToolBtn icon={Undo} onClick={() => exec("undo")} title="Undo" />
        <ToolBtn icon={Redo} onClick={() => exec("redo")} title="Redo" />
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        className="min-h-[400px] p-4 focus:outline-none prose prose-lg max-w-none text-foreground [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-4 [&_blockquote]:italic [&_pre]:bg-muted [&_pre]:p-3 [&_pre]:rounded [&_img]:max-w-full [&_img]:rounded"
        onInput={handleInput}
        onBlur={handleInput}
      />

      {/* Link Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Insert Link</DialogTitle></DialogHeader>
          <Input placeholder="https://example.com" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} />
          <DialogFooter>
            <Button onClick={handleInsertLink}>Insert</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Image Dialog */}
      <Dialog open={imageDialogOpen} onOpenChange={setImageDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Insert Image</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Upload image</p>
              <Input type="file" accept="image/*" onChange={handleImageUpload} disabled={uploading} />
            </div>
            <div className="text-center text-xs text-muted-foreground">— or —</div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Image URL</p>
              <Input placeholder="https://..." value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleInsertImageUrl} disabled={!imageUrl}>Insert URL</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RichTextEditor;
