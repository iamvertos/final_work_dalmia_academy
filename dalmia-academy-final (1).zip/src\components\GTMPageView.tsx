import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { pushPageView } from "@/lib/gtm";

const GTMPageView = () => {
  const location = useLocation();

  useEffect(() => {
    // Defer one tick so React Helmet / route components can update document.title first.
    const id = window.setTimeout(() => {
      pushPageView({
        path: location.pathname + location.search,
        title: document.title,
      });
    }, 0);
    return () => window.clearTimeout(id);
  }, [location.pathname, location.search]);

  return null;
};

export default GTMPageView;
