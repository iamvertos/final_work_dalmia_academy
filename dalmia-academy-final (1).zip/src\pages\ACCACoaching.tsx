import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import RichTextSection from "@/components/RichTextSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { accaContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const accaCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/acca-coaching#course",
  name: "ACCA Coaching in Indore",
  description:
    "ACCA (Association of Chartered Certified Accountants) coaching at Dalmia Academy, Indore. Structured preparation for all 13 ACCA papers across Applied Knowledge, Applied Skills, and Strategic Professional levels with expert faculty and small batches.",
  url: "https://dalmiaacademy.com/acca-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "ProfessionalCertificate",
  teaches: [
    "Financial Accounting", "Management Accounting", "Business & Technology",
    "Corporate & Business Law", "Performance Management", "Taxation",
    "Financial Reporting", "Audit & Assurance", "Financial Management",
    "Strategic Business Leader", "Strategic Business Reporting",
    "Advanced Financial Management", "Advanced Audit & Assurance",
  ],
  coursePrerequisites: "Class 12 pass (Commerce preferred) or Graduation",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      postalCode: "452001",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "ACCA Applied Knowledge",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "ACCA Applied Skills",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
    {
      "@type": "CourseInstance",
      name: "ACCA Strategic Professional",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Counselling Available",
    url: "https://dalmiaacademy.com/acca-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
};

const accaContentBlocks = [
  {
    heading: "What is ACCA and Why Pursue It from Indore?",
    content: `<p><strong>ACCA (Association of Chartered Certified Accountants)</strong> is one of the world's most prestigious accounting qualifications, recognized in over 180 countries. With 233,000+ members and 536,000+ students globally, ACCA opens doors to careers at Big 4 firms, multinational corporations, banks, and consulting firms worldwide.</p>
<p>Traditionally, students from Indore had to travel to Mumbai, Delhi, or Pune for quality ACCA coaching. <strong>Dalmia Academy changes that</strong> — bringing structured, expert-led ACCA preparation to Indore. Our 30+ years of accounting teaching excellence provides the perfect foundation for ACCA's rigorous, application-based syllabus.</p>
<p>Whether you're a Commerce graduate, CA student looking to add a global credential, or a working professional seeking career acceleration — ACCA coaching at Dalmia Academy in Indore gives you world-class preparation with the personal attention that only a local, small-batch institute can provide.</p>`,
  },
  {
    heading: "ACCA Syllabus Overview — 13 Papers Across 3 Levels",
    content: `<p><strong>Applied Knowledge (3 papers):</strong> Business and Technology (BT), Management Accounting (MA), Financial Accounting (FA). These foundation papers build your core business and accounting knowledge. Can be completed alongside graduation.</p>
<p><strong>Applied Skills (6 papers):</strong> Corporate and Business Law (LW), Performance Management (PM), Taxation (TX), Financial Reporting (FR), Audit and Assurance (AA), Financial Management (FM). These papers develop technical expertise across all key areas of professional accounting.</p>
<p><strong>Strategic Professional (4 papers):</strong> Strategic Business Leader (SBL) and Strategic Business Reporting (SBR) are compulsory. Choose 2 from: Advanced Financial Management (AFM), Advanced Performance Management (APM), Advanced Taxation (ATX), Advanced Audit and Assurance (AAA). These papers test strategic thinking and professional judgment.</p>
<p>At Dalmia Academy Indore, each paper is taught with exam-focused methodology — combining conceptual learning with extensive past paper practice and mock exams aligned to ACCA's quarterly exam sessions.</p>`,
  },
  {
    heading: "ACCA vs CA — Which Should You Choose?",
    content: `<p>Both ACCA and Indian CA are prestigious qualifications, but they serve different career goals:</p>
<p><strong>Choose ACCA if:</strong> You want international career mobility, plan to work at multinational companies or abroad, want a qualification recognized in 180+ countries, or prefer a flexible exam structure with quarterly exam windows.</p>
<p><strong>Choose CA if:</strong> You want to practice as an auditor in India, prefer the established Indian CA ecosystem, or want a qualification deeply embedded in Indian tax and regulatory frameworks.</p>
<p><strong>Many students pursue both.</strong> CA students get exemptions in up to 9 ACCA papers, making it highly efficient to add ACCA after CA. At Dalmia Academy, we offer both CA Foundation and ACCA coaching, so we can guide you on the best path based on your career goals.</p>`,
  },
];

const ACCACoaching = () => {
  const seo = getPageSeo("/acca-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/acca-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/acca-coaching" }),
          accaCourseSchema,
          faqSchema(accaContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "ACCA Coaching in Indore", path: "/acca-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <main>
        <HeroSection content={accaContent.hero} />
        <WhyChooseSection
          heading={accaContent.whyChoose.heading}
          subheading={accaContent.whyChoose.subheading}
          benefits={accaContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={accaContent.courses.heading}
          subheading={accaContent.courses.subheading}
          courses={accaContent.courses.items}
        />
        <RichTextSection
          sectionHeading="Everything You Need to Know About ACCA"
          blocks={accaContentBlocks}
          lastUpdated="May 2026"
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={accaContent.highlights.heading}
          subheading={accaContent.highlights.subheading}
          highlights={accaContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={accaContent.leadForm.courseOptions} />
        <FAQSection faqs={accaContent.faqs} />
        <FinalCTASection
          headline={accaContent.finalCTA.headline}
          highlightText={accaContent.finalCTA.highlightText}
          subheadline={accaContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in ACCA Coaching at Dalmia Academy, Indore. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in ACCA Coaching at Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default ACCACoaching;
