import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import StickyHeader from "@/components/StickyHeader";
import Footer from "@/components/Footer";
import { ArrowLeft, Clock, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import SEO from "@/components/seo/SEO";
import { articleSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

interface Post {
  id: string;
  title: string;
  slug: string;
  cover_image_url: string | null;
  content: string | null;
  category: string | null;
  created_at: string;
  updated_at?: string;
  excerpt?: string | null;
  author_name?: string;
  reading_time_minutes?: number;
  meta_title?: string;
  meta_description?: string;
  meta_keywords?: string;
  og_image_url?: string;
  schema_type?: string;
  canonical_url?: string;
}

const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      if (!slug) return;
      const { data } = await supabase
        .from("blog_posts")
        .select("*")
        .eq("slug", slug)
        .eq("published", true)
        .maybeSingle();
      setPost(data as Post | null);
      setLoading(false);
    };
    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader />
        <div className="container mx-auto px-4 py-20 text-center text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <SEO path={`/blog/${slug ?? ""}`} title="Article Not Found — Dalmia Academy Blog" description="This article doesn't exist." noindex />
        <StickyHeader />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold font-heading text-foreground mb-4">Article Not Found</h1>
          <Button asChild variant="outline">
            <Link to="/blog"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Blog</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const articlePath = `/blog/${post.slug}`;
  const seoTitle = post.meta_title || `${post.title} — Dalmia Academy Blog`;
  const seoDescription = post.meta_description || post.excerpt || `${post.title} — Dalmia Academy Indore.`;
  const seoImage = post.og_image_url || post.cover_image_url || undefined;

  return (
    <div className="min-h-screen bg-background">
      <SEO
        path={articlePath}
        title={seoTitle}
        description={seoDescription}
        image={seoImage}
        imageAlt={post.title}
        type="article"
        canonical={post.canonical_url}
        keywords={post.meta_keywords}
        articleMeta={{
          publishedTime: post.created_at,
          modifiedTime: post.updated_at,
          author: post.author_name || "Dalmia Academy",
          section: post.category || undefined,
        }}
        schema={[
          articleSchema({
            title: post.title,
            slug: post.slug,
            description: seoDescription,
            image: seoImage,
            author: post.author_name,
            datePublished: post.created_at,
            dateModified: post.updated_at,
            schemaType: post.schema_type,
          }),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Blog", path: "/blog" },
            { name: post.title, path: articlePath },
          ]),
        ]}
      />
      <StickyHeader />
      <main>
        {post.cover_image_url && (
          <div className="w-full h-64 md:h-96 overflow-hidden">
            <img src={post.cover_image_url} alt={post.title} className="w-full h-full object-cover" />
          </div>
        )}
        <article className="container mx-auto px-4 py-10 max-w-3xl">
          <Link to="/blog" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
            <ArrowLeft className="h-4 w-4" /> Back to Blog
          </Link>
          <div className="flex items-center gap-3 mb-3 flex-wrap">
            {post.category && (
              <span className="text-xs bg-primary/10 text-primary rounded-full px-2.5 py-0.5 font-medium">{post.category}</span>
            )}
            <span className="text-xs text-muted-foreground">
              {new Date(post.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
            </span>
            {post.author_name && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <User className="h-3 w-3" /> {post.author_name}
              </span>
            )}
            {post.reading_time_minutes && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" /> {post.reading_time_minutes} min read
              </span>
            )}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold font-heading text-foreground mb-6">{post.title}</h1>
          <div
            className="prose prose-lg max-w-none text-foreground"
            dangerouslySetInnerHTML={{ __html: post.content || "" }}
          />
        </article>
      </main>
      <Footer />
    </div>
  );
};

export default BlogPost;
