import { Badge } from "@/components/ui/badge";

const statusColors: Record<string, string> = {
  New: "bg-blue-100 text-blue-800 border-blue-200",
  Contacted: "bg-sky-100 text-sky-800 border-sky-200",
  "Not Reachable": "bg-gray-100 text-gray-800 border-gray-200",
  Interested: "bg-emerald-100 text-emerald-800 border-emerald-200",
  "Demo Booked": "bg-violet-100 text-violet-800 border-violet-200",
  "Follow-up Required": "bg-amber-100 text-amber-800 border-amber-200",
  "Admission Confirmed": "bg-green-100 text-green-800 border-green-200",
  Lost: "bg-red-100 text-red-800 border-red-200",
};

export const LEAD_STATUSES = [
  "New",
  "Contacted",
  "Not Reachable",
  "Interested",
  "Demo Booked",
  "Follow-up Required",
  "Admission Confirmed",
  "Lost",
];

const LeadStatusBadge = ({ status }: { status: string }) => {
  const colorClass = statusColors[status] || "bg-muted text-muted-foreground";
  return (
    <Badge variant="outline" className={`${colorClass} text-xs font-medium`}>
      {status}
    </Badge>
  );
};

export default LeadStatusBadge;
