import { Link } from "react-router-dom";
import { ArrowRight, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import StickyHeader from "@/components/StickyHeader";

import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { homePageCourses } from "@/data/pageContent";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { homepageGraphSchema } from "@/components/seo/SchemaMarkup";


const allCourseOptions = [
{ value: "CUET", label: "IPMAT & CUET-UG Coaching" },
{ value: "CA Foundation", label: "CA Foundation / CSEET" },
{ value: "ACCA", label: "ACCA Coaching" },
{ value: "US CPA", label: "US CPA Coaching" },
{ value: "US CMA", label: "US CMA Coaching" },
{ value: "CFA", label: "CFA Coaching" },
{ value: "Commerce", label: "11th & 12th Commerce" },
{ value: "Humanities", label: "11th & 12th Humanities" },
{ value: "Spoken English", label: "Spoken English & Personality Development" },
{ value: "School 6-10", label: "6th to 10th All Subjects" }];


const Home = () => {
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO {...getPageSeo("/")} path="/" schema={homepageGraphSchema()} />

      <StickyHeader />
      
      <main>
        {/* Hero */}
        <section className="bg-primary text-primary-foreground py-14 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-5xl font-extrabold font-heading leading-tight mb-4">
              Your Path to{" "}
              <span className="text-accent">Academic Excellence</span>{" "}
              in Indore
            </h1>
            <p className="text-lg md:text-xl opacity-90 mb-8 max-w-2xl mx-auto font-body">
              Indore's most trusted coaching since 1991. Expert coaching for CUET, CA Foundation, Commerce, Humanities, Science, Spoken English & School Tuition — all under one roof at Geeta Bhawan Square.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center mb-6">
              <Button
                asChild
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-bold text-base">

                <a href="#courses">Explore Courses</a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10 font-heading font-bold text-base">

                <a href="#lead-form">Get Free Counseling</a>
              </Button>
            </div>
            <a
              href="tel:+919575776655"
              className="inline-flex items-center gap-2 text-accent font-semibold text-lg">

              <Phone className="h-5 w-5" />
              +91 95757 76655
            </a>

            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mt-10 pt-8 border-t border-primary-foreground/20">
              {[
              { value: "30+", label: "Years in Indore" },
              { value: "1000+", label: "Students Guided" },
              { value: "6", label: "Programs Offered" }].
              map((s) =>
              <div key={s.label} className="text-center">
                  <div className="text-2xl md:text-3xl font-extrabold font-heading text-accent">
                    {s.value}
                  </div>
                  <div className="text-xs md:text-sm opacity-80">{s.label}</div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Course Cards */}
        <section className="py-14 md:py-20" id="courses">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
              Our Programs
            </h2>
            <p className="text-center text-muted-foreground mb-4 max-w-2xl mx-auto">
              Choose the program that's right for you and take the first step toward success
            </p>
            <p className="text-center text-sm text-muted-foreground mb-10 max-w-2xl mx-auto">
              Also offering{" "}
              <Link to="/acca-coaching" className="text-primary font-medium hover:underline">ACCA</Link>,{" "}
              <Link to="/cfa-coaching" className="text-primary font-medium hover:underline">CFA</Link>,{" "}
              <Link to="/us-cpa-coaching" className="text-primary font-medium hover:underline">US CPA</Link> &{" "}
              <Link to="/us-cma-coaching" className="text-primary font-medium hover:underline">US CMA</Link> coaching in Indore.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {homePageCourses.map((course) =>
              <Link
                key={course.route}
                to={course.route}
                className="group bg-card rounded-xl p-6 shadow-sm border-2 border-border hover:border-secondary/50 hover:shadow-lg transition-all">

                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <course.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-bold font-heading text-foreground mb-2 group-hover:text-primary transition-colors">
                    {course.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {course.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {course.tags.map((tag) =>
                  <span
                    key={tag}
                    className="text-xs bg-muted text-foreground rounded-full px-3 py-1 font-medium">

                        {tag}
                      </span>
                  )}
                  </div>
                  <span className="inline-flex items-center gap-1 text-sm font-semibold text-secondary group-hover:text-primary transition-colors">
                    Learn More <ArrowRight className="h-4 w-4" />
                  </span>
                </Link>
              )}
            </div>
          </div>
        </section>

        <AboutSection />
        <FacultySection />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={allCourseOptions} />
        <FinalCTASection
          headline="Start Your Journey —"
          highlightText="Join Dalmia Academy"
          subheadline="Expert coaching, personal mentorship, and proven results. Enroll today!"
          whatsappMessage="Hi, I'm interested in coaching at Dalmia Academy, Indore. Please share details." />

      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in coaching at Dalmia Academy, Indore. Please share details." />
    </div>);

};

export default Home;