import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import type { CourseItem } from "@/data/pageContent";

interface CoursesSectionProps {
  heading?: string;
  subheading?: string;
  courses?: CourseItem[];
}

const CoursesSection = ({
  heading = "CUET Courses Offered",
  subheading = "Structured programs for Commerce and Science students preparing for CUET (UG)",
  courses = [],
}: CoursesSectionProps) => {
  return (
    <section className="py-14 md:py-20" id="courses">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-heading text-center text-primary mb-3">
          {heading}
        </h2>
        <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
          {subheading}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {courses.map((c) => (
            <Card key={c.title} className="border-2 border-border hover:border-secondary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <c.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="font-heading text-primary">{c.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{c.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {c.subjects.map((s) => (
                    <span
                      key={s}
                      className="text-xs bg-muted text-foreground rounded-full px-3 py-1 font-medium"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-heading font-semibold">
                  <a href="#lead-form">Enquire Now</a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
