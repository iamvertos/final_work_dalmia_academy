import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import WhyChooseSection from "@/components/WhyChooseSection";
import CoursesSection from "@/components/CoursesSection";
import RichTextSection from "@/components/RichTextSection";
import AboutSection from "@/components/AboutSection";
import FacultySection from "@/components/FacultySection";
import HighlightsSection from "@/components/HighlightsSection";
import StudentReviewsSection from "@/components/StudentReviewsSection";
import LeadFormSection from "@/components/LeadFormSection";
import FAQSection from "@/components/FAQSection";
import FinalCTASection from "@/components/FinalCTASection";
import StickyBottomBar from "@/components/StickyBottomBar";
import { usCpaContent } from "@/data/pageContent";
import Footer from "@/components/Footer";
import SEO from "@/components/seo/SEO";
import { getPageSeo } from "@/data/seo-meta";
import { serviceSchema, faqSchema, breadcrumbSchema } from "@/components/seo/SchemaMarkup";

const usCpaCourseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "@id": "https://dalmiaacademy.com/us-cpa-coaching#course",
  name: "US CPA Coaching in Indore",
  description:
    "US CPA (Certified Public Accountant) exam coaching at Dalmia Academy, Indore. Comprehensive preparation for all 4 CPA sections — FAR, AUD, REG, BEC — with expert accounting faculty, section-wise mock exams, and strategic exam planning.",
  url: "https://dalmiaacademy.com/us-cpa-coaching",
  image: "https://dalmiaacademy.com/logo.png",
  inLanguage: "hi, en",
  educationalLevel: "ProfessionalCertificate",
  teaches: [
    "Financial Accounting & Reporting (FAR)", "Auditing & Attestation (AUD)",
    "Regulation (REG)", "Business Environment & Concepts (BEC)",
    "US GAAP", "Federal Taxation", "Audit Standards", "Corporate Governance",
  ],
  coursePrerequisites: "Bachelor's degree with 120-150 credit hours in accounting",
  availableLanguage: ["Hindi", "English"],
  provider: {
    "@type": "EducationalOrganization",
    "@id": "https://dalmiaacademy.com/#organization",
    name: "Dalmia Academy",
    url: "https://dalmiaacademy.com/",
    telephone: "+91-95757-76655",
    address: {
      "@type": "PostalAddress",
      streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
      addressLocality: "Indore",
      addressRegion: "Madhya Pradesh",
      postalCode: "452001",
      addressCountry: "IN",
    },
  },
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "US CPA — All 4 Sections",
      courseMode: "Onsite",
      maximumAttendeeCapacity: 25,
      location: {
        "@type": "Place",
        name: "Dalmia Academy",
        address: {
          "@type": "PostalAddress",
          streetAddress: "108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd",
          addressLocality: "Indore",
          addressRegion: "Madhya Pradesh",
          addressCountry: "IN",
        },
      },
    },
  ],
  offers: {
    "@type": "Offer",
    category: "Free Counselling Available",
    url: "https://dalmiaacademy.com/us-cpa-coaching",
    availability: "https://schema.org/LimitedAvailability",
    priceCurrency: "INR",
  },
};

const usCpaContentBlocks = [
  {
    heading: "What is US CPA and Why Is It Valuable?",
    content: `<p>The <strong>US CPA (Certified Public Accountant)</strong> is the most respected accounting license in the United States and one of the most recognized credentials globally. Administered by AICPA (American Institute of Certified Public Accountants), the CPA license is essential for signing audit reports in the US and is highly valued by multinational companies worldwide.</p>
<p>For Indian professionals, US CPA opens doors to roles at Big 4 firms (Deloitte, PwC, EY, KPMG), US-headquartered MNCs, KPOs, and global shared service centres. With US GAAP becoming increasingly important for Indian companies with US operations, CPA holders are in high demand even within India.</p>
<p><strong>Dalmia Academy brings US CPA coaching to Indore</strong> — so you don't need to travel to metro cities for quality preparation. Our 30+ years of accounting teaching expertise provides the perfect foundation for CPA's demanding, application-based exam format.</p>`,
  },
  {
    heading: "US CPA Exam Structure — 4 Sections",
    content: `<p>The Uniform CPA Examination consists of 4 sections, each a 4-hour computer-based test taken at Prometric centres:</p>
<p><strong>FAR (Financial Accounting & Reporting):</strong> The most content-heavy section. Covers US GAAP, governmental accounting, not-for-profit accounting, and financial statement preparation. Requires deep understanding of accounting standards (ASC topics).</p>
<p><strong>AUD (Auditing & Attestation):</strong> Covers AICPA auditing standards, audit planning, risk assessment, internal controls, audit evidence, and reporting. Tests professional judgment and ethical reasoning.</p>
<p><strong>REG (Regulation):</strong> Federal taxation for individuals, corporations, partnerships, and estates. Also covers business law, professional ethics, and federal tax procedures.</p>
<p><strong>BEC (Business Environment & Concepts):</strong> Corporate governance, economic concepts, financial management, information technology, and operations management. Includes written communication tasks scored on writing quality.</p>
<p>You must pass all 4 sections within an 18-month rolling window. At Dalmia Academy, we help you plan the optimal section order and study timeline based on your background.</p>`,
  },
  {
    heading: "CPA Eligibility & Licensing Process",
    content: `<p><strong>Education:</strong> Most US state boards require 150 credit hours (equivalent to a Master's degree) with specific accounting and business course requirements. Indian qualifications like B.Com + CA, M.Com, or MBA typically meet these requirements after credential evaluation by NASBA-approved agencies (WES, FACS).</p>
<p><strong>Exam:</strong> Pass all 4 sections with a score of 75+ (out of 99) within the 18-month window. The exam can be taken at Prometric centres in India (Mumbai, Delhi, Hyderabad, etc.).</p>
<p><strong>Experience:</strong> Most states require 1-2 years of accounting experience under a licensed CPA's supervision.</p>
<p><strong>Ethics:</strong> Some states require passing an ethics exam (AICPA Professional Ethics exam).</p>
<p>At Dalmia Academy, we provide <strong>end-to-end guidance</strong> on credential evaluation, state board selection, NTS application, Prometric scheduling, and post-exam licensing — not just exam coaching.</p>`,
  },
];

const USCPACoaching = () => {
  const seo = getPageSeo("/us-cpa-coaching");
  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <SEO
        {...seo}
        path="/us-cpa-coaching"
        schema={[
          serviceSchema({ name: seo.title!, description: seo.description!, url: "/us-cpa-coaching" }),
          usCpaCourseSchema,
          faqSchema(usCpaContent.faqs.map(f => ({ question: f.q, answer: f.a }))),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "US CPA Coaching in Indore", path: "/us-cpa-coaching" },
          ]),
        ]}
      />
      <StickyHeader />
      <main>
        <HeroSection content={usCpaContent.hero} />
        <WhyChooseSection
          heading={usCpaContent.whyChoose.heading}
          subheading={usCpaContent.whyChoose.subheading}
          benefits={usCpaContent.whyChoose.benefits}
        />
        <CoursesSection
          heading={usCpaContent.courses.heading}
          subheading={usCpaContent.courses.subheading}
          courses={usCpaContent.courses.items}
        />
        <RichTextSection
          sectionHeading="Everything You Need to Know About US CPA"
          blocks={usCpaContentBlocks}
          lastUpdated="May 2026"
        />
        <AboutSection />
        <FacultySection />
        <HighlightsSection
          heading={usCpaContent.highlights.heading}
          subheading={usCpaContent.highlights.subheading}
          highlights={usCpaContent.highlights.items}
        />
        <StudentReviewsSection />
        <LeadFormSection courseOptions={usCpaContent.leadForm.courseOptions} />
        <FAQSection faqs={usCpaContent.faqs} />
        <FinalCTASection
          headline={usCpaContent.finalCTA.headline}
          highlightText={usCpaContent.finalCTA.highlightText}
          subheadline={usCpaContent.finalCTA.subheadline}
          whatsappMessage="Hi, I'm interested in US CPA Coaching at Dalmia Academy, Indore. Please share details."
        />
      </main>
      <Footer />
      <StickyBottomBar whatsappMessage="Hi, I'm interested in US CPA Coaching at Dalmia Academy, Indore. Please share details." />
    </div>
  );
};

export default USCPACoaching;
