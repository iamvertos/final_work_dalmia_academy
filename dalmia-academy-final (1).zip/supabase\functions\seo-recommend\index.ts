import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const lovableKey = Deno.env.get("LOVABLE_API_KEY");

    if (!lovableKey) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY missing" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const { data: isAdmin } = await userClient.rpc("has_role", { _user_id: user.id, _role: "admin" });
    if (!isAdmin) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { result_id } = await req.json();
    if (!result_id) return new Response(JSON.stringify({ error: "result_id required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const admin = createClient(supabaseUrl, serviceKey);
    const { data: row, error } = await admin.from("seo_scan_results").select("*").eq("id", result_id).single();
    if (error || !row) return new Response(JSON.stringify({ error: "Result not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const prompt = `You are a senior technical SEO consultant for Dalmia Academy (Indore), a coaching institute for IPMAT, CUET, CA, Commerce, Humanities, and school students.

Audit findings for route ${row.route_path}:
- Current title (${(row.title || "").length} chars): ${row.title || "(missing)"}
- Current description (${(row.description || "").length} chars): ${row.description || "(missing)"}
- Canonical: ${row.canonical || "(missing)"}
- H1 count: ${row.h1_count ?? 0}
- OG title: ${row.og_title || "(missing)"} | OG image: ${row.og_image || "(missing)"}
- Schema types: ${(row.schema_types || []).join(", ") || "(none)"}
- Status code: ${row.status_code}
- Issues: ${JSON.stringify(row.issues)}

Produce a concise, actionable recommendation in Markdown with:
1. **Improved Title** (≤60 chars, include "Indore" where natural)
2. **Improved Meta Description** (≤160 chars, with a CTA)
3. **Schema additions** (specific @type values to add)
4. **One-paragraph action plan** for the developer

Be specific. No fluff.`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${lovableKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      return new Response(JSON.stringify({ error: `AI gateway error: ${aiRes.status} ${errText}` }), { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const aiJson = await aiRes.json();
    const recommendation = aiJson?.choices?.[0]?.message?.content ?? "";

    await admin.from("seo_scan_results").update({ ai_recommendation: recommendation }).eq("id", result_id);

    return new Response(JSON.stringify({ recommendation }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    return new Response(JSON.stringify({ error: message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});