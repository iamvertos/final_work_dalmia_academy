import { Megaphone } from "lucide-react";

interface AnnouncementBannerProps {
  variant?: "commerce" | "default";
}

const AnnouncementBanner = ({ variant = "default" }: AnnouncementBannerProps) => {
  const message =
    variant === "commerce"
      ? "New Batch Starting from 10th March, 2026"
      : "New Batches Starting from 16th March, 2026";

  return (
    <div className="bg-accent text-accent-foreground py-2.5 px-4 text-center relative overflow-hidden">
      <div className="container mx-auto flex items-center justify-center gap-2 text-sm md:text-base font-semibold font-heading">
        <span className="relative flex h-2.5 w-2.5 shrink-0">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-foreground/60" />
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-accent-foreground" />
        </span>
        <Megaphone className="h-4 w-4 shrink-0 hidden sm:block" />
        <span>{message}</span>
      </div>
    </div>
  );
};

export default AnnouncementBanner;
