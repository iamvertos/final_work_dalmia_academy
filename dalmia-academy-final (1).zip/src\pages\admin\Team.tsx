import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Trash2, UserPlus } from "lucide-react";
import { format } from "date-fns";

interface Counselor {
  id: string;
  email: string;
  name: string;
  created_at: string;
}

const Counselors = () => {
  const { toast } = useToast();
  const [counselors, setCounselors] = useState<Counselor[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const fetchCounselors = async () => {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("manage-counselor", {
      body: { action: "list" },
    });
    if (error) {
      toast({ title: "Error loading counselors", variant: "destructive" });
    } else {
      setCounselors(data?.counselors || []);
    }
    setLoading(false);
  };

  useEffect(() => { fetchCounselors(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      toast({ title: "Email and password required", variant: "destructive" });
      return;
    }
    setCreating(true);
    const { data, error } = await supabase.functions.invoke("manage-counselor", {
      body: { action: "create", email: form.email, password: form.password, name: form.name },
    });
    setCreating(false);
    if (error || data?.error) {
      toast({ title: "Error", description: data?.error || error?.message, variant: "destructive" });
    } else {
      toast({ title: "Counselor created" });
      setForm({ name: "", email: "", password: "" });
      fetchCounselors();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this counselor? Their leads will be unassigned.")) return;
    const { data, error } = await supabase.functions.invoke("manage-counselor", {
      body: { action: "delete", counselor_id: id },
    });
    if (error || data?.error) {
      toast({ title: "Error", description: data?.error || error?.message, variant: "destructive" });
    } else {
      toast({ title: "Counselor deleted" });
      fetchCounselors();
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-heading font-bold">Team Members</h1>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add New Team Member</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <Input
              placeholder="Email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
            <Input
              placeholder="Password"
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
              minLength={6}
            />
            <Button type="submit" disabled={creating} className="shrink-0">
              <UserPlus className="h-4 w-4 mr-1" />
              {creating ? "Creating..." : "Add"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {loading ? (
        <p className="text-muted-foreground">Loading...</p>
      ) : (
        <div className="rounded-lg border border-border overflow-x-auto bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {counselors.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                    No team members yet
                  </TableCell>
                </TableRow>
              ) : (
                counselors.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>{c.email}</TableCell>
                    <TableCell className="text-xs">{format(new Date(c.created_at), "MMM dd, yyyy")}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(c.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default Counselors;
