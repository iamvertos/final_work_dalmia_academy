import { Link } from "react-router-dom";
import { Phone, Mail, MapPin } from "lucide-react";
import WhatsAppIcon from "@/components/icons/WhatsAppIcon";
import logo from "@/assets/dalmia-academy-logo.webp";

const quickLinks = [
  { label: "Home", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Results", path: "/results" },
  { label: "Blog", path: "/blog" },
  { label: "Resources", path: "/resources" },
  { label: "Contact", path: "/contact" },
];

const courseLinks = [
  { label: "CUET & IPMAT Coaching", path: "/cuet-coaching" },
  { label: "CA Coaching in Indore", path: "/ca-foundation" },
  { label: "ACCA Coaching", path: "/acca-coaching" },
  { label: "US CPA Coaching", path: "/us-cpa-coaching" },
  { label: "US CMA Coaching", path: "/us-cma-coaching" },
  { label: "CFA Coaching", path: "/cfa-coaching" },
  { label: "Commerce Coaching", path: "/commerce-coaching" },
  { label: "Humanities Coaching", path: "/humanities-coaching" },
  { label: "Class 6–10 Coaching", path: "/school-coaching" },
  { label: "Spoken English", path: "/spoken-english" },
];

const Footer = () => {
  return (
    <footer className="bg-[#154360] text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="bg-white rounded-lg p-2 inline-block mb-4">
              <img src={logo} alt="Dalmia Academy Logo" width={192} height={48} loading="lazy" className="h-12 w-auto" />
            </div>
            <p className="text-sm opacity-70 leading-relaxed mb-4">
              Building strong foundations since 1991. Indore's most trusted coaching institute for Commerce, CA, CUET &amp; competitive exams.
            </p>
            <div className="flex gap-3">
              <a
                href="https://wa.me/919109109651?text=Hi%2C%20I%20want%20to%20know%20about%20Dalmia%20Academy"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-background/10 hover:bg-background/20 flex items-center justify-center transition-colors"
                aria-label="Chat on WhatsApp about Dalmia Academy courses"
              >
                <WhatsAppIcon className="h-4 w-4" />
              </a>
              <a
                href="https://www.instagram.com/dalmia_academy_indore/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-background/10 hover:bg-background/20 flex items-center justify-center transition-colors text-sm font-bold"
                aria-label="Instagram"
              >
                IG
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider mb-4 opacity-90">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm opacity-70 hover:opacity-100 transition-opacity">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider mb-4 opacity-90">Courses</h3>
            <ul className="space-y-2">
              {courseLinks.map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm opacity-70 hover:opacity-100 transition-opacity">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading font-bold text-sm uppercase tracking-wider mb-4 opacity-90">Contact Us</h3>
            <ul className="space-y-3">
              <li>
                <a href="tel:+919575776655" className="flex items-start gap-2 text-sm opacity-70 hover:opacity-100 transition-opacity">
                  <Phone className="h-4 w-4 mt-0.5 shrink-0" />
                  +91 95757 76655
                </a>
              </li>
              <li>
                <a href="mailto:dalmiaacademy@gmail.com" className="flex items-start gap-2 text-sm opacity-70 hover:opacity-100 transition-opacity">
                  <Mail className="h-4 w-4 mt-0.5 shrink-0" />
                  dalmiaacademy@gmail.com
                </a>
              </li>
              <li>
                <a
                  href="https://www.google.com/maps/place/?q=place_id:ChIJH579QzX9YjkR4wewVlLwGW8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-2 text-sm opacity-70 hover:opacity-100 transition-opacity"
                >
                  <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
                  108-109, First Floor, Tulsi Tower, Geeta Bhawan Square, AB Rd, Indore
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-background/10">
        <div className="container mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs opacity-60">
            © {new Date().getFullYear()} Dalmia Academy, Indore. All rights reserved.
          </p>
          <p className="text-xs opacity-60">
            Owned and Managed by Yasharsh Educational Initiatives LLP
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
