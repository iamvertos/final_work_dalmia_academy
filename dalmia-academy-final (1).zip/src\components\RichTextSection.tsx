interface ContentBlock {
  heading: string;
  content: string;
}

interface RichTextSectionProps {
  sectionHeading: string;
  blocks: ContentBlock[];
  lastUpdated?: string;
}

const RichTextSection = ({ sectionHeading, blocks, lastUpdated }: RichTextSectionProps) => {
  return (
    <section className="py-14 md:py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold font-heading text-primary mb-8 text-center">
            {sectionHeading}
          </h2>

          <div className="space-y-8">
            {blocks.map((block, i) => (
              <div key={i} className="bg-card rounded-xl p-6 md:p-8 shadow-sm border border-border">
                <h3 className="text-lg md:text-xl font-bold font-heading text-foreground mb-3">
                  {block.heading}
                </h3>
                <div
                  className="text-muted-foreground leading-relaxed space-y-3 prose prose-sm max-w-none"
                  dangerouslySetInnerHTML={{ __html: block.content }}
                />
              </div>
            ))}
          </div>

          {lastUpdated && (
            <p className="text-center text-xs text-muted-foreground mt-8">
              Last updated: {lastUpdated}
            </p>
          )}
        </div>
      </div>
    </section>
  );
};

export default RichTextSection;
