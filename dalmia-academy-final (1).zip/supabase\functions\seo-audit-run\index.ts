import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const BASE_URL = "https://dalmiaacademy.com";

const STATIC_ROUTES: Array<{ path: string; indexable: boolean }> = [
  { path: "/", indexable: true },
  { path: "/cuet-coaching", indexable: true },
  { path: "/ca-foundation", indexable: true },
  { path: "/commerce-coaching", indexable: true },
  { path: "/humanities-coaching", indexable: true },
  { path: "/school-coaching", indexable: true },
  { path: "/spoken-english", indexable: true },
  { path: "/about", indexable: true },
  { path: "/results", indexable: true },
  { path: "/contact", indexable: true },
  { path: "/resources", indexable: true },
  { path: "/blog", indexable: true },
  { path: "/summer-camp-2026", indexable: true },
  { path: "/summer-camp/register", indexable: false },
  { path: "/thank-you", indexable: false },
  { path: "/review", indexable: false },
];

interface Issue {
  code: string;
  severity: "high" | "medium" | "low";
  message: string;
}

function extractMeta(html: string) {
  const get = (re: RegExp) => {
    const m = html.match(re);
    return m ? m[1].trim() : null;
  };

  const title = get(/<title[^>]*>([^<]*)<\/title>/i);
  const description = get(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)["']/i);
  const canonical = get(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']*)["']/i);
  const ogTitle = get(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']*)["']/i);
  const ogDescription = get(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']*)["']/i);
  const ogImage = get(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']*)["']/i);
  const robots = get(/<meta[^>]+name=["']robots["'][^>]+content=["']([^"']*)["']/i);

  const h1Matches = html.match(/<h1[\s>]/gi) || [];
  const h1Count = h1Matches.length;

  const schemaTypes: string[] = [];
  const ldRe = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = ldRe.exec(html)) !== null) {
    try {
      const parsed = JSON.parse(m[1].trim());
      const items = Array.isArray(parsed) ? parsed : [parsed];
      for (const item of items) {
        const t = item?.["@type"];
        if (typeof t === "string") schemaTypes.push(t);
        else if (Array.isArray(t)) schemaTypes.push(...t.filter((x: unknown) => typeof x === "string"));
      }
    } catch { /* ignore parse errors */ }
  }

  return { title, description, canonical, ogTitle, ogDescription, ogImage, robots, h1Count, schemaTypes };
}

function evaluate(path: string, indexable: boolean, statusCode: number, meta: ReturnType<typeof extractMeta>): Issue[] {
  const issues: Issue[] = [];
  if (statusCode !== 200) {
    issues.push({ code: "non_200", severity: "high", message: `HTTP ${statusCode}` });
    return issues;
  }

  if (!meta.title) issues.push({ code: "title_missing", severity: "high", message: "Missing <title>" });
  else if (meta.title.length > 60) issues.push({ code: "title_long", severity: "medium", message: `Title is ${meta.title.length} chars (max 60)` });
  else if (meta.title.length < 20) issues.push({ code: "title_short", severity: "low", message: `Title is only ${meta.title.length} chars` });

  if (!meta.description) issues.push({ code: "description_missing", severity: "high", message: "Missing meta description" });
  else if (meta.description.length > 160) issues.push({ code: "description_long", severity: "medium", message: `Description is ${meta.description.length} chars (max 160)` });
  else if (meta.description.length < 50) issues.push({ code: "description_short", severity: "low", message: `Description is only ${meta.description.length} chars` });

  if (indexable) {
    if (!meta.canonical) issues.push({ code: "canonical_missing", severity: "high", message: "Missing canonical link" });
    else if (!meta.canonical.startsWith(BASE_URL)) issues.push({ code: "canonical_wrong_domain", severity: "medium", message: `Canonical points outside ${BASE_URL}` });

    if (meta.robots && /noindex/i.test(meta.robots)) {
      issues.push({ code: "unexpected_noindex", severity: "high", message: "Indexable route is marked noindex" });
    }
  } else {
    if (!meta.robots || !/noindex/i.test(meta.robots)) {
      issues.push({ code: "missing_noindex", severity: "high", message: "Utility/admin route should be noindex" });
    }
  }

  if (meta.h1Count === 0) issues.push({ code: "h1_missing", severity: "medium", message: "No <h1> found" });
  else if (meta.h1Count > 1) issues.push({ code: "h1_multiple", severity: "medium", message: `Found ${meta.h1Count} <h1> tags` });

  if (!meta.ogTitle) issues.push({ code: "og_title_missing", severity: "low", message: "Missing og:title" });
  if (!meta.ogDescription) issues.push({ code: "og_description_missing", severity: "low", message: "Missing og:description" });
  if (!meta.ogImage) issues.push({ code: "og_image_missing", severity: "low", message: "Missing og:image" });

  if (indexable && meta.schemaTypes.length === 0) {
    issues.push({ code: "schema_missing", severity: "medium", message: "No JSON-LD schema detected" });
  }

  return issues;
}

function severityOf(issues: Issue[]): string {
  if (issues.some((i) => i.severity === "high")) return "high";
  if (issues.some((i) => i.severity === "medium")) return "medium";
  if (issues.length > 0) return "low";
  return "ok";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: isAdmin } = await userClient.rpc("has_role", { _user_id: user.id, _role: "admin" });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const admin = createClient(supabaseUrl, serviceKey);

    // Build routes list: static + published blog posts
    const { data: blogs } = await admin.from("blog_posts").select("slug").eq("published", true);
    const blogRoutes = (blogs ?? []).map((b: { slug: string }) => ({ path: `/blog/${b.slug}`, indexable: true }));
    const routes = [...STATIC_ROUTES, ...blogRoutes];

    // Create scan
    const { data: scan, error: scanErr } = await admin.from("seo_scans").insert({
      status: "running",
      total_routes: routes.length,
      triggered_by: user.id,
    }).select().single();
    if (scanErr) throw scanErr;

    let passed = 0, failed = 0, warnings = 0;
    const resultRows: Array<Record<string, unknown>> = [];

    for (const route of routes) {
      const url = `${BASE_URL}${route.path}`;
      let statusCode = 0;
      let html = "";
      try {
        const res = await fetch(url, { headers: { "User-Agent": "DalmiaSEOAuditBot/1.0" } });
        statusCode = res.status;
        html = await res.text();
      } catch (e) {
        statusCode = 0;
      }
      const meta = html ? extractMeta(html) : {
        title: null, description: null, canonical: null, ogTitle: null, ogDescription: null, ogImage: null, robots: null, h1Count: 0, schemaTypes: [],
      };
      const issues = evaluate(route.path, route.indexable, statusCode, meta);
      const sev = severityOf(issues);
      if (sev === "ok") passed++;
      else if (sev === "high") failed++;
      else warnings++;

      resultRows.push({
        scan_id: scan.id,
        route_path: route.path,
        status_code: statusCode,
        title: meta.title,
        description: meta.description,
        canonical: meta.canonical,
        h1_count: meta.h1Count,
        og_title: meta.ogTitle,
        og_description: meta.ogDescription,
        og_image: meta.ogImage,
        robots: meta.robots,
        schema_types: meta.schemaTypes,
        issues,
        severity: sev,
      });
    }

    const { error: insertErr } = await admin.from("seo_scan_results").insert(resultRows);
    if (insertErr) throw insertErr;

    await admin.from("seo_scans").update({
      status: "complete",
      finished_at: new Date().toISOString(),
      passed, failed, warnings,
    }).eq("id", scan.id);

    return new Response(JSON.stringify({ scan_id: scan.id, passed, failed, warnings, total: routes.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    return new Response(JSON.stringify({ error: message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});